import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { u as useQuery } from "../_libs/tanstack__react-query.mjs";
import { A as AppLayout } from "./AppLayout-BsiDHgiV.mjs";
import { K as KpiCard } from "./KpiCard-B0PnoKzu.mjs";
import { C as Card } from "./card-RGlIzTYo.mjs";
import { S as StatusBadge } from "./StatusBadge-BmU038Ba.mjs";
import { e as egp, s as supabase } from "./router-ChN6Fncz.mjs";
import { K as KeyRound, F as FileText, W as Wallet, p as TrendingDown, Y as CalendarClock, H as House, o as TrendingUp, c as Wrench, T as TriangleAlert, i as Banknote } from "../_libs/lucide-react.mjs";
import { f as format, a as addDays, b as startOfMonth, e as endOfMonth, g as addMonths, s as subMonths } from "../_libs/date-fns.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/cmdk.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-effect-event+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "./button-DL752WFK.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-dropdown-menu.mjs";
import "../_libs/radix-ui__react-menu.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-roving-focus.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/supabase__functions-js.mjs";
const getDashboardStats = async () => {
  const today = /* @__PURE__ */ new Date();
  const in60Days = format(addDays(today, 60), "yyyy-MM-dd");
  const todayStr = format(today, "yyyy-MM-dd");
  const monthStart = format(startOfMonth(today), "yyyy-MM-dd");
  const monthEnd = format(endOfMonth(today), "yyyy-MM-dd");
  const nextMonthStart = format(startOfMonth(addMonths(today, 1)), "yyyy-MM-dd");
  const nextMonthEnd = format(endOfMonth(addMonths(today, 1)), "yyyy-MM-dd");
  const [
    { count: totalUnits },
    { count: rentedUnits },
    { count: availableUnits },
    { count: maintenanceUnits },
    { count: activeContracts },
    { count: expiringSoon },
    { data: allUnits },
    { data: payments },
    { data: recentMaintenance },
    { data: depositsData }
  ] = await Promise.all([
    supabase.from("units").select("*", { count: "exact", head: true }),
    supabase.from("units").select("*", { count: "exact", head: true }).eq("status", "rented"),
    supabase.from("units").select("*", { count: "exact", head: true }).eq("status", "available"),
    supabase.from("units").select("*", { count: "exact", head: true }).eq("status", "maintenance"),
    supabase.from("contracts").select("*", { count: "exact", head: true }).eq("status", "نشط"),
    supabase.from("contracts").select("*", { count: "exact", head: true }).eq("status", "نشط").gte("end_date", todayStr).lte("end_date", in60Days),
    supabase.from("units").select("rent_price, city"),
    supabase.from("payments").select("amount, status, payment_date"),
    supabase.from("maintenance").select("*, units(number, title)").order("created_at", { ascending: false }).limit(5),
    supabase.from("deposits").select("amount").eq("status", "held")
  ]);
  const unitsList = allUnits || [];
  const avgRent = unitsList.length ? Math.round(unitsList.reduce((s, u) => s + (u.rent_price || 0), 0) / unitsList.length) : 0;
  const cityMap = {};
  for (const u of unitsList) {
    const city = u.city || "غير محدد";
    cityMap[city] = (cityMap[city] || 0) + 1;
  }
  const topCities = Object.entries(cityMap).sort(([, a], [, b]) => b - a).slice(0, 5).map(([name, count]) => ({
    name,
    count,
    pct: unitsList.length ? Math.round(count / unitsList.length * 100) : 0
  }));
  const allPayments = payments || [];
  const thisMonth = allPayments.filter((p) => p.status === "مدفوع" && p.payment_date >= monthStart && p.payment_date <= monthEnd).reduce((s, p) => s + (p.amount || 0), 0);
  const overdue = allPayments.filter((p) => p.status === "متأخر").reduce((s, p) => s + (p.amount || 0), 0);
  const nextMonth = allPayments.filter((p) => p.payment_date >= nextMonthStart && p.payment_date <= nextMonthEnd).reduce((s, p) => s + (p.amount || 0), 0);
  const totalHeld = (depositsData || []).reduce((s, d) => s + (d.amount || 0), 0);
  const monthly = [];
  for (let i = 5; i >= 0; i--) {
    const d = subMonths(today, i);
    const start = format(startOfMonth(d), "yyyy-MM-dd");
    const end = format(endOfMonth(d), "yyyy-MM-dd");
    const val = allPayments.filter((p) => p.status === "مدفوع" && p.payment_date >= start && p.payment_date <= end).reduce((s, p) => s + (p.amount || 0), 0);
    monthly.push({ month: format(d, "MMM"), value: val });
  }
  return {
    units: {
      total: totalUnits || 0,
      rented: rentedUnits || 0,
      available: availableUnits || 0,
      maintenance: maintenanceUnits || 0,
      avgRent
    },
    contracts: {
      active: activeContracts || 0,
      expiringSoon: expiringSoon || 0
    },
    payments: { thisMonth, overdue, nextMonth },
    deposits: { totalHeld },
    monthly,
    topCities,
    maintenance: recentMaintenance || []
  };
};
function Dashboard() {
  const {
    data: stats,
    isLoading
  } = useQuery({
    queryKey: ["dashboard-stats"],
    queryFn: getDashboardStats,
    staleTime: 2 * 60 * 1e3
  });
  const maxRev = stats ? Math.max(...stats.monthly.map((m) => m.value), 1) : 1;
  const occupancyRate = stats?.units.total ? Math.round(stats.units.rented / stats.units.total * 100) : 0;
  if (isLoading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(AppLayout, { title: "لوحة التحكم", subtitle: "نظرة عامة على أداء محفظتك العقارية", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-[60vh] items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-10 w-10 animate-spin rounded-full border-b-2 border-primary" }) }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(AppLayout, { title: "لوحة التحكم", subtitle: "نظرة عامة على أداء محفظتك العقارية", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-4 xl:grid-cols-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "إجمالي الوحدات", value: stats?.units.total.toString() || "0", hint: `${stats?.units.available || 0} شاغرة • ${stats?.units.rented || 0} مؤجرة`, icon: KeyRound, tone: "primary" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "العقود النشطة", value: stats?.contracts.active.toString() || "0", hint: "إجمالي العقود السارية", icon: FileText, tone: "success" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "تحصيلات الشهر", value: egp(stats?.payments.thisMonth || 0), hint: "الدفعات المحصلة هذا الشهر", icon: Wallet, tone: "gold" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "إجمالي المتأخرات", value: egp(stats?.payments.overdue || 0), hint: "مبالغ إيجار متأخرة", icon: TrendingDown, tone: "warning" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "تحصيلات الشهر القادم", value: egp(stats?.payments.nextMonth || 0), hint: "مبالغ متوقع تحصيلها", icon: CalendarClock, tone: "accent" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 grid grid-cols-2 gap-4 xl:grid-cols-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "نسبة الإشغال", value: `${occupancyRate}%`, icon: House, tone: "success" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "متوسط الإيجار", value: egp(stats?.units.avgRent || 0), icon: TrendingUp, tone: "accent" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "تحت الصيانة", value: stats?.units.maintenance.toString() || "0", icon: Wrench, tone: "warning" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/reports", className: "block", children: /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "عقود تنتهي قريباً", value: stats?.contracts.expiringSoon.toString() || "0", hint: "خلال 60 يوم — اضغط للتفاصيل", icon: TriangleAlert, tone: "warning" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/deposits", className: "block", children: /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "إجمالي التأمينات", value: egp(stats?.deposits.totalHeld || 0), hint: "المبالغ المحتجزة حالياً", icon: Banknote, tone: "success" }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 grid grid-cols-1 gap-4 lg:grid-cols-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-5 lg:col-span-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mb-4 font-bold text-foreground", children: "الإيرادات الشهرية (آخر 6 أشهر)" }),
        stats?.monthly.every((m) => m.value === 0) ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-48 items-center justify-center text-sm text-muted-foreground", children: "لا توجد إيرادات مسجلة بعد" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-52 items-end gap-3", children: stats?.monthly.map((m) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-1 flex-col items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-semibold text-foreground", children: m.value > 0 ? egp(m.value) : "" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex w-full flex-1 items-end", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full rounded-t-lg bg-accent transition-all hover:bg-primary", style: {
            height: `${Math.max(m.value / maxRev * 100, m.value > 0 ? 4 : 0)}%`
          } }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-muted-foreground", children: m.month })
        ] }, m.month)) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mb-4 font-bold text-foreground", children: "أعلى المناطق بالوحدات" }),
        stats?.topCities.length ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4", children: stats.topCities.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-1 flex justify-between text-sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-foreground", children: c.name }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-muted-foreground", children: [
              c.count,
              " وحدة (",
              c.pct,
              "%)"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-2 w-full overflow-hidden rounded-full bg-secondary", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-full rounded-full bg-primary", style: {
            width: `${c.pct}%`
          } }) })
        ] }, c.name)) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-40 items-center justify-center text-sm text-muted-foreground", children: "لا توجد وحدات مسجلة بعد." })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "mt-6 p-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-foreground", children: "أحدث طلبات الصيانة" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/maintenance", className: "text-sm font-medium text-primary hover:underline", children: "عرض الكل" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: stats?.maintenance && stats.maintenance.length > 0 ? stats.maintenance.map((m) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2 rounded-lg border border-border p-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "font-semibold text-foreground", children: [
            m.description || m.type || "طلب صيانة",
            " — ",
            m.units?.title || "وحدة غير معروفة"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-muted-foreground", children: [
            "وحدة رقم: ",
            m.units?.number || "-",
            " • ",
            format(new Date(m.created_at), "yyyy/MM/dd")
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { status: m.status })
      ] }, m.id)) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "py-8 text-center text-sm text-muted-foreground", children: "لا توجد طلبات صيانة حالية." }) })
    ] })
  ] });
}
export {
  Dashboard as component
};
