import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { u as useQuery } from "../_libs/tanstack__react-query.mjs";
import { A as AppLayout, g as getReportStats } from "./AppLayout-C7gE-JWZ.mjs";
import { C as Card } from "./card-RGlIzTYo.mjs";
import { K as KpiCard } from "./KpiCard-B0PnoKzu.mjs";
import { D as DataTable } from "./DataTable-lfA95yU8.mjs";
import { S as StatusBadge } from "./StatusBadge-AJi_pDVS.mjs";
import { R as Root2, L as List, T as Trigger, C as Content } from "../_libs/radix-ui__react-tabs.mjs";
import { c as cn } from "./utils-H80jjgLf.mjs";
import { B as Button } from "./button-DL752WFK.mjs";
import { g as getPayments } from "./payments-D3DmHtDk.mjs";
import { g as getContracts } from "./contracts-CzvTNqoa.mjs";
import { g as getUnits } from "./units-CIw35dUG.mjs";
import { g as getMaintenanceRequests } from "./maintenance-BuYo71NX.mjs";
import { e as egp } from "./router-C7nVfvJ9.mjs";
import { e as exportToExcel } from "./excel-ncAzCXAJ.mjs";
import "../_libs/sonner.mjs";
import { a as addDays, i as isBefore, c as startOfDay, d as differenceInDays } from "../_libs/date-fns.mjs";
import { n as Building2, o as TrendingUp, W as Wallet, p as TrendingDown, F as FileText, c as Wrench, D as Download } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/cmdk.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-effect-event+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-dropdown-menu.mjs";
import "../_libs/radix-ui__react-menu.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-roving-focus.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/xlsx.mjs";
const Tabs = Root2;
const TabsList = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  List,
  {
    ref,
    className: cn(
      "inline-flex h-9 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground",
      className
    ),
    ...props
  }
));
TabsList.displayName = List.displayName;
const TabsTrigger = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Trigger,
  {
    ref,
    className: cn(
      "inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background cursor-pointer transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow",
      className
    ),
    ...props
  }
));
TabsTrigger.displayName = Trigger.displayName;
const TabsContent = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Content,
  {
    ref,
    className: cn(
      "mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
      className
    ),
    ...props
  }
));
TabsContent.displayName = Content.displayName;
const statusTranslations = {
  available: "متاح",
  rented: "مؤجر",
  maintenance: "تحت الصيانة"
};
function SectionHeader({
  title,
  onExport
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-3 flex items-center justify-between", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-foreground", children: title }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", size: "sm", className: "gap-1 text-muted-foreground", onClick: onExport, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "h-4 w-4" }),
      " تصدير"
    ] })
  ] });
}
function EmptyTable({
  msg
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-32 items-center justify-center rounded-lg border border-dashed border-border text-sm text-muted-foreground", children: msg });
}
function Reports() {
  const {
    data: stats,
    isLoading: loadingStats
  } = useQuery({
    queryKey: ["report-stats"],
    queryFn: getReportStats
  });
  const {
    data: payments = [],
    isLoading: loadingPayments
  } = useQuery({
    queryKey: ["payments"],
    queryFn: getPayments
  });
  const {
    data: contracts = [],
    isLoading: loadingContracts
  } = useQuery({
    queryKey: ["contracts"],
    queryFn: getContracts
  });
  const {
    data: units = [],
    isLoading: loadingUnits
  } = useQuery({
    queryKey: ["units"],
    queryFn: getUnits
  });
  const {
    data: maintenance = [],
    isLoading: loadingMaint
  } = useQuery({
    queryKey: ["maintenance"],
    queryFn: getMaintenanceRequests
  });
  const today = /* @__PURE__ */ new Date();
  const in60Days = addDays(today, 60);
  const overduePayments = payments.filter((p) => p.status === "متأخر");
  const duePayments = payments.filter((p) => p.status === "مستحق");
  const collectedPayments = payments.filter((p) => p.status === "مدفوع");
  const expiringContracts = contracts.filter((c) => c.status === "نشط" && c.end_date && !isBefore(new Date(c.end_date), startOfDay(today)) && isBefore(new Date(c.end_date), in60Days));
  const expiredContracts = contracts.filter((c) => {
    if (c.end_date && isBefore(new Date(c.end_date), startOfDay(today))) return true;
    return c.status === "عقد منتهي";
  });
  const vacantUnits = units.filter((u) => u.status === "available");
  const maintenanceUnits = units.filter((u) => u.status === "maintenance");
  const pendingMaint = maintenance.filter((m) => ["جديد", "مفتوح", "pending"].includes(m.status || ""));
  const maxRev = stats ? Math.max(...stats.payments.monthly.map((m) => m.value), 1) : 1;
  const occupancy = stats?.units.total ? Math.round(stats.units.rented / stats.units.total * 100) : 0;
  const paymentColumns = [{
    key: "receipt_number",
    header: "الإيصال",
    render: (r) => r.receipt_number || "-"
  }, {
    key: "tenant",
    header: "المستأجر",
    render: (r) => r.contracts?.tenants?.full_name || "-"
  }, {
    key: "unit",
    header: "الوحدة",
    render: (r) => `${r.contracts?.units?.title || "-"} ${r.contracts?.units?.number ? `- ${r.contracts.units.number}` : ""}`
  }, {
    key: "amount",
    header: "المبلغ",
    render: (r) => egp(r.amount)
  }, {
    key: "payment_date",
    header: "التاريخ",
    render: (r) => r.payment_date
  }, {
    key: "payment_method",
    header: "الطريقة",
    render: (r) => r.payment_method || "-"
  }, {
    key: "status",
    header: "الحالة",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { status: r.status || "مدفوع" })
  }];
  const overdueColumns = [{
    key: "tenant",
    header: "المستأجر",
    render: (r) => r.contracts?.tenants?.full_name || "-"
  }, {
    key: "unit",
    header: "الوحدة",
    render: (r) => `${r.contracts?.units?.title || "-"} ${r.contracts?.units?.number ? `- ${r.contracts.units.number}` : ""}`
  }, {
    key: "amount",
    header: "المبلغ المتأخر",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-destructive", children: egp(r.amount) })
  }, {
    key: "payment_date",
    header: "كان مستحقاً في",
    render: (r) => r.payment_date
  }, {
    key: "delay",
    header: "أيام التأخير",
    render: (r) => {
      const days = differenceInDays(today, new Date(r.payment_date));
      return /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-destructive", children: days > 0 ? `${days} يوم` : "-" });
    }
  }];
  const contractColumns = [{
    key: "number",
    header: "رقم العقد",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/contracts/$id", params: {
      id: r.id
    }, className: "font-bold text-primary hover:underline", children: r.number || "بدون رقم" })
  }, {
    key: "tenant",
    header: "المستأجر",
    render: (r) => r.tenants?.full_name || "-"
  }, {
    key: "unit",
    header: "الوحدة",
    render: (r) => `${r.units?.title || "-"} - ${r.units?.number || ""}`
  }, {
    key: "end_date",
    header: "تاريخ الانتهاء",
    render: (r) => r.end_date
  }, {
    key: "days_left",
    header: "المتبقي",
    render: (r) => {
      const days = differenceInDays(new Date(r.end_date), today);
      const color = days <= 14 ? "text-destructive" : days <= 30 ? "text-warning" : "text-foreground";
      return /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `font-bold ${color}`, children: days >= 0 ? `${days} يوم` : "منتهي" });
    }
  }, {
    key: "rent_amount",
    header: "الإيجار",
    render: (r) => egp(r.rent_amount)
  }, {
    key: "status",
    header: "الحالة",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { status: r.status || "نشط" })
  }];
  const unitColumns = [{
    key: "number",
    header: "رقم الوحدة",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/units/$id", params: {
      id: r.id
    }, className: "font-bold text-primary hover:underline", children: r.number || "-" })
  }, {
    key: "title",
    header: "العقار",
    render: (r) => r.title
  }, {
    key: "type",
    header: "النوع",
    render: (r) => r.type
  }, {
    key: "city",
    header: "المدينة",
    render: (r) => r.city || "-"
  }, {
    key: "floor",
    header: "الطابق",
    render: (r) => r.floor || "-"
  }, {
    key: "area",
    header: "المساحة",
    render: (r) => r.area ? `${r.area} م²` : "-"
  }, {
    key: "rent_price",
    header: "الإيجار",
    render: (r) => egp(r.rent_price)
  }, {
    key: "status",
    header: "الحالة",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { status: statusTranslations[r.status] || r.status })
  }];
  const maintenanceColumns = [{
    key: "number",
    header: "رقم الطلب",
    render: (r) => r.number || "-"
  }, {
    key: "unit",
    header: "الوحدة",
    render: (r) => r.units ? `${r.units.title} - ${r.units.number || ""}` : "-"
  }, {
    key: "type",
    header: "النوع",
    render: (r) => r.type || "-"
  }, {
    key: "description",
    header: "الوصف",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "max-w-xs truncate block", children: r.description || "-" })
  }, {
    key: "priority",
    header: "الأولوية",
    render: (r) => r.priority || "-"
  }, {
    key: "status",
    header: "الحالة",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { status: r.status || "جديد" })
  }];
  const exportOverdue = () => exportToExcel(overduePayments.map((p) => ({
    "المستأجر": p.contracts?.tenants?.full_name || "-",
    "الوحدة": `${p.contracts?.units?.title || "-"} - ${p.contracts?.units?.number || ""}`,
    "المبلغ": p.amount,
    "تاريخ الاستحقاق": p.payment_date,
    "أيام التأخير": differenceInDays(today, new Date(p.payment_date))
  })), "تقرير_المتأخرات");
  const exportExpiring = () => exportToExcel(expiringContracts.map((c) => ({
    "رقم العقد": c.number,
    "المستأجر": c.tenants?.full_name || "-",
    "الوحدة": `${c.units?.title || "-"} - ${c.units?.number || ""}`,
    "تاريخ الانتهاء": c.end_date,
    "الأيام المتبقية": differenceInDays(new Date(c.end_date), today),
    "الإيجار": c.rent_amount
  })), "تقرير_العقود_المنتهية");
  const exportVacant = () => exportToExcel(vacantUnits.map((u) => ({
    "رقم الوحدة": u.number,
    "العقار": u.title,
    "النوع": u.type,
    "المدينة": u.city || "-",
    "الطابق": u.floor || "-",
    "المساحة": u.area ? `${u.area} م²` : "-",
    "الإيجار": u.rent_price
  })), "تقرير_الوحدات_الشاغرة");
  const exportMaintenance = () => exportToExcel(pendingMaint.map((m) => ({
    "رقم الطلب": m.number,
    "الوحدة": m.units ? `${m.units.title} - ${m.units.number || ""}` : "-",
    "النوع": m.type,
    "الوصف": m.description,
    "الأولوية": m.priority,
    "الحالة": m.status
  })), "تقرير_الصيانة_المعلقة");
  const isLoading = loadingStats || loadingPayments || loadingContracts || loadingUnits || loadingMaint;
  if (isLoading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(AppLayout, { title: "التقارير", subtitle: "تقارير شاملة عن أداء العقارات والمالية", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-[60vh] items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-10 w-10 animate-spin rounded-full border-b-2 border-primary" }) }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(AppLayout, { title: "التقارير", subtitle: "تقارير شاملة عن أداء العقارات والمالية", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-4 xl:grid-cols-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "إجمالي الوحدات", value: stats?.units.total.toString() || "0", icon: Building2, tone: "primary" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "نسبة الإشغال", value: `${occupancy}%`, icon: TrendingUp, tone: "success" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "إجمالي التحصيلات", value: egp(stats?.payments.collected || 0), icon: Wallet, tone: "gold" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "المتأخرات", value: egp(stats?.payments.overdue || 0), icon: TrendingDown, tone: "warning" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "mt-5 p-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mb-4 font-bold text-foreground", children: "الإيرادات الشهرية (آخر 6 أشهر)" }),
      stats && stats.payments.monthly.every((m) => m.value === 0) ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-48 items-center justify-center text-sm text-muted-foreground", children: "لا توجد إيرادات مسجلة بعد — ابدأ بتسجيل دفعات في صفحة التحصيلات" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-52 items-end gap-3", children: stats?.payments.monthly.map((m) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-1 flex-col items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-semibold text-foreground", children: m.value > 0 ? egp(m.value) : "" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex w-full flex-1 items-end", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full rounded-t-lg bg-accent transition-all hover:bg-primary", style: {
          height: `${Math.max(m.value / maxRev * 100, m.value > 0 ? 4 : 0)}%`
        } }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-muted-foreground", children: m.month })
      ] }, m.month)) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Tabs, { defaultValue: "financial", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsList, { className: "mb-4 flex flex-wrap gap-1 h-auto", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsTrigger, { value: "financial", className: "gap-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Wallet, { className: "h-4 w-4" }),
          " التقرير المالي",
          overduePayments.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mr-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-bold text-destructive-foreground", children: overduePayments.length })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsTrigger, { value: "contracts", className: "gap-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(FileText, { className: "h-4 w-4" }),
          " العقود",
          expiringContracts.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mr-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-warning px-1 text-[10px] font-bold text-warning-foreground", children: expiringContracts.length })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsTrigger, { value: "units", className: "gap-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "h-4 w-4" }),
          " الوحدات"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsTrigger, { value: "maintenance", className: "gap-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Wrench, { className: "h-4 w-4" }),
          " الصيانة",
          pendingMaint.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mr-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-bold text-destructive-foreground", children: pendingMaint.length })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsContent, { value: "financial", className: "space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeader, { title: `الدفعات المتأخرة (${overduePayments.length})`, onExport: exportOverdue }),
          overduePayments.length ? /* @__PURE__ */ jsxRuntimeExports.jsx(DataTable, { columns: overdueColumns, rows: overduePayments }) : /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyTable, { msg: "لا توجد دفعات متأخرة — ممتاز!" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeader, { title: `الدفعات المستحقة (${duePayments.length})`, onExport: () => exportToExcel(duePayments.map((p) => ({
            "المستأجر": p.contracts?.tenants?.full_name || "-",
            "الوحدة": `${p.contracts?.units?.title || "-"} - ${p.contracts?.units?.number || ""}`,
            "المبلغ": p.amount,
            "تاريخ الاستحقاق": p.payment_date
          })), "تقرير_الدفعات_المستحقة") }),
          duePayments.length ? /* @__PURE__ */ jsxRuntimeExports.jsx(DataTable, { columns: paymentColumns, rows: duePayments }) : /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyTable, { msg: "لا توجد دفعات مستحقة." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeader, { title: `سجل التحصيلات (${collectedPayments.length})`, onExport: () => exportToExcel(collectedPayments.map((p) => ({
            "الإيصال": p.receipt_number,
            "المستأجر": p.contracts?.tenants?.full_name || "-",
            "المبلغ": p.amount,
            "التاريخ": p.payment_date,
            "الطريقة": p.payment_method
          })), "تقرير_التحصيلات") }),
          collectedPayments.length ? /* @__PURE__ */ jsxRuntimeExports.jsx(DataTable, { columns: paymentColumns, rows: collectedPayments }) : /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyTable, { msg: "لا توجد تحصيلات مسجلة." })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsContent, { value: "contracts", className: "space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeader, { title: `عقود تنتهي خلال 60 يوم (${expiringContracts.length})`, onExport: exportExpiring }),
          expiringContracts.length ? /* @__PURE__ */ jsxRuntimeExports.jsx(DataTable, { columns: contractColumns, rows: expiringContracts }) : /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyTable, { msg: "لا توجد عقود تنتهي خلال 60 يوم." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeader, { title: `العقود المنتهية (${expiredContracts.length})`, onExport: () => exportToExcel(expiredContracts.map((c) => ({
            "رقم العقد": c.number,
            "المستأجر": c.tenants?.full_name || "-",
            "الوحدة": `${c.units?.title || "-"} - ${c.units?.number || ""}`,
            "تاريخ الانتهاء": c.end_date,
            "الإيجار": c.rent_amount
          })), "تقرير_العقود_المنتهية") }),
          expiredContracts.length ? /* @__PURE__ */ jsxRuntimeExports.jsx(DataTable, { columns: contractColumns, rows: expiredContracts }) : /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyTable, { msg: "لا توجد عقود منتهية." })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsContent, { value: "units", className: "space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeader, { title: `الوحدات الشاغرة (${vacantUnits.length})`, onExport: exportVacant }),
          vacantUnits.length ? /* @__PURE__ */ jsxRuntimeExports.jsx(DataTable, { columns: unitColumns, rows: vacantUnits }) : /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyTable, { msg: "لا توجد وحدات شاغرة." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeader, { title: `وحدات تحت الصيانة (${maintenanceUnits.length})`, onExport: () => exportToExcel(maintenanceUnits.map((u) => ({
            "رقم الوحدة": u.number,
            "العقار": u.title,
            "النوع": u.type,
            "المدينة": u.city || "-",
            "الإيجار": u.rent_price
          })), "تقرير_وحدات_الصيانة") }),
          maintenanceUnits.length ? /* @__PURE__ */ jsxRuntimeExports.jsx(DataTable, { columns: unitColumns, rows: maintenanceUnits }) : /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyTable, { msg: "لا توجد وحدات تحت الصيانة." })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsContent, { value: "maintenance", className: "space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeader, { title: `طلبات الصيانة المعلقة (${pendingMaint.length})`, onExport: exportMaintenance }),
          pendingMaint.length ? /* @__PURE__ */ jsxRuntimeExports.jsx(DataTable, { columns: maintenanceColumns, rows: pendingMaint }) : /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyTable, { msg: "لا توجد طلبات صيانة معلقة." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeader, { title: `كل طلبات الصيانة (${maintenance.length})`, onExport: () => exportToExcel(maintenance.map((m) => ({
            "رقم الطلب": m.number,
            "الوحدة": m.units ? `${m.units.title} - ${m.units.number || ""}` : "-",
            "النوع": m.type,
            "الوصف": m.description,
            "الأولوية": m.priority,
            "الحالة": m.status
          })), "تقرير_الصيانة_الكامل") }),
          maintenance.length ? /* @__PURE__ */ jsxRuntimeExports.jsx(DataTable, { columns: maintenanceColumns, rows: maintenance }) : /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyTable, { msg: "لا توجد طلبات صيانة." })
        ] })
      ] })
    ] }) })
  ] });
}
export {
  Reports as component
};
