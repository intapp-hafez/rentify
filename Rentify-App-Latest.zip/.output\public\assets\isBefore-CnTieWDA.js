import{t}from"./AppLayout-BU7NLMyW.js";function i(o,r){return+t(o)<+t(r)}export{i};
