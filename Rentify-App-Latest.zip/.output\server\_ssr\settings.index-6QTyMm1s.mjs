import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { C as Card } from "./card-RGlIzTYo.mjs";
import { B as Button } from "./button-DL752WFK.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { L as Label } from "./label-JU3yqRBo.mjs";
import { S as StatusBadge } from "./StatusBadge-AJi_pDVS.mjs";
import { u as useAuth, s as supabase } from "./router-C7nVfvJ9.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { a as useQueryClient, u as useQuery, b as useMutation } from "../_libs/tanstack__react-query.mjs";
import { u as updateSetting, g as getAllSettings } from "./settings-DVH_T3OS.mjs";
import { O as Mail, Q as Save, f as LogOut, K as KeyRound, l as Check, t as Pencil, X, P as Plus } from "../_libs/lucide-react.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
function EditableList({
  title,
  settingKey,
  items,
  onSave,
  saving
}) {
  const [list, setList] = reactExports.useState(items);
  const [newItem, setNewItem] = reactExports.useState("");
  const [editIdx, setEditIdx] = reactExports.useState(null);
  const [editVal, setEditVal] = reactExports.useState("");
  const isDirty = JSON.stringify(list) !== JSON.stringify(items);
  const addItem = () => {
    const trimmed = newItem.trim();
    if (!trimmed || list.includes(trimmed)) return;
    setList([...list, trimmed]);
    setNewItem("");
  };
  const removeItem = (idx) => setList(list.filter((_, i) => i !== idx));
  const startEdit = (idx) => {
    setEditIdx(idx);
    setEditVal(list[idx]);
  };
  const confirmEdit = () => {
    if (editIdx === null) return;
    const trimmed = editVal.trim();
    if (!trimmed) return;
    const updated = [...list];
    updated[editIdx] = trimmed;
    setList(updated);
    setEditIdx(null);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-bold text-foreground", children: [
        title,
        " ",
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-sm font-normal text-muted-foreground", children: [
          "(",
          list.length,
          ")"
        ] })
      ] }),
      isDirty && /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", className: "gap-1", onClick: () => onSave(settingKey, list), disabled: saving, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "h-3.5 w-3.5" }),
        " ",
        saving ? "جارٍ الحفظ..." : "حفظ"
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-3 flex flex-wrap gap-2", children: list.map((item, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "group flex items-center gap-1 rounded-full border border-border bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground", children: editIdx === idx ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("input", { className: "w-20 bg-transparent text-xs outline-none", value: editVal, onChange: (e) => setEditVal(e.target.value), onKeyDown: (e) => e.key === "Enter" && confirmEdit(), autoFocus: true }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: confirmEdit, className: "text-success hover:text-success/80", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "h-3 w-3" }) })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: item }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => startEdit(idx), className: "hidden text-muted-foreground hover:text-foreground group-hover:inline-flex", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-3 w-3" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => removeItem(idx), className: "hidden text-destructive hover:text-destructive/80 group-hover:inline-flex", children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-3 w-3" }) })
    ] }) }, idx)) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: newItem, onChange: (e) => setNewItem(e.target.value), onKeyDown: (e) => e.key === "Enter" && addItem(), placeholder: `إضافة ${title.split(" ")[0]}...`, className: "h-8 text-sm" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant: "outline", className: "gap-1 shrink-0", onClick: addItem, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-3.5 w-3.5" }),
        " إضافة"
      ] })
    ] })
  ] });
}
function SettingsIndex() {
  const {
    user
  } = useAuth();
  const queryClient = useQueryClient();
  const [fullName, setFullName] = reactExports.useState(user?.user_metadata?.full_name || "");
  const [phone, setPhone] = reactExports.useState(user?.user_metadata?.phone || "");
  const [profileSaving, setProfileSaving] = reactExports.useState(false);
  const [newPassword, setNewPassword] = reactExports.useState("");
  const [confirmPassword, setConfirmPassword] = reactExports.useState("");
  const [passwordSaving, setPasswordSaving] = reactExports.useState(false);
  const {
    data: settings,
    isLoading
  } = useQuery({
    queryKey: ["settings"],
    queryFn: getAllSettings
  });
  const saveMutation = useMutation({
    mutationFn: ({
      key,
      value
    }) => updateSetting(key, value),
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["settings"]
      });
      toast.success("تم حفظ الإعداد بنجاح");
    },
    onError: (error) => toast.error(error.message)
  });
  const handleSaveProfile = async () => {
    setProfileSaving(true);
    const {
      error
    } = await supabase.auth.updateUser({
      data: {
        full_name: fullName,
        phone
      }
    });
    setProfileSaving(false);
    if (error) toast.error(error.message);
    else toast.success("تم حفظ بيانات الحساب بنجاح");
  };
  const handleChangePassword = async () => {
    if (!newPassword || newPassword.length < 6) {
      toast.error("كلمة المرور يجب أن تكون 6 أحرف على الأقل");
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error("كلمتا المرور غير متطابقتين");
      return;
    }
    setPasswordSaving(true);
    const {
      error
    } = await supabase.auth.updateUser({
      password: newPassword
    });
    setPasswordSaving(false);
    if (error) toast.error(error.message);
    else {
      toast.success("تم تغيير كلمة المرور بنجاح، يرجى تسجيل الدخول مجدداً");
      setNewPassword("");
      setConfirmPassword("");
      await handleSignOut();
    }
  };
  const handleSignOut = async () => {
    await supabase.auth.signOut();
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mb-4 font-bold text-foreground", children: "بيانات الحساب" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 gap-4 md:grid-cols-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "mb-1.5 block text-sm", children: "الاسم الكامل" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: fullName, onChange: (e) => setFullName(e.target.value), placeholder: "اسمك الكامل" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "mb-1.5 block text-sm", children: "رقم الهاتف" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: phone, onChange: (e) => setPhone(e.target.value), placeholder: "رقم هاتفك" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "mb-1.5 block text-sm", children: "البريد الإلكتروني" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 rounded-lg border border-border bg-muted px-3 py-2 text-sm text-muted-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { className: "h-4 w-4 shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: user?.email || "غير مسجل" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "mb-1.5 block text-sm", children: "معرف المستخدم" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 rounded-lg border border-border bg-muted px-3 py-2 text-xs text-muted-foreground font-mono truncate", children: user?.id || "-" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { className: "gap-1", onClick: handleSaveProfile, disabled: profileSaving, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "h-4 w-4" }),
          " ",
          profileSaving ? "جارٍ الحفظ..." : "حفظ التغييرات"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", className: "gap-1 text-destructive hover:text-destructive", onClick: handleSignOut, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "h-4 w-4" }),
          " تسجيل الخروج"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "mt-5 p-5 border-destructive/20 bg-destructive/5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "mb-4 font-bold text-foreground flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(KeyRound, { className: "h-5 w-5 text-destructive" }),
        "تغيير كلمة المرور"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 gap-4 md:grid-cols-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "mb-1.5 block text-sm", children: "كلمة المرور الجديدة" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "password", value: newPassword, onChange: (e) => setNewPassword(e.target.value), placeholder: "••••••••" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "mb-1.5 block text-sm", children: "تأكيد كلمة المرور" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "password", value: confirmPassword, onChange: (e) => setConfirmPassword(e.target.value), placeholder: "••••••••" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4 flex gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { className: "gap-1 bg-destructive hover:bg-destructive/90 text-destructive-foreground", onClick: handleChangePassword, disabled: passwordSaving || !newPassword || !confirmPassword, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "h-4 w-4" }),
        " ",
        passwordSaving ? "جارٍ الحفظ..." : "تحديث كلمة المرور"
      ] }) })
    ] }),
    isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-5 flex justify-center p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-8 w-8 animate-spin rounded-full border-b-2 border-primary" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(EditableList, { title: "المحافظات", settingKey: "governorates", items: settings?.governorates || [], onSave: (key, value) => saveMutation.mutate({
        key,
        value
      }), saving: saveMutation.isPending }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(EditableList, { title: "أنواع العقارات", settingKey: "property_types", items: settings?.property_types || [], onSave: (key, value) => saveMutation.mutate({
        key,
        value
      }), saving: saveMutation.isPending }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mb-4 font-bold text-foreground", children: "حالات الوحدات" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-4 flex flex-wrap gap-3", children: (settings?.unit_statuses || ["متاح", "مؤجر", "محجوز", "تحت الصيانة", "متأخر بالسداد", "عقد منتهي"]).map((s) => /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { status: s }, s)) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "حالات الوحدات محددة مسبقاً وتُستخدم في جميع أنحاء النظام لضمان التوافق." })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-6 text-center text-xs text-muted-foreground", children: "Developer: Mr. Hafez Rahim +201007419344 — Rentify v1.0.0" })
  ] });
}
export {
  SettingsIndex as component
};
