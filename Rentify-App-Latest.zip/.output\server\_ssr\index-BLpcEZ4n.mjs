import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { e as useNavigate } from "../_libs/tanstack__react-router.mjs";
import { B as Button } from "./button-DL752WFK.mjs";
import { n as Building2, N as ShieldCheck, C as ChartColumn } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/tailwind-merge.mjs";
function Index() {
  const navigate = useNavigate();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid min-h-screen lg:grid-cols-2", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative hidden flex-col justify-between overflow-hidden bg-primary p-12 text-primary-foreground lg:flex", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -left-24 -top-24 h-80 w-80 rounded-full bg-accent/30 blur-3xl" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -bottom-32 -right-10 h-96 w-96 rounded-full bg-gold/20 blur-3xl" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: "/logo.png", alt: "Rentify", className: "h-12 w-12 rounded-xl bg-white p-1", width: 48, height: 48 }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-2xl font-extrabold", children: "Rentify" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-4xl font-extrabold leading-tight", children: "نظام Rentify لإدارة العقارات" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "max-w-md text-lg text-primary-foreground/80", children: "إدارة العقارات والإيجارات بسهولة واحترافية — عقود، تحصيلات، صيانة وتقارير ذكية في نظام واحد." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid max-w-md grid-cols-3 gap-4 pt-4", children: [{
          icon: Building2,
          t: "العقارات"
        }, {
          icon: ShieldCheck,
          t: "العقود"
        }, {
          icon: ChartColumn,
          t: "التقارير"
        }].map((f) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl bg-white/10 p-4 text-center backdrop-blur", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(f.icon, { className: "mx-auto mb-2 h-6 w-6 text-gold" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-semibold", children: f.t })
        ] }, f.t)) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "relative text-sm text-primary-foreground/60", children: "© 2026 Rentify — جميع الحقوق محفوظة" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-center bg-background p-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: (e) => {
      e.preventDefault();
      navigate({
        to: "/dashboard"
      });
    }, className: "w-full max-w-sm space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-2 flex items-center gap-3 lg:hidden", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: "/logo.png", alt: "Rentify", className: "h-10 w-10 rounded-xl", width: 40, height: 40 }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xl font-extrabold", children: "Rentify" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-2xl font-extrabold text-foreground", children: "تسجيل الدخول" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: "مرحباً بعودتك، أدخل بياناتك للمتابعة" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-sm font-semibold text-foreground", children: "البريد الإلكتروني" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "email", defaultValue: "admin@rentify.app", className: "h-11 w-full rounded-lg border border-input bg-background px-3 text-sm outline-none focus:border-ring focus:ring-2 focus:ring-ring/20" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-sm font-semibold text-foreground", children: "كلمة المرور" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "password", defaultValue: "123456", className: "h-11 w-full rounded-lg border border-input bg-background px-3 text-sm outline-none focus:border-ring focus:ring-2 focus:ring-ring/20" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "submit", className: "h-11 w-full text-base", children: "تسجيل الدخول" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", className: "block w-full text-center text-sm text-accent hover:underline", children: "نسيت كلمة المرور؟" })
    ] }) })
  ] });
}
export {
  Index as component
};
