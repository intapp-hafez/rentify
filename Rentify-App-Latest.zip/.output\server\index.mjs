globalThis.__nitro_main__ = import.meta.url;
import { N as NodeResponse, s as serve } from "./_libs/srvx.mjs";
import { d as defineHandler, H as HTTPError, t as toEventHandler, a as defineLazyEventHandler, b as H3Core } from "./_libs/h3.mjs";
import { d as decodePath, w as withLeadingSlash, a as withoutTrailingSlash, j as joinURL } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import "node:http";
import "node:stream";
import "node:stream/promises";
import "node:https";
import "node:http2";
import "./_libs/rou3.mjs";
function lazyService(loader) {
  let promise, mod;
  return {
    fetch(req) {
      if (mod) {
        return mod.fetch(req);
      }
      if (!promise) {
        promise = loader().then((_mod) => mod = _mod.default || _mod);
      }
      return promise.then((mod2) => mod2.fetch(req));
    }
  };
}
const services = {
  ["ssr"]: lazyService(() => import("./_ssr/index.mjs"))
};
globalThis.__nitro_vite_envs__ = services;
const headers = ((m) => function headersRouteRule(event) {
  for (const [key2, value] of Object.entries(m.options || {})) {
    event.res.headers.set(key2, value);
  }
});
const assets = {
  "/.htaccess": {
    "type": "text/plain; charset=utf-8",
    "etag": '"d6-uCGM/aWSby4OafxcQnLurhDUWcE"',
    "mtime": "2026-07-07T06:24:35.259Z",
    "size": 214,
    "path": "../public/.htaccess"
  },
  "/assets/addYears-C3xCgZvf.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"8c-ThZFgNHHPfsll8rNVs37RduI1WA"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 140,
    "path": "../public/assets/addYears-C3xCgZvf.js"
  },
  "/robots.txt": {
    "type": "text/plain; charset=utf-8",
    "etag": '"16-iUOtJ2RsHfdY9DoQxaq0wz1LZCU"',
    "mtime": "2026-07-05T00:53:04.000Z",
    "size": 22,
    "path": "../public/robots.txt"
  },
  "/rentify.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": '"e8e8-FXFXsQVeCiJWpLJ5/SCzrzv6YNY"',
    "mtime": "2026-07-06T16:31:33.376Z",
    "size": 59624,
    "path": "../public/rentify.ico"
  },
  "/favicon.png": {
    "type": "image/png",
    "etag": '"66ca1-HrdoQV9cIHmnRiDzMPV3ov/zyjI"',
    "mtime": "2026-07-05T11:41:33.192Z",
    "size": 421025,
    "path": "../public/favicon.png"
  },
  "/assets/building-2-CZ0wNK3i.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"186-yimq03QttouOLMwBzbyYc9hxCmU"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 390,
    "path": "../public/assets/building-2-CZ0wNK3i.js"
  },
  "/assets/AppLayout-DWpWrGGj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"238da-Xzm0m72JPHf0e/8qetSuapsk4uM"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 145626,
    "path": "../public/assets/AppLayout-DWpWrGGj.js"
  },
  "/assets/button-BwK2P02n.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1122-d/hqPWLS6F5xnOzr8TsEndtupoY"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 4386,
    "path": "../public/assets/button-BwK2P02n.js"
  },
  "/assets/arrow-down-up-DUpfuMY8.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"101-HjIVYAsZUZpxgMD2p/gowmZZj3w"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 257,
    "path": "../public/assets/arrow-down-up-DUpfuMY8.js"
  },
  "/assets/card-BLGfACTC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3e9-u/GWDQ+DGVD/Sg1dD+mA6taL4f4"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 1001,
    "path": "../public/assets/card-BLGfACTC.js"
  },
  "/assets/ConfirmDelete-Y5iKnt-I.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"83ce-AXuldoLgjJsmftoVXLAQ/hhiTIg"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 33742,
    "path": "../public/assets/ConfirmDelete-Y5iKnt-I.js"
  },
  "/assets/chart-column-DkbVC4dg.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"102-vDb25OKGCJAMXVEhSJfzsCa+kVA"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 258,
    "path": "../public/assets/chart-column-DkbVC4dg.js"
  },
  "/assets/contracts-CigTa23b.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5f-cuQT4lFifLZEyRelN/d5IkNAsho"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 95,
    "path": "../public/assets/contracts-CigTa23b.js"
  },
  "/assets/contracts-DxFVXsiI.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"334-A5o5/MMl5LvsCXMlE//xvO3Zhxo"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 820,
    "path": "../public/assets/contracts-DxFVXsiI.js"
  },
  "/assets/contracts.index-DrCnCVR3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2072-21q4P5m0bd/AVpt6rlBsY7ycYXQ"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 8306,
    "path": "../public/assets/contracts.index-DrCnCVR3.js"
  },
  "/assets/createLucideIcon-GLBMnevz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"705a-nkD2+ainIh6kLmqsHoRWaD1cB60"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 28762,
    "path": "../public/assets/createLucideIcon-GLBMnevz.js"
  },
  "/assets/dashboard-CBH4YypY.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2022-LDml2gKJkhtTaEb8Aq3E9HzDyhY"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 8226,
    "path": "../public/assets/dashboard-CBH4YypY.js"
  },
  "/assets/deposits-BYJcEehr.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"d89-ZbOghhkTqlNPFwLEznsRuutnkTk"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 3465,
    "path": "../public/assets/deposits-BYJcEehr.js"
  },
  "/assets/deposits-L_Kfwkex.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2e5-ZjYAM/d2RhdbcGi2DQ0Dy/8U5WU"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 741,
    "path": "../public/assets/deposits-L_Kfwkex.js"
  },
  "/assets/DataTable-DmGnYc_X.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"961-vIrYqXIsPGScb5pNbaG1pf36hTM"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 2401,
    "path": "../public/assets/DataTable-DmGnYc_X.js"
  },
  "/assets/download-DBQeG333.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"f4-uLFrb6/svwOnv5kAdi+PcRHCHMQ"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 244,
    "path": "../public/assets/download-DBQeG333.js"
  },
  "/assets/excel-B_OhYyJx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"67cc3-x6l3rLs9UY1krW08cZ6bsVhBnYM"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 425155,
    "path": "../public/assets/excel-B_OhYyJx.js"
  },
  "/favicon1.png": {
    "type": "image/png",
    "etag": '"8a080-kq0z09uyP2kxj00KbOLDWNLRJZ4"',
    "mtime": "2026-07-05T00:53:04.000Z",
    "size": 565376,
    "path": "../public/favicon1.png"
  },
  "/logo.png": {
    "type": "image/png",
    "etag": '"871bc-/OQjtGLNFqOF/JUZF46kOgZ7wzk"',
    "mtime": "2026-07-05T00:53:04.000Z",
    "size": 553404,
    "path": "../public/logo.png"
  },
  "/assets/contracts._id-BswI6eWb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"93829-AIKdncGXixNUdd5EK+OiitB/Bhk"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 604201,
    "path": "../public/assets/contracts._id-BswI6eWb.js"
  },
  "/assets/index-lHSZbx4y.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"49f8-eBIAwetbo/0CfSy2MnpGTHmZC8g"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 18936,
    "path": "../public/assets/index-lHSZbx4y.js"
  },
  "/assets/file-spreadsheet-l9oc7Gzz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1b3-jshLmCkXRp/HiBErLIb7+iJ6/2g"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 435,
    "path": "../public/assets/file-spreadsheet-l9oc7Gzz.js"
  },
  "/assets/index-BmS8KqAA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"27b9-1L/Tj+4sqm5DtGqr8Eg81qJXOAM"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 10169,
    "path": "../public/assets/index-BmS8KqAA.js"
  },
  "/assets/index-qwtQKhOm.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"e28-RizgWDvu0vbjsWYOXUf0flbFR6s"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 3624,
    "path": "../public/assets/index-qwtQKhOm.js"
  },
  "/assets/input-Crsp1SFh.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"259-75ikJe81/mftfDLZpBIdhiTLq5Y"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 601,
    "path": "../public/assets/input-Crsp1SFh.js"
  },
  "/assets/index.es-BxLNXUFb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"26ee4-znDnKb1di2iEqzbOIOrtwK8ccEk"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 159460,
    "path": "../public/assets/index.es-BxLNXUFb.js"
  },
  "/assets/KpiCard-BmXN7bPR.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3dd-Lio20Ab/kXCTyrpHn0oNK0vnU2M"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 989,
    "path": "../public/assets/KpiCard-BmXN7bPR.js"
  },
  "/assets/isBefore-CtGlDlBv.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"54-7R/ejDDfLdC+eBziPVZHqdWIL3Q"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 84,
    "path": "../public/assets/isBefore-CtGlDlBv.js"
  },
  "/assets/label-FNXll8Jc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"bd5-PE2wNx6F3fo0G37uwyIUqh6Aj3U"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 3029,
    "path": "../public/assets/label-FNXll8Jc.js"
  },
  "/assets/login-DRFQzWnD.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"82e-K7BAIQ7uoJa1qXfiim0dq0DW+o0"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 2094,
    "path": "../public/assets/login-DRFQzWnD.js"
  },
  "/assets/maintenance-Bod_-xsY.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"18c8-9uDvCgsQY3sJZYf/yaSW3iVKOfg"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 6344,
    "path": "../public/assets/maintenance-Bod_-xsY.js"
  },
  "/assets/maintenance-BhO3nIjw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2a0-DJ0m0sGqPOJdmIzEYneZc4uLdQ4"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 672,
    "path": "../public/assets/maintenance-BhO3nIjw.js"
  },
  "/assets/payments-D0_jB0TZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"29af-PeeJHBf0vCqIm5tnht77kKNZQpQ"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 10671,
    "path": "../public/assets/payments-D0_jB0TZ.js"
  },
  "/assets/notifications-Blc4uPtk.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"13d8-JAhWFmPDd1mJmAlnvrLcBdKHt0c"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 5080,
    "path": "../public/assets/notifications-Blc4uPtk.js"
  },
  "/assets/payments-DL0sfu_r.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2b0-njXP3oYYtpio8hehIR4QSWDw7zk"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 688,
    "path": "../public/assets/payments-DL0sfu_r.js"
  },
  "/assets/PayNowDialog-CC12BwTN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1310-rjUXrNf83UgZcTRBlTWEdIv7TWw"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 4880,
    "path": "../public/assets/PayNowDialog-CC12BwTN.js"
  },
  "/assets/purify.es-VaSPOPhr.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"7032-uZQ20bhcE4YqMv2bJ83N97r01ek"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 28722,
    "path": "../public/assets/purify.es-VaSPOPhr.js"
  },
  "/assets/reports-C2u4ND4n.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"4093-3OkoScAE+NyC7192KRdb9lKhTAs"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 16531,
    "path": "../public/assets/reports-C2u4ND4n.js"
  },
  "/assets/settings-BWG-GlTU.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"258-3PttviVDlIpphyUoN1N6c6Nl1Qg"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 600,
    "path": "../public/assets/settings-BWG-GlTU.js"
  },
  "/assets/settings-D70hl81H.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"43c-1Rh+leuG5LbrQVdUHHfKBXkWsZc"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 1084,
    "path": "../public/assets/settings-D70hl81H.js"
  },
  "/assets/settings.about-CkRflykD.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"f75-NlxL+4CIaqFQMbbowThVkx3kX+w"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 3957,
    "path": "../public/assets/settings.about-CkRflykD.js"
  },
  "/assets/index-BDl6EVWd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"8e31d-0Nd4OA5mO0b2jfAJH5MeJpf7bFE"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 582429,
    "path": "../public/assets/index-BDl6EVWd.js"
  },
  "/assets/settings.index-DDyRne2J.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1fae-AFCLVUuBX2BGTZ/1QPQGDgrvKxY"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 8110,
    "path": "../public/assets/settings.index-DDyRne2J.js"
  },
  "/assets/shield-check-B2qvGl9V.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"14c-2As0Ax99o9nsubSNVadgDKRhVn4"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 332,
    "path": "../public/assets/shield-check-B2qvGl9V.js"
  },
  "/assets/StatusBadge-Vcl6tdgy.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"140-Dn3U2EF0nuAp0B9yF5I13PBKHR8"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 320,
    "path": "../public/assets/StatusBadge-Vcl6tdgy.js"
  },
  "/assets/styles-DJz_HUkV.css": {
    "type": "text/css; charset=utf-8",
    "etag": '"1794e-Y2ajGYPgWQ4Hkk7Js/j6L1yNXgQ"',
    "mtime": "2026-07-29T21:10:38.432Z",
    "size": 96590,
    "path": "../public/assets/styles-DJz_HUkV.css"
  },
  "/assets/tenants-B0fnBSMg.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"266-GpHky1R/E3CRp9pC7qzzNNNBWao"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 614,
    "path": "../public/assets/tenants-B0fnBSMg.js"
  },
  "/assets/tenants-BEN3gSKX.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5f-cuQT4lFifLZEyRelN/d5IkNAsho"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 95,
    "path": "../public/assets/tenants-BEN3gSKX.js"
  },
  "/assets/tenants.index-C8-xePEH.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1b43-PIZmyzOaHcyJiKTB/DJeuWrFU2k"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 6979,
    "path": "../public/assets/tenants.index-C8-xePEH.js"
  },
  "/assets/tenants._id-vLSzmYVs.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"258c-6NNzveYcdHbyxOUh3kxCBqvGPa8"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 9612,
    "path": "../public/assets/tenants._id-vLSzmYVs.js"
  },
  "/assets/trending-down-CVrlRjwL.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"be-ywm15/4Reha+ql35FNwFkHuQDOE"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 190,
    "path": "../public/assets/trending-down-CVrlRjwL.js"
  },
  "/assets/units-BEN3gSKX.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5f-cuQT4lFifLZEyRelN/d5IkNAsho"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 95,
    "path": "../public/assets/units-BEN3gSKX.js"
  },
  "/assets/units-BzvLxgKo.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"254-IaKX0Quc17zf8KcUbU7cm1u3c38"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 596,
    "path": "../public/assets/units-BzvLxgKo.js"
  },
  "/assets/units.index-DBy4Z7Iq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"20f6-/pSgXv277oREYPMkUg/eXOH+vbk"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 8438,
    "path": "../public/assets/units.index-DBy4Z7Iq.js"
  },
  "/assets/units._id-D4YOXoK3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"267d-X8+Iz+0bfCQ7mr6rcn7aj3KU5F0"',
    "mtime": "2026-07-29T21:10:38.453Z",
    "size": 9853,
    "path": "../public/assets/units._id-D4YOXoK3.js"
  }
};
function readAsset(id) {
  const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
  return promises.readFile(resolve(serverDir, assets[id].path));
}
const publicAssetBases = {};
function isPublicAssetURL(id = "") {
  if (assets[id]) {
    return true;
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) {
      return true;
    }
  }
  return false;
}
function getAsset(id) {
  return assets[id];
}
const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = {
  gzip: ".gz",
  br: ".br",
  zstd: ".zst"
};
const _9YnzWg = defineHandler((event) => {
  if (event.req.method && !METHODS.has(event.req.method)) {
    return;
  }
  let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
  let asset;
  const encodingHeader = event.req.headers.get("accept-encoding") || "";
  const encodings = [...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      event.res.headers.delete("Cache-Control");
      throw new HTTPError({ status: 404 });
    }
    return;
  }
  if (encodings.length > 1) {
    event.res.headers.append("Vary", "Accept-Encoding");
  }
  const ifNotMatch = event.req.headers.get("if-none-match") === asset.etag;
  if (ifNotMatch) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  const ifModifiedSinceH = event.req.headers.get("if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  if (asset.type) {
    event.res.headers.set("Content-Type", asset.type);
  }
  if (asset.etag && !event.res.headers.has("ETag")) {
    event.res.headers.set("ETag", asset.etag);
  }
  if (asset.mtime && !event.res.headers.has("Last-Modified")) {
    event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !event.res.headers.has("Content-Encoding")) {
    event.res.headers.set("Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !event.res.headers.has("Content-Length")) {
    event.res.headers.set("Content-Length", asset.size.toString());
  }
  return readAsset(id);
});
const findRouteRules = /* @__PURE__ */ (() => {
  const $0 = [{ name: "headers", route: "/assets/**", handler: headers, options: { "cache-control": "public, max-age=31536000, immutable" } }];
  return (m, p) => {
    let r = [];
    if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
    let s = p.split("/"), l = s.length;
    if (l > 1) {
      if (s[1] === "assets") {
        r.unshift({ data: $0, params: { "_": s.slice(2).join("/") } });
      }
    }
    return r;
  };
})();
const _lazy_PFmFgc = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
const findRoute = /* @__PURE__ */ (() => {
  const data = { route: "/**", handler: _lazy_PFmFgc };
  return ((_m, p) => {
    return { data, params: { "_": p.slice(1) } };
  });
})();
const globalMiddleware = [
  toEventHandler(_9YnzWg)
].filter(Boolean);
const errorHandler$1 = (error, event) => {
  const res = defaultHandler(error, event);
  return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
  const unhandled = error.unhandled ?? !HTTPError.isError(error);
  const { status = 500, statusText = "" } = unhandled ? {} : error;
  if (status === 404) {
    const url = event.url || new URL(event.req.url);
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      return {
        status: 302,
        headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
      };
    }
  }
  const headers2 = new Headers(unhandled ? {} : error.headers);
  headers2.set("content-type", "application/json; charset=utf-8");
  const jsonBody = unhandled ? {
    status,
    unhandled: true
  } : typeof error.toJSON === "function" ? error.toJSON() : {
    status,
    statusText,
    message: error.message
  };
  return {
    status,
    statusText,
    headers: headers2,
    body: {
      error: true,
      ...jsonBody
    }
  };
}
const errorHandlers = [errorHandler$1];
async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      const response = await handler(error, event, { defaultHandler });
      if (response) {
        return response;
      }
    } catch (error2) {
      console.error(error2);
    }
  }
}
function createNitroApp() {
  const captureError = (error, errorCtx) => {
    if (errorCtx?.event) {
      const errors = errorCtx.event.req.context?.nitro?.errors;
      if (errors) {
        errors.push({ error, context: errorCtx });
      }
    }
  };
  const h3App = createH3App({
    onError(error, event) {
      return errorHandler(error, event);
    }
  });
  let appHandler = (req) => {
    req.context ||= {};
    req.context.nitro = req.context.nitro || { errors: [] };
    return h3App.fetch(req);
  };
  return {
    fetch: appHandler,
    h3: h3App,
    hooks: void 0,
    captureError
  };
}
function createH3App(config) {
  const h3App = new H3Core(config);
  h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
  h3App["~middleware"].push(...globalMiddleware);
  h3App["~getMiddleware"] = (event, route) => {
    const pathname = event.url.pathname;
    const method = event.req.method;
    const middleware = [];
    const routeRules = getRouteRules(method, pathname);
    event.context.routeRules = routeRules?.routeRules;
    if (routeRules?.routeRuleMiddleware.length) {
      middleware.push(...routeRules.routeRuleMiddleware);
    }
    middleware.push(...h3App["~middleware"]);
    if (route?.data?.middleware?.length) {
      middleware.push(...route.data.middleware);
    }
    return middleware;
  };
  return h3App;
}
const APP_ID = "default";
function useNitroApp() {
  let instance = useNitroApp._instance;
  if (instance) {
    return instance;
  }
  instance = useNitroApp._instance = createNitroApp();
  globalThis.__nitro__ = globalThis.__nitro__ || {};
  globalThis.__nitro__[APP_ID] = instance;
  return instance;
}
function getRouteRules(method, pathname) {
  const m = findRouteRules(method, pathname);
  if (!m?.length) {
    return { routeRuleMiddleware: [] };
  }
  const routeRules = {};
  for (const layer of m) {
    for (const rule of layer.data) {
      const currentRule = routeRules[rule.name];
      if (currentRule) {
        if (rule.options === false) {
          delete routeRules[rule.name];
          continue;
        }
        if (typeof currentRule.options === "object" && typeof rule.options === "object") {
          currentRule.options = {
            ...currentRule.options,
            ...rule.options
          };
        } else {
          currentRule.options = rule.options;
        }
        currentRule.route = rule.route;
        currentRule.params = {
          ...currentRule.params,
          ...layer.params
        };
      } else if (rule.options !== false) {
        routeRules[rule.name] = {
          ...rule,
          params: layer.params
        };
      }
    }
  }
  const middleware = [];
  const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
  for (const rule of orderedRules) {
    if (rule.options === false || !rule.handler) {
      continue;
    }
    middleware.push(rule.handler(rule));
  }
  return {
    routeRules,
    routeRuleMiddleware: middleware
  };
}
function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
  process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
  process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
const tracingSrvxPlugins = [];
const _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
const port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
const host = process.env.NITRO_HOST || process.env.HOST;
const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const nitroApp = useNitroApp();
serve({
  port,
  hostname: host,
  tls: cert && key ? {
    cert,
    key
  } : void 0,
  fetch: nitroApp.fetch,
  plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
const nodeServer = {};
export {
  nodeServer as default
};
