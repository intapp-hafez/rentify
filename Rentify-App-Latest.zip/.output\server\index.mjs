globalThis.__nitro_main__ = import.meta.url;
import { N as NodeResponse, s as serve } from "./_libs/srvx.mjs";
import { d as defineHandler, H as HTTPError, t as toEventHandler, a as defineLazyEventHandler, b as H3Core } from "./_libs/h3.mjs";
import { d as decodePath, w as withLeadingSlash, a as withoutTrailingSlash, j as joinURL } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import "node:http";
import "node:stream";
import "node:stream/promises";
import "node:https";
import "node:http2";
import "./_libs/rou3.mjs";
function lazyService(loader) {
  let promise, mod;
  return {
    fetch(req) {
      if (mod) {
        return mod.fetch(req);
      }
      if (!promise) {
        promise = loader().then((_mod) => mod = _mod.default || _mod);
      }
      return promise.then((mod2) => mod2.fetch(req));
    }
  };
}
const services = {
  ["ssr"]: lazyService(() => import("./_ssr/index.mjs"))
};
globalThis.__nitro_vite_envs__ = services;
const headers = ((m) => function headersRouteRule(event) {
  for (const [key2, value] of Object.entries(m.options || {})) {
    event.res.headers.set(key2, value);
  }
});
const assets = {
  "/.htaccess": {
    "type": "text/plain; charset=utf-8",
    "etag": '"d6-uCGM/aWSby4OafxcQnLurhDUWcE"',
    "mtime": "2026-07-07T06:24:35.259Z",
    "size": 214,
    "path": "../public/.htaccess"
  },
  "/favicon.png": {
    "type": "image/png",
    "etag": '"66ca1-HrdoQV9cIHmnRiDzMPV3ov/zyjI"',
    "mtime": "2026-07-05T11:41:33.192Z",
    "size": 421025,
    "path": "../public/favicon.png"
  },
  "/assets/addYears-DjtnMsf5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"8c-yLGxU7RYRr8M44DQUqhVTKiAeyo"',
    "mtime": "2026-09-16T21:54:36.988Z",
    "size": 140,
    "path": "../public/assets/addYears-DjtnMsf5.js"
  },
  "/rentify.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": '"e8e8-FXFXsQVeCiJWpLJ5/SCzrzv6YNY"',
    "mtime": "2026-07-06T16:31:33.376Z",
    "size": 59624,
    "path": "../public/rentify.ico"
  },
  "/assets/AppLayout-BU7NLMyW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2390e-j81AGsURIMH0aLjN0bWa9lrLGCw"',
    "mtime": "2026-09-16T21:54:36.990Z",
    "size": 145678,
    "path": "../public/assets/AppLayout-BU7NLMyW.js"
  },
  "/assets/arrow-down-up-DyzZzSW8.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"101-5L8P03xpmuDzixJtLhvWMEE4ojg"',
    "mtime": "2026-09-16T21:54:36.988Z",
    "size": 257,
    "path": "../public/assets/arrow-down-up-DyzZzSW8.js"
  },
  "/assets/building-2-B11KnxlP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"186-AN4W1MMhTwcqMNIJUfx63bKfAxw"',
    "mtime": "2026-09-16T21:54:36.989Z",
    "size": 390,
    "path": "../public/assets/building-2-B11KnxlP.js"
  },
  "/assets/button-CqGPq8o2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1122-sATOsrpG2rNvv3fwFUs3nhANEzE"',
    "mtime": "2026-09-16T21:54:36.991Z",
    "size": 4386,
    "path": "../public/assets/button-CqGPq8o2.js"
  },
  "/assets/card-BwYw8gIa.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3e9-D2R8m0Dq7nEh1eQ+V6eSedKfpZM"',
    "mtime": "2026-09-16T21:54:36.991Z",
    "size": 1001,
    "path": "../public/assets/card-BwYw8gIa.js"
  },
  "/assets/chevron-right-Ci28IZMq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"e0-KrsbejFyya1GOBuvE1oqz0E2qZM"',
    "mtime": "2026-09-16T21:54:36.990Z",
    "size": 224,
    "path": "../public/assets/chevron-right-Ci28IZMq.js"
  },
  "/assets/ConfirmDelete-DNfs0Rlp.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"833a-RhQ0DWNvWBNGyDUNgoYKfAQrxhY"',
    "mtime": "2026-09-16T21:54:36.990Z",
    "size": 33594,
    "path": "../public/assets/ConfirmDelete-DNfs0Rlp.js"
  },
  "/assets/contracts-C7wltNFS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"afb-MHtirk7VrGkP+PkQWVimAAbDMiM"',
    "mtime": "2026-09-16T21:54:36.990Z",
    "size": 2811,
    "path": "../public/assets/contracts-C7wltNFS.js"
  },
  "/assets/contracts-C9bHtjRX.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5f-Ur5Fa4VlMdJXI7pmMr11WwM+Tsc"',
    "mtime": "2026-09-16T21:54:36.987Z",
    "size": 95,
    "path": "../public/assets/contracts-C9bHtjRX.js"
  },
  "/assets/contracts.index-DgVZ3zjs.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2ddf-eZJHDfHuTdlKDunf4Qmq6OtqZ4A"',
    "mtime": "2026-09-16T21:54:36.989Z",
    "size": 11743,
    "path": "../public/assets/contracts.index-DgVZ3zjs.js"
  },
  "/assets/createLucideIcon-D4T147QG.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"705a-rSz6yp+fKyZlXQzDtjBh6MYzHd4"',
    "mtime": "2026-09-16T21:54:36.991Z",
    "size": 28762,
    "path": "../public/assets/createLucideIcon-D4T147QG.js"
  },
  "/assets/DataTable-HwexSERM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"d7c-mGPUsQnLsld7cxuEGtfWe2V3mdk"',
    "mtime": "2026-09-16T21:54:36.989Z",
    "size": 3452,
    "path": "../public/assets/DataTable-HwexSERM.js"
  },
  "/assets/deposits-Dm6HZb_w.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2e5-uTT43jq0V8bV2txfVOtN2t71rsc"',
    "mtime": "2026-09-16T21:54:36.989Z",
    "size": 741,
    "path": "../public/assets/deposits-Dm6HZb_w.js"
  },
  "/robots.txt": {
    "type": "text/plain; charset=utf-8",
    "etag": '"16-iUOtJ2RsHfdY9DoQxaq0wz1LZCU"',
    "mtime": "2026-07-05T00:53:04.000Z",
    "size": 22,
    "path": "../public/robots.txt"
  },
  "/assets/dashboard-xbRHbH6P.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2023-cUUTtAgSUt7nkQU1kTuMai0m8ZQ"',
    "mtime": "2026-09-16T21:54:36.987Z",
    "size": 8227,
    "path": "../public/assets/dashboard-xbRHbH6P.js"
  },
  "/favicon1.png": {
    "type": "image/png",
    "etag": '"8a080-kq0z09uyP2kxj00KbOLDWNLRJZ4"',
    "mtime": "2026-07-05T00:53:04.000Z",
    "size": 565376,
    "path": "../public/favicon1.png"
  },
  "/logo.png": {
    "type": "image/png",
    "etag": '"871bc-/OQjtGLNFqOF/JUZF46kOgZ7wzk"',
    "mtime": "2026-07-05T00:53:04.000Z",
    "size": 553404,
    "path": "../public/logo.png"
  },
  "/assets/contracts._id-BDzrlV1L.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"93afc-oDVjrA9LzvIzbEQwGdeR4Pn+OpY"',
    "mtime": "2026-09-16T21:54:36.995Z",
    "size": 604924,
    "path": "../public/assets/contracts._id-BDzrlV1L.js"
  },
  "/rentify-slider.png": {
    "type": "image/png",
    "etag": '"1bd15d-yIq6rznT6puyf70e8/5Jqx8V7H8"',
    "mtime": "2026-09-16T21:22:37.865Z",
    "size": 1823069,
    "path": "../public/rentify-slider.png"
  },
  "/rentify-slider2.png": {
    "type": "image/png",
    "etag": '"1a5fac-hHdZjAf40W/LyFzzTYOWC0+4u9s"',
    "mtime": "2026-09-16T21:22:06.104Z",
    "size": 1728428,
    "path": "../public/rentify-slider2.png"
  },
  "/rentify-slider1.png": {
    "type": "image/png",
    "etag": '"1b1fea-NQ8/Zo4D26El2TxwetTasTCPyyA"',
    "mtime": "2026-09-16T21:22:19.804Z",
    "size": 1777642,
    "path": "../public/rentify-slider1.png"
  },
  "/assets/deposits-VmmLVzmI.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"da4-dcZijCoeXJg/FSLShDEBiFLK6cE"',
    "mtime": "2026-09-16T21:54:36.986Z",
    "size": 3492,
    "path": "../public/assets/deposits-VmmLVzmI.js"
  },
  "/assets/download-BG0QpoWA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"f4-NaL4OLYQTP1CFUO8sqciDBUnn/Y"',
    "mtime": "2026-09-16T21:54:36.990Z",
    "size": 244,
    "path": "../public/assets/download-BG0QpoWA.js"
  },
  "/assets/eye-CoEhMlRV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"10c-OufE/X+5W9rVTIgPa2Nx2pxBGSw"',
    "mtime": "2026-09-16T21:54:36.990Z",
    "size": 268,
    "path": "../public/assets/eye-CoEhMlRV.js"
  },
  "/assets/file-spreadsheet-BvOeo_ed.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1b3-sY3QvLwJCVD9y9jsYQVdUIn4GPw"',
    "mtime": "2026-09-16T21:54:36.989Z",
    "size": 435,
    "path": "../public/assets/file-spreadsheet-BvOeo_ed.js"
  },
  "/assets/index-C049qd0m.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"27b9-g0qFr139q7r++pjaQGmcxreZvu4"',
    "mtime": "2026-09-16T21:54:36.991Z",
    "size": 10169,
    "path": "../public/assets/index-C049qd0m.js"
  },
  "/assets/index-CNwLMM3y.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"263-FbX9nyUwOZw8oA32qsAZktZrX8k"',
    "mtime": "2026-09-16T21:54:36.987Z",
    "size": 611,
    "path": "../public/assets/index-CNwLMM3y.js"
  },
  "/assets/index-DQApeKt3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"49f8-QdURPKL29ANOeTn/ZtI7M90kzyA"',
    "mtime": "2026-09-16T21:54:36.991Z",
    "size": 18936,
    "path": "../public/assets/index-DQApeKt3.js"
  },
  "/assets/excel-C5j6C-ZU.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"67cc3-KKIwmy9NVaaQ6BXDaD+OF0+R/F8"',
    "mtime": "2026-09-16T21:54:36.989Z",
    "size": 425155,
    "path": "../public/assets/excel-C5j6C-ZU.js"
  },
  "/assets/input-B6c2I-F-.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"259-1+mxfZngO1ln27Tff68FFoD7m+c"',
    "mtime": "2026-09-16T21:54:36.991Z",
    "size": 601,
    "path": "../public/assets/input-B6c2I-F-.js"
  },
  "/assets/index.es-CC_JF-hr.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"26eff-5CPw8O0rs7paCzrQdb8GHiBty+Y"',
    "mtime": "2026-09-16T21:54:36.991Z",
    "size": 159487,
    "path": "../public/assets/index.es-CC_JF-hr.js"
  },
  "/assets/isBefore-CnTieWDA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"54-Di2r/RtNWf/iKhw73gHxETV0k0w"',
    "mtime": "2026-09-16T21:54:36.990Z",
    "size": 84,
    "path": "../public/assets/isBefore-CnTieWDA.js"
  },
  "/assets/KpiCard-D0fD0483.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3dd-UJQOFJaBQOBLIRLA6y5H742dwkw"',
    "mtime": "2026-09-16T21:54:36.987Z",
    "size": 989,
    "path": "../public/assets/KpiCard-D0fD0483.js"
  },
  "/assets/label-D0QBf32s.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"bd5-zr4zbEKlaNcJHJkyNyuYEtm0MdA"',
    "mtime": "2026-09-16T21:54:36.991Z",
    "size": 3029,
    "path": "../public/assets/label-D0QBf32s.js"
  },
  "/assets/login-D9RBrzuA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2c39-9xcejm+/uxdo7+sCCeQXtGT8bJg"',
    "mtime": "2026-09-16T21:54:36.986Z",
    "size": 11321,
    "path": "../public/assets/login-D9RBrzuA.js"
  },
  "/assets/mail-D6_j0cqc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"dc-ANI+ovFsYewaP3rHth5k4+hyfoM"',
    "mtime": "2026-09-16T21:54:36.988Z",
    "size": 220,
    "path": "../public/assets/mail-D6_j0cqc.js"
  },
  "/assets/maintenance-dd1P8asg.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2a0-TSXv90eL+LaGwOeh+XZmIoJl9oY"',
    "mtime": "2026-09-16T21:54:36.986Z",
    "size": 672,
    "path": "../public/assets/maintenance-dd1P8asg.js"
  },
  "/assets/maintenance-DR2tztyq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"18e3-t8K2bl/bPteazIwpWTtf1iSjKYQ"',
    "mtime": "2026-09-16T21:54:36.986Z",
    "size": 6371,
    "path": "../public/assets/maintenance-DR2tztyq.js"
  },
  "/assets/notifications-zWh7al-8.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"13d9-EqNOVzZ7D8app1G+M3nRYxaULbw"',
    "mtime": "2026-09-16T21:54:36.986Z",
    "size": 5081,
    "path": "../public/assets/notifications-zWh7al-8.js"
  },
  "/assets/payments-BSXxBnYy.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2b0-32vVFesd6Qj8YrHJIauoNR3owX8"',
    "mtime": "2026-09-16T21:54:36.989Z",
    "size": 688,
    "path": "../public/assets/payments-BSXxBnYy.js"
  },
  "/assets/payments-CTXTwZ8y.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2a31-KccE7AssoPgu6y9cC7UD5FTK3s0"',
    "mtime": "2026-09-16T21:54:36.986Z",
    "size": 10801,
    "path": "../public/assets/payments-CTXTwZ8y.js"
  },
  "/assets/index-MFwZeyvL.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"8e33c-Nt9t/jgt6zMi56LrEq/olSZwxfM"',
    "mtime": "2026-09-16T21:54:36.991Z",
    "size": 582460,
    "path": "../public/assets/index-MFwZeyvL.js"
  },
  "/assets/PayNowDialog-DjqTMI-2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1310-I75h12rMBPPj6r32p/Pk6xUxzAY"',
    "mtime": "2026-09-16T21:54:36.989Z",
    "size": 4880,
    "path": "../public/assets/PayNowDialog-DjqTMI-2.js"
  },
  "/assets/purify.es-VaSPOPhr.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"7032-uZQ20bhcE4YqMv2bJ83N97r01ek"',
    "mtime": "2026-09-16T21:54:36.991Z",
    "size": 28722,
    "path": "../public/assets/purify.es-VaSPOPhr.js"
  },
  "/assets/reports-eYUFZ-Q6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"4094-3f1N7Ze5VMmkPPfEZnu6weusPPI"',
    "mtime": "2026-09-16T21:54:36.986Z",
    "size": 16532,
    "path": "../public/assets/reports-eYUFZ-Q6.js"
  },
  "/assets/settings-1FPvi2KJ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"258-vXojvqfDGBYjGZZtw59ki6SHJxQ"',
    "mtime": "2026-09-16T21:54:36.989Z",
    "size": 600,
    "path": "../public/assets/settings-1FPvi2KJ.js"
  },
  "/assets/settings-DPCYtD8q.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"43d-OpTXpzKVxcCb8ZAIBv4yJIkaOzQ"',
    "mtime": "2026-09-16T21:54:36.986Z",
    "size": 1085,
    "path": "../public/assets/settings-DPCYtD8q.js"
  },
  "/assets/settings.about-Dqyl3o5F.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"f75-xxehsn0LIBFFVbmH0HJyxQ9FhIc"',
    "mtime": "2026-09-16T21:54:36.989Z",
    "size": 3957,
    "path": "../public/assets/settings.about-Dqyl3o5F.js"
  },
  "/assets/settings.index-C91zuA-a.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1f37-qi+xYsBTaY4TKeKg/dS+acdw/dI"',
    "mtime": "2026-09-16T21:54:36.988Z",
    "size": 7991,
    "path": "../public/assets/settings.index-C91zuA-a.js"
  },
  "/assets/shield-check-DDVjB9mV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"14c-RVYss4WnLXkkMlsbhQyxcS0dRLQ"',
    "mtime": "2026-09-16T21:54:36.989Z",
    "size": 332,
    "path": "../public/assets/shield-check-DDVjB9mV.js"
  },
  "/assets/StatusBadge-BxCNRRh9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"140-B0zyLDmbLQcoYcj8y5KqZWxqW5Y"',
    "mtime": "2026-09-16T21:54:36.991Z",
    "size": 320,
    "path": "../public/assets/StatusBadge-BxCNRRh9.js"
  },
  "/assets/tenants-BykA42Dq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"266-dt3Yl87uFXj4OFE8IY0KN5Mdf2o"',
    "mtime": "2026-09-16T21:54:36.990Z",
    "size": 614,
    "path": "../public/assets/tenants-BykA42Dq.js"
  },
  "/assets/tenants-VZz0Q3cp.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5f-Ur5Fa4VlMdJXI7pmMr11WwM+Tsc"',
    "mtime": "2026-09-16T21:54:36.985Z",
    "size": 95,
    "path": "../public/assets/tenants-VZz0Q3cp.js"
  },
  "/assets/styles-Dao-kunJ.css": {
    "type": "text/css; charset=utf-8",
    "etag": '"1a5d5-XYK337BAgH7aNvC1DO04PiEWRmY"',
    "mtime": "2026-09-16T21:54:36.968Z",
    "size": 107989,
    "path": "../public/assets/styles-Dao-kunJ.css"
  },
  "/assets/tenants.index-D6UhwVH_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1b5e-oDMDqQESlRrI42jn0OW5su5AHN4"',
    "mtime": "2026-09-16T21:54:36.988Z",
    "size": 7006,
    "path": "../public/assets/tenants.index-D6UhwVH_.js"
  },
  "/assets/tenants._id--OV7AO27.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"25b6-k1TW9TXFLcbA/2Ju98mA9ZhYvBk"',
    "mtime": "2026-09-16T21:54:36.988Z",
    "size": 9654,
    "path": "../public/assets/tenants._id--OV7AO27.js"
  },
  "/assets/trending-down-B4SZuTje.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"be-uaBFzbnVa5+SGvpNZHmWp7QUFCI"',
    "mtime": "2026-09-16T21:54:36.987Z",
    "size": 190,
    "path": "../public/assets/trending-down-B4SZuTje.js"
  },
  "/assets/units-tu-1Teu0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"254-VaoToSgYWNraJqF6v0NQsFdIvik"',
    "mtime": "2026-09-16T21:54:36.990Z",
    "size": 596,
    "path": "../public/assets/units-tu-1Teu0.js"
  },
  "/assets/units-VZz0Q3cp.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5f-Ur5Fa4VlMdJXI7pmMr11WwM+Tsc"',
    "mtime": "2026-09-16T21:54:36.985Z",
    "size": 95,
    "path": "../public/assets/units-VZz0Q3cp.js"
  },
  "/assets/units.index-_aag1T1Q.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2111-SEsoea5BSsO5Q/t8IEJ0Iha84I4"',
    "mtime": "2026-09-16T21:54:36.987Z",
    "size": 8465,
    "path": "../public/assets/units.index-_aag1T1Q.js"
  },
  "/assets/units._id-Ba5JQiG_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2b0b-ztPaQ3ZreQX0RbscpyGv8Wr7Z44"',
    "mtime": "2026-09-16T21:54:36.988Z",
    "size": 11019,
    "path": "../public/assets/units._id-Ba5JQiG_.js"
  }
};
function readAsset(id) {
  const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
  return promises.readFile(resolve(serverDir, assets[id].path));
}
const publicAssetBases = {};
function isPublicAssetURL(id = "") {
  if (assets[id]) {
    return true;
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) {
      return true;
    }
  }
  return false;
}
function getAsset(id) {
  return assets[id];
}
const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = {
  gzip: ".gz",
  br: ".br",
  zstd: ".zst"
};
const _9YnzWg = defineHandler((event) => {
  if (event.req.method && !METHODS.has(event.req.method)) {
    return;
  }
  let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
  let asset;
  const encodingHeader = event.req.headers.get("accept-encoding") || "";
  const encodings = [...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      event.res.headers.delete("Cache-Control");
      throw new HTTPError({ status: 404 });
    }
    return;
  }
  if (encodings.length > 1) {
    event.res.headers.append("Vary", "Accept-Encoding");
  }
  const ifNotMatch = event.req.headers.get("if-none-match") === asset.etag;
  if (ifNotMatch) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  const ifModifiedSinceH = event.req.headers.get("if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  if (asset.type) {
    event.res.headers.set("Content-Type", asset.type);
  }
  if (asset.etag && !event.res.headers.has("ETag")) {
    event.res.headers.set("ETag", asset.etag);
  }
  if (asset.mtime && !event.res.headers.has("Last-Modified")) {
    event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !event.res.headers.has("Content-Encoding")) {
    event.res.headers.set("Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !event.res.headers.has("Content-Length")) {
    event.res.headers.set("Content-Length", asset.size.toString());
  }
  return readAsset(id);
});
const findRouteRules = /* @__PURE__ */ (() => {
  const $0 = [{ name: "headers", route: "/assets/**", handler: headers, options: { "cache-control": "public, max-age=31536000, immutable" } }];
  return (m, p) => {
    let r = [];
    if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
    let s = p.split("/"), l = s.length;
    if (l > 1) {
      if (s[1] === "assets") {
        r.unshift({ data: $0, params: { "_": s.slice(2).join("/") } });
      }
    }
    return r;
  };
})();
const _lazy_PFmFgc = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
const findRoute = /* @__PURE__ */ (() => {
  const data = { route: "/**", handler: _lazy_PFmFgc };
  return ((_m, p) => {
    return { data, params: { "_": p.slice(1) } };
  });
})();
const globalMiddleware = [
  toEventHandler(_9YnzWg)
].filter(Boolean);
const errorHandler$1 = (error, event) => {
  const res = defaultHandler(error, event);
  return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
  const unhandled = error.unhandled ?? !HTTPError.isError(error);
  const { status = 500, statusText = "" } = unhandled ? {} : error;
  if (status === 404) {
    const url = event.url || new URL(event.req.url);
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      return {
        status: 302,
        headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
      };
    }
  }
  const headers2 = new Headers(unhandled ? {} : error.headers);
  headers2.set("content-type", "application/json; charset=utf-8");
  const jsonBody = unhandled ? {
    status,
    unhandled: true
  } : typeof error.toJSON === "function" ? error.toJSON() : {
    status,
    statusText,
    message: error.message
  };
  return {
    status,
    statusText,
    headers: headers2,
    body: {
      error: true,
      ...jsonBody
    }
  };
}
const errorHandlers = [errorHandler$1];
async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      const response = await handler(error, event, { defaultHandler });
      if (response) {
        return response;
      }
    } catch (error2) {
      console.error(error2);
    }
  }
}
function createNitroApp() {
  const captureError = (error, errorCtx) => {
    if (errorCtx?.event) {
      const errors = errorCtx.event.req.context?.nitro?.errors;
      if (errors) {
        errors.push({ error, context: errorCtx });
      }
    }
  };
  const h3App = createH3App({
    onError(error, event) {
      return errorHandler(error, event);
    }
  });
  let appHandler = (req) => {
    req.context ||= {};
    req.context.nitro = req.context.nitro || { errors: [] };
    return h3App.fetch(req);
  };
  return {
    fetch: appHandler,
    h3: h3App,
    hooks: void 0,
    captureError
  };
}
function createH3App(config) {
  const h3App = new H3Core(config);
  h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
  h3App["~middleware"].push(...globalMiddleware);
  h3App["~getMiddleware"] = (event, route) => {
    const pathname = event.url.pathname;
    const method = event.req.method;
    const middleware = [];
    const routeRules = getRouteRules(method, pathname);
    event.context.routeRules = routeRules?.routeRules;
    if (routeRules?.routeRuleMiddleware.length) {
      middleware.push(...routeRules.routeRuleMiddleware);
    }
    middleware.push(...h3App["~middleware"]);
    if (route?.data?.middleware?.length) {
      middleware.push(...route.data.middleware);
    }
    return middleware;
  };
  return h3App;
}
const APP_ID = "default";
function useNitroApp() {
  let instance = useNitroApp._instance;
  if (instance) {
    return instance;
  }
  instance = useNitroApp._instance = createNitroApp();
  globalThis.__nitro__ = globalThis.__nitro__ || {};
  globalThis.__nitro__[APP_ID] = instance;
  return instance;
}
function getRouteRules(method, pathname) {
  const m = findRouteRules(method, pathname);
  if (!m?.length) {
    return { routeRuleMiddleware: [] };
  }
  const routeRules = {};
  for (const layer of m) {
    for (const rule of layer.data) {
      const currentRule = routeRules[rule.name];
      if (currentRule) {
        if (rule.options === false) {
          delete routeRules[rule.name];
          continue;
        }
        if (typeof currentRule.options === "object" && typeof rule.options === "object") {
          currentRule.options = {
            ...currentRule.options,
            ...rule.options
          };
        } else {
          currentRule.options = rule.options;
        }
        currentRule.route = rule.route;
        currentRule.params = {
          ...currentRule.params,
          ...layer.params
        };
      } else if (rule.options !== false) {
        routeRules[rule.name] = {
          ...rule,
          params: layer.params
        };
      }
    }
  }
  const middleware = [];
  const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
  for (const rule of orderedRules) {
    if (rule.options === false || !rule.handler) {
      continue;
    }
    middleware.push(rule.handler(rule));
  }
  return {
    routeRules,
    routeRuleMiddleware: middleware
  };
}
function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
  process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
  process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
const tracingSrvxPlugins = [];
const _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
const port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
const host = process.env.NITRO_HOST || process.env.HOST;
const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const nitroApp = useNitroApp();
serve({
  port,
  hostname: host,
  tls: cert && key ? {
    cert,
    key
  } : void 0,
  fetch: nitroApp.fetch,
  plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
const nodeServer = {};
export {
  nodeServer as default
};
