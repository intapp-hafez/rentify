globalThis.__nitro_main__ = import.meta.url;
import { N as NodeResponse, s as serve } from "./_libs/srvx.mjs";
import { d as defineHandler, H as HTTPError, t as toEventHandler, a as defineLazyEventHandler, b as H3Core } from "./_libs/h3.mjs";
import { d as decodePath, w as withLeadingSlash, a as withoutTrailingSlash, j as joinURL } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import "node:http";
import "node:stream";
import "node:stream/promises";
import "node:https";
import "node:http2";
import "./_libs/rou3.mjs";
function lazyService(loader) {
  let promise, mod;
  return {
    fetch(req) {
      if (mod) {
        return mod.fetch(req);
      }
      if (!promise) {
        promise = loader().then((_mod) => mod = _mod.default || _mod);
      }
      return promise.then((mod2) => mod2.fetch(req));
    }
  };
}
const services = {
  ["ssr"]: lazyService(() => import("./_ssr/index.mjs"))
};
globalThis.__nitro_vite_envs__ = services;
const headers = ((m) => function headersRouteRule(event) {
  for (const [key2, value] of Object.entries(m.options || {})) {
    event.res.headers.set(key2, value);
  }
});
const assets = {
  "/.htaccess": {
    "type": "text/plain; charset=utf-8",
    "etag": '"d6-uCGM/aWSby4OafxcQnLurhDUWcE"',
    "mtime": "2026-07-07T06:24:35.259Z",
    "size": 214,
    "path": "../public/.htaccess"
  },
  "/rentify.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": '"e8e8-FXFXsQVeCiJWpLJ5/SCzrzv6YNY"',
    "mtime": "2026-07-06T16:31:33.376Z",
    "size": 59624,
    "path": "../public/rentify.ico"
  },
  "/robots.txt": {
    "type": "text/plain; charset=utf-8",
    "etag": '"16-iUOtJ2RsHfdY9DoQxaq0wz1LZCU"',
    "mtime": "2026-07-05T00:53:04.000Z",
    "size": 22,
    "path": "../public/robots.txt"
  },
  "/favicon.png": {
    "type": "image/png",
    "etag": '"66ca1-HrdoQV9cIHmnRiDzMPV3ov/zyjI"',
    "mtime": "2026-07-05T11:41:33.192Z",
    "size": 421025,
    "path": "../public/favicon.png"
  },
  "/assets/addYears-QsHAVdER.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"8c-Lo9lKkX8Qvu2UpmyJI7FUMELmA4"',
    "mtime": "2026-07-17T22:20:22.159Z",
    "size": 140,
    "path": "../public/assets/addYears-QsHAVdER.js"
  },
  "/assets/AppLayout-ChiaEUYe.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"22a91-+DGySHdozDuQ/kPunVCEUn51sAQ"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 141969,
    "path": "../public/assets/AppLayout-ChiaEUYe.js"
  },
  "/assets/button-eeRQtRSH.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1122-XoVu2Y10lFPAM50+YWRUe/STVkY"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 4386,
    "path": "../public/assets/button-eeRQtRSH.js"
  },
  "/assets/building-2-DQYcExln.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"186-u86sNtMvHDil0flEtkT80NDxg8I"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 390,
    "path": "../public/assets/building-2-DQYcExln.js"
  },
  "/assets/card-D8px5rUQ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3e9-b5MiZzbQ/hhTScEjvzfJ9ichsw4"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 1001,
    "path": "../public/assets/card-D8px5rUQ.js"
  },
  "/assets/ConfirmDelete-DWK_LNnv.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"6f88-xWnOcNyqDxJUP4TApbbA0xFE/vg"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 28552,
    "path": "../public/assets/ConfirmDelete-DWK_LNnv.js"
  },
  "/assets/chart-column-CUpkoCUI.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"102-BBZLQBInzfsOzQ0DMHKe5MwzdmY"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 258,
    "path": "../public/assets/chart-column-CUpkoCUI.js"
  },
  "/assets/contracts-DmQ4NKpI.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"334-4AzedOfh6uywCl/tSpy6/T15rrM"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 820,
    "path": "../public/assets/contracts-DmQ4NKpI.js"
  },
  "/assets/arrow-down-up-z35Lqt8i.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"101-c5Zyo5NVgUtUE3zxW5IraflHtaU"',
    "mtime": "2026-07-17T22:20:22.159Z",
    "size": 257,
    "path": "../public/assets/arrow-down-up-z35Lqt8i.js"
  },
  "/assets/contracts.index-FR11OJ-y.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1d67-DZWKi0GgqjZDisdPfnjlNqLjnPw"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 7527,
    "path": "../public/assets/contracts.index-FR11OJ-y.js"
  },
  "/assets/contracts-Dsujf30h.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5f-ZD2tUNXsymY52gnWo7PUNaA+rws"',
    "mtime": "2026-07-17T22:20:22.159Z",
    "size": 95,
    "path": "../public/assets/contracts-Dsujf30h.js"
  },
  "/assets/createLucideIcon-CIX9LLje.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"705a-dhPMARY51w/zaEnUfnfB6Mao630"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 28762,
    "path": "../public/assets/createLucideIcon-CIX9LLje.js"
  },
  "/assets/DataTable-Cg3LTdik.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"961-YT/zar5X1MYjoNz0TqwpgECTTSU"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 2401,
    "path": "../public/assets/DataTable-Cg3LTdik.js"
  },
  "/assets/dashboard-ZChw7n5R.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2051-R9a7JmQhgL4wEtKfKMBu3sOcmUY"',
    "mtime": "2026-07-17T22:20:22.159Z",
    "size": 8273,
    "path": "../public/assets/dashboard-ZChw7n5R.js"
  },
  "/assets/deposits-CjhZnLFg.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"d6a-qVBsWU8REfeJEGFKDtqtpZB089I"',
    "mtime": "2026-07-17T22:20:22.159Z",
    "size": 3434,
    "path": "../public/assets/deposits-CjhZnLFg.js"
  },
  "/assets/deposits-w1egKLHA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2e5-68pfVGpuI9nl8sMPIk2JjyIJrcs"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 741,
    "path": "../public/assets/deposits-w1egKLHA.js"
  },
  "/favicon1.png": {
    "type": "image/png",
    "etag": '"8a080-kq0z09uyP2kxj00KbOLDWNLRJZ4"',
    "mtime": "2026-07-05T00:53:04.000Z",
    "size": 565376,
    "path": "../public/favicon1.png"
  },
  "/assets/excel-Bo9Gh-au.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"67db4-em17PyOU9BX9jLFF+r28kaTvUsk"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 425396,
    "path": "../public/assets/excel-Bo9Gh-au.js"
  },
  "/logo.png": {
    "type": "image/png",
    "etag": '"871bc-/OQjtGLNFqOF/JUZF46kOgZ7wzk"',
    "mtime": "2026-07-05T00:53:04.000Z",
    "size": 553404,
    "path": "../public/logo.png"
  },
  "/assets/contracts._id-BHJygxPa.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"93489-JLs3ly2EDFaDuvyzfFIwBk7aiA0"',
    "mtime": "2026-07-17T22:20:22.162Z",
    "size": 603273,
    "path": "../public/assets/contracts._id-BHJygxPa.js"
  },
  "/assets/index-BdrOZv2w.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"27b9-bIWHnUiascnhVCDd7ZexN9hunL0"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 10169,
    "path": "../public/assets/index-BdrOZv2w.js"
  },
  "/assets/index-BYJfAnI6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"49f8-fd/ea2YZrYDWtN2Ex74yH1w/Jcg"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 18936,
    "path": "../public/assets/index-BYJfAnI6.js"
  },
  "/assets/index-DzYGNT30.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"e2a-vI/oL6ChGuL1iY/UQEUmem5Hb80"',
    "mtime": "2026-07-17T22:20:22.159Z",
    "size": 3626,
    "path": "../public/assets/index-DzYGNT30.js"
  },
  "/assets/input-B0lDQ3Wj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"259-Lvu0BiYELw5e34O7qHKx37M93rE"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 601,
    "path": "../public/assets/input-B0lDQ3Wj.js"
  },
  "/assets/isBefore-C78qw3D8.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"54-xn5oDpufhpEHDDijwYlyo8R29vU"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 84,
    "path": "../public/assets/isBefore-C78qw3D8.js"
  },
  "/assets/KpiCard-Cebi6W5q.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3dd-RZ/IZ/D5oLYqtCPjVEvKi4guz/k"',
    "mtime": "2026-07-17T22:20:22.159Z",
    "size": 989,
    "path": "../public/assets/KpiCard-Cebi6W5q.js"
  },
  "/assets/index.es-BV1vfAq3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"26ec5-2DZTEWx3J9zPy7sUp7c8guisQNo"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 159429,
    "path": "../public/assets/index.es-BV1vfAq3.js"
  },
  "/assets/label-BvXKN7dI.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"bd5-of+m6w5RS+whxBDy0vn0H6a/MKw"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 3029,
    "path": "../public/assets/label-BvXKN7dI.js"
  },
  "/assets/login-DedmTe8F.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"82e-Psr0l9rFdvFOdIoqcPGj04Effb8"',
    "mtime": "2026-07-17T22:20:22.159Z",
    "size": 2094,
    "path": "../public/assets/login-DedmTe8F.js"
  },
  "/assets/maintenance-f5cU5Uvf.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"189a-4UNnCJEgjDAqjBgd8h6GHXYItdY"',
    "mtime": "2026-07-17T22:20:22.159Z",
    "size": 6298,
    "path": "../public/assets/maintenance-f5cU5Uvf.js"
  },
  "/assets/maintenance-DoQzf8Ah.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2a0-BxTsOkvggrNDeP3YS+39pe9mxW8"',
    "mtime": "2026-07-17T22:20:22.159Z",
    "size": 672,
    "path": "../public/assets/maintenance-DoQzf8Ah.js"
  },
  "/assets/notifications-BBK8O2cx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1402-xW6eO5SH2mPoFBYMsLXvvqtvuDo"',
    "mtime": "2026-07-17T22:20:22.159Z",
    "size": 5122,
    "path": "../public/assets/notifications-BBK8O2cx.js"
  },
  "/assets/payments-BL67YWM5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2b0-guxnZrm+gpLQUfFGhd8sdXqe3pE"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 688,
    "path": "../public/assets/payments-BL67YWM5.js"
  },
  "/assets/PayNowDialog-BCnH7vEG.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"11cd-zT4RHHk0Kp9JatV2xj7fiZInS6w"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 4557,
    "path": "../public/assets/PayNowDialog-BCnH7vEG.js"
  },
  "/assets/payments-DXbXQDL2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"26bc-73Or4IeIOJUMg+3HmwSELcp/soY"',
    "mtime": "2026-07-17T22:20:22.159Z",
    "size": 9916,
    "path": "../public/assets/payments-DXbXQDL2.js"
  },
  "/assets/purify.es-VaSPOPhr.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"7032-uZQ20bhcE4YqMv2bJ83N97r01ek"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 28722,
    "path": "../public/assets/purify.es-VaSPOPhr.js"
  },
  "/assets/reports-B5syPqQt.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"406f-Y90FWuH7aqI0m3z9a2j3fwYNPyA"',
    "mtime": "2026-07-17T22:20:22.159Z",
    "size": 16495,
    "path": "../public/assets/reports-B5syPqQt.js"
  },
  "/assets/settings-Bq2dEuzK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"43c-CxRgx7qhyWq04fkRnX+5ardCKLA"',
    "mtime": "2026-07-17T22:20:22.159Z",
    "size": 1084,
    "path": "../public/assets/settings-Bq2dEuzK.js"
  },
  "/assets/settings-uqphODKB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"258-wiy442dTHSL9+1rp7Mgh8+iod8w"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 600,
    "path": "../public/assets/settings-uqphODKB.js"
  },
  "/assets/settings.about-BVPbZ8Lj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"b03-SKfl3d8Knp/j/vh/n1uaC34ysuA"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 2819,
    "path": "../public/assets/settings.about-BVPbZ8Lj.js"
  },
  "/assets/index-BiCJzA_6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"8e304-76y67LP4HlTiSCWQcT2dNkzOg8c"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 582404,
    "path": "../public/assets/index-BiCJzA_6.js"
  },
  "/assets/shield-check-DNkvhA2P.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"14c-RcJebYeygkKo7Z7rOG769+pdJbI"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 332,
    "path": "../public/assets/shield-check-DNkvhA2P.js"
  },
  "/assets/settings.index-D33H-cM4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1fae-9V5/KD4wwvtnzrYEqSdF414oH5Q"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 8110,
    "path": "../public/assets/settings.index-D33H-cM4.js"
  },
  "/assets/StatusBadge-DkkBRK-e.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"140-48EeugsWqGKsI0IfO+8Ww4wji3o"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 320,
    "path": "../public/assets/StatusBadge-DkkBRK-e.js"
  },
  "/assets/styles-BgUP67JD.css": {
    "type": "text/css; charset=utf-8",
    "etag": '"16db5-vnCZeWMjjC8V+CSS7RkmB+rg+Yk"',
    "mtime": "2026-07-17T22:20:22.152Z",
    "size": 93621,
    "path": "../public/assets/styles-BgUP67JD.css"
  },
  "/assets/tenants-C4wVD_pK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5f-ZD2tUNXsymY52gnWo7PUNaA+rws"',
    "mtime": "2026-07-17T22:20:22.158Z",
    "size": 95,
    "path": "../public/assets/tenants-C4wVD_pK.js"
  },
  "/assets/tenants.index-XgrnoXwd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1b15-/VlhvUQ2bSveXMmpwj8+pOO1poo"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 6933,
    "path": "../public/assets/tenants.index-XgrnoXwd.js"
  },
  "/assets/tenants._id-Bs2dPBiK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"256d-OpDVsmWXGaPU4H6e7Oa7nrVdqcI"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 9581,
    "path": "../public/assets/tenants._id-Bs2dPBiK.js"
  },
  "/assets/tenants-CT6AFmPZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"266-J83lDtL8+/+smqj039z5Bgq/YIA"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 614,
    "path": "../public/assets/tenants-CT6AFmPZ.js"
  },
  "/assets/trending-down-BZVTBxj6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"be-D5sul8/F7qH9L78xjHfOfo9CiPs"',
    "mtime": "2026-07-17T22:20:22.159Z",
    "size": 190,
    "path": "../public/assets/trending-down-BZVTBxj6.js"
  },
  "/assets/triangle-alert-DkmjW0wN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"115-rvX0NJON34XbnAitKs/QlVT7jcM"',
    "mtime": "2026-07-17T22:20:22.159Z",
    "size": 277,
    "path": "../public/assets/triangle-alert-DkmjW0wN.js"
  },
  "/assets/units-C4wVD_pK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5f-ZD2tUNXsymY52gnWo7PUNaA+rws"',
    "mtime": "2026-07-17T22:20:22.158Z",
    "size": 95,
    "path": "../public/assets/units-C4wVD_pK.js"
  },
  "/assets/units._id-B4V8atUh.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"265e-uvm+Zxje/VJ0RiP/iuPd2f9DF3c"',
    "mtime": "2026-07-17T22:20:22.159Z",
    "size": 9822,
    "path": "../public/assets/units._id-B4V8atUh.js"
  },
  "/assets/units-YTs0Isrh.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"254-34ubH0+rKirGIjkFCzrtpnN9/U8"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 596,
    "path": "../public/assets/units-YTs0Isrh.js"
  },
  "/assets/units.index-me7pPQig.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"20c8-k5w7p6SHhq+I12F+1UIm18zud8o"',
    "mtime": "2026-07-17T22:20:22.159Z",
    "size": 8392,
    "path": "../public/assets/units.index-me7pPQig.js"
  },
  "/assets/upload-C_lzgTjz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"269-V+69fD2nTtvPhOz6i1bzHxaGy2Q"',
    "mtime": "2026-07-17T22:20:22.160Z",
    "size": 617,
    "path": "../public/assets/upload-C_lzgTjz.js"
  }
};
function readAsset(id) {
  const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
  return promises.readFile(resolve(serverDir, assets[id].path));
}
const publicAssetBases = {};
function isPublicAssetURL(id = "") {
  if (assets[id]) {
    return true;
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) {
      return true;
    }
  }
  return false;
}
function getAsset(id) {
  return assets[id];
}
const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = {
  gzip: ".gz",
  br: ".br",
  zstd: ".zst"
};
const _9YnzWg = defineHandler((event) => {
  if (event.req.method && !METHODS.has(event.req.method)) {
    return;
  }
  let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
  let asset;
  const encodingHeader = event.req.headers.get("accept-encoding") || "";
  const encodings = [...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      event.res.headers.delete("Cache-Control");
      throw new HTTPError({ status: 404 });
    }
    return;
  }
  if (encodings.length > 1) {
    event.res.headers.append("Vary", "Accept-Encoding");
  }
  const ifNotMatch = event.req.headers.get("if-none-match") === asset.etag;
  if (ifNotMatch) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  const ifModifiedSinceH = event.req.headers.get("if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  if (asset.type) {
    event.res.headers.set("Content-Type", asset.type);
  }
  if (asset.etag && !event.res.headers.has("ETag")) {
    event.res.headers.set("ETag", asset.etag);
  }
  if (asset.mtime && !event.res.headers.has("Last-Modified")) {
    event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !event.res.headers.has("Content-Encoding")) {
    event.res.headers.set("Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !event.res.headers.has("Content-Length")) {
    event.res.headers.set("Content-Length", asset.size.toString());
  }
  return readAsset(id);
});
const findRouteRules = /* @__PURE__ */ (() => {
  const $0 = [{ name: "headers", route: "/assets/**", handler: headers, options: { "cache-control": "public, max-age=31536000, immutable" } }];
  return (m, p) => {
    let r = [];
    if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
    let s = p.split("/"), l = s.length;
    if (l > 1) {
      if (s[1] === "assets") {
        r.unshift({ data: $0, params: { "_": s.slice(2).join("/") } });
      }
    }
    return r;
  };
})();
const _lazy_PFmFgc = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
const findRoute = /* @__PURE__ */ (() => {
  const data = { route: "/**", handler: _lazy_PFmFgc };
  return ((_m, p) => {
    return { data, params: { "_": p.slice(1) } };
  });
})();
const globalMiddleware = [
  toEventHandler(_9YnzWg)
].filter(Boolean);
const errorHandler$1 = (error, event) => {
  const res = defaultHandler(error, event);
  return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
  const unhandled = error.unhandled ?? !HTTPError.isError(error);
  const { status = 500, statusText = "" } = unhandled ? {} : error;
  if (status === 404) {
    const url = event.url || new URL(event.req.url);
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      return {
        status: 302,
        headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
      };
    }
  }
  const headers2 = new Headers(unhandled ? {} : error.headers);
  headers2.set("content-type", "application/json; charset=utf-8");
  const jsonBody = unhandled ? {
    status,
    unhandled: true
  } : typeof error.toJSON === "function" ? error.toJSON() : {
    status,
    statusText,
    message: error.message
  };
  return {
    status,
    statusText,
    headers: headers2,
    body: {
      error: true,
      ...jsonBody
    }
  };
}
const errorHandlers = [errorHandler$1];
async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      const response = await handler(error, event, { defaultHandler });
      if (response) {
        return response;
      }
    } catch (error2) {
      console.error(error2);
    }
  }
}
function createNitroApp() {
  const captureError = (error, errorCtx) => {
    if (errorCtx?.event) {
      const errors = errorCtx.event.req.context?.nitro?.errors;
      if (errors) {
        errors.push({ error, context: errorCtx });
      }
    }
  };
  const h3App = createH3App({
    onError(error, event) {
      return errorHandler(error, event);
    }
  });
  let appHandler = (req) => {
    req.context ||= {};
    req.context.nitro = req.context.nitro || { errors: [] };
    return h3App.fetch(req);
  };
  return {
    fetch: appHandler,
    h3: h3App,
    hooks: void 0,
    captureError
  };
}
function createH3App(config) {
  const h3App = new H3Core(config);
  h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
  h3App["~middleware"].push(...globalMiddleware);
  h3App["~getMiddleware"] = (event, route) => {
    const pathname = event.url.pathname;
    const method = event.req.method;
    const middleware = [];
    const routeRules = getRouteRules(method, pathname);
    event.context.routeRules = routeRules?.routeRules;
    if (routeRules?.routeRuleMiddleware.length) {
      middleware.push(...routeRules.routeRuleMiddleware);
    }
    middleware.push(...h3App["~middleware"]);
    if (route?.data?.middleware?.length) {
      middleware.push(...route.data.middleware);
    }
    return middleware;
  };
  return h3App;
}
const APP_ID = "default";
function useNitroApp() {
  let instance = useNitroApp._instance;
  if (instance) {
    return instance;
  }
  instance = useNitroApp._instance = createNitroApp();
  globalThis.__nitro__ = globalThis.__nitro__ || {};
  globalThis.__nitro__[APP_ID] = instance;
  return instance;
}
function getRouteRules(method, pathname) {
  const m = findRouteRules(method, pathname);
  if (!m?.length) {
    return { routeRuleMiddleware: [] };
  }
  const routeRules = {};
  for (const layer of m) {
    for (const rule of layer.data) {
      const currentRule = routeRules[rule.name];
      if (currentRule) {
        if (rule.options === false) {
          delete routeRules[rule.name];
          continue;
        }
        if (typeof currentRule.options === "object" && typeof rule.options === "object") {
          currentRule.options = {
            ...currentRule.options,
            ...rule.options
          };
        } else {
          currentRule.options = rule.options;
        }
        currentRule.route = rule.route;
        currentRule.params = {
          ...currentRule.params,
          ...layer.params
        };
      } else if (rule.options !== false) {
        routeRules[rule.name] = {
          ...rule,
          params: layer.params
        };
      }
    }
  }
  const middleware = [];
  const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
  for (const rule of orderedRules) {
    if (rule.options === false || !rule.handler) {
      continue;
    }
    middleware.push(rule.handler(rule));
  }
  return {
    routeRules,
    routeRuleMiddleware: middleware
  };
}
function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
  process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
  process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
const tracingSrvxPlugins = [];
const _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
const port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
const host = process.env.NITRO_HOST || process.env.HOST;
const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const nitroApp = useNitroApp();
serve({
  port,
  hostname: host,
  tls: cert && key ? {
    cert,
    key
  } : void 0,
  fetch: nitroApp.fetch,
  plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
const nodeServer = {};
export {
  nodeServer as default
};
