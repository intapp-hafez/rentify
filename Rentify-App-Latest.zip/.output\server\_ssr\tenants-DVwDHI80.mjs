import { s as supabase } from "./router-ChN6Fncz.mjs";
const getTenants = async () => {
  const { data, error } = await supabase.from("tenants").select("*").order("created_at", { ascending: false });
  if (error) {
    throw new Error(error.message);
  }
  return data;
};
const addTenant = async (tenant) => {
  const { data, error } = await supabase.from("tenants").insert([tenant]).select().single();
  if (error) {
    throw new Error(error.message);
  }
  return data;
};
const updateTenant = async ({ id, ...updateData }) => {
  const { data, error } = await supabase.from("tenants").update(updateData).eq("id", id).select().single();
  if (error) {
    throw new Error(error.message);
  }
  return data;
};
const deleteTenant = async (id) => {
  const { error } = await supabase.from("tenants").delete().eq("id", id);
  if (error) {
    throw new Error(error.message);
  }
};
export {
  addTenant as a,
  deleteTenant as d,
  getTenants as g,
  updateTenant as u
};
