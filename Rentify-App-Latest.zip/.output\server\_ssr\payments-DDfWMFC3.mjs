import { s as supabase } from "./router-ChN6Fncz.mjs";
const getPayments = async () => {
  const { data, error } = await supabase.from("payments").select("*, contracts(number, unit_id, units(title, number), tenants(full_name))").order("created_at", { ascending: false });
  if (error) {
    throw new Error(error.message);
  }
  return data;
};
const addPayment = async (payment) => {
  const { data, error } = await supabase.from("payments").insert([payment]).select().single();
  if (error) {
    throw new Error(error.message);
  }
  return data;
};
const updatePayment = async ({ id, ...updateData }) => {
  const { data, error } = await supabase.from("payments").update(updateData).eq("id", id).select().single();
  if (error) {
    throw new Error(error.message);
  }
  return data;
};
const deletePayment = async (id) => {
  const { error } = await supabase.from("payments").delete().eq("id", id);
  if (error) {
    throw new Error(error.message);
  }
};
export {
  addPayment as a,
  deletePayment as d,
  getPayments as g,
  updatePayment as u
};
