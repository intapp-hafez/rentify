import { s as supabase } from "./router-ChN6Fncz.mjs";
const getUnits = async () => {
  const { data, error } = await supabase.from("units").select("*").order("created_at", { ascending: false });
  if (error) {
    throw new Error(error.message);
  }
  return data;
};
const addUnit = async (unit) => {
  const { data, error } = await supabase.from("units").insert([unit]).select().single();
  if (error) {
    throw new Error(error.message);
  }
  return data;
};
const updateUnit = async ({ id, ...updateData }) => {
  const { data, error } = await supabase.from("units").update(updateData).eq("id", id).select().single();
  if (error) {
    throw new Error(error.message);
  }
  return data;
};
const deleteUnit = async (id) => {
  const { error } = await supabase.from("units").delete().eq("id", id);
  if (error) {
    throw new Error(error.message);
  }
};
export {
  addUnit as a,
  deleteUnit as d,
  getUnits as g,
  updateUnit as u
};
