import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { u as useRouter, L as Link } from "../_libs/tanstack__react-router.mjs";
import { A as AppLayout } from "./AppLayout-D343eYEX.mjs";
import { B as Button } from "./button-DL752WFK.mjs";
import { S as StatusBadge } from "./StatusBadge-yA9h_bRJ.mjs";
import { E as EmptyState, D as DetailGrid, S as SectionTitle, P as PayNowDialog } from "./PayNowDialog-B6LlFtaC.mjs";
import { C as CrudDialog, e as ConfirmDelete } from "./ConfirmDelete-DuL2SYKU.mjs";
import { b as Route, e as egp } from "./router-D3vpDMsI.mjs";
import { a as useQueryClient, u as useQuery, b as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { u as updateContract, d as deleteContract, g as getContracts } from "./contracts-fNjmsRpA.mjs";
import { g as getPayments } from "./payments-CqySaxzc.mjs";
import { u as updateDeposit, a as getDepositByContractId } from "./deposits-scwjt4AQ.mjs";
import { g as getUnits } from "./units-DFEKe7B8.mjs";
import { g as getTenants } from "./tenants-CkyNSj6k.mjs";
import { j as jsPDF } from "../_libs/jspdf.mjs";
import { h as html2canvas } from "../_libs/html2canvas.mjs";
import { p as parseISO, c as startOfDay, h as isAfter, f as format, g as addMonths, l as subDays, i as isBefore } from "../_libs/date-fns.mjs";
import { J as ArrowRight, r as Pencil, s as Trash2, E as ShieldCheck, V as FileDown } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/cmdk.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-effect-event+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-dropdown-menu.mjs";
import "../_libs/radix-ui__react-menu.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-roving-focus.mjs";
import "../_libs/class-variance-authority.mjs";
import "./card-RGlIzTYo.mjs";
import "./input-C0QjszdI.mjs";
import "./label-JU3yqRBo.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-select.mjs";
import "../_libs/radix-ui__number.mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "../_libs/radix-ui__react-alert-dialog.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/supabase__functions-js.mjs";
import "fs";
import "path";
import "../_libs/fflate.mjs";
import "../_libs/fast-png.mjs";
import "../_libs/iobuffer.mjs";
import "../_libs/pako.mjs";
import "../_libs/dompurify.mjs";
import "../_libs/canvg.mjs";
import "../_libs/core-js.mjs";
import "../_libs/babel__runtime.mjs";
import "../_libs/raf.mjs";
import "../_libs/performance-now.mjs";
import "../_libs/rgbcolor.mjs";
import "../_libs/svg-pathdata.mjs";
import "../_libs/stackblur-canvas.mjs";
const contractStatuses = ["نشط", "عقد منتهي", "محجوز"];
const getContractStatus = (status, endDate) => {
  if (status === "نشط" && endDate && isBefore(new Date(endDate), startOfDay(/* @__PURE__ */ new Date()))) {
    return "عقد منتهي";
  }
  return status || "نشط";
};
function ContractDetail() {
  const {
    id
  } = Route.useParams();
  const router = useRouter();
  const queryClient = useQueryClient();
  const scheduleRef = reactExports.useRef(null);
  const {
    data: contracts = [],
    isLoading
  } = useQuery({
    queryKey: ["contracts"],
    queryFn: getContracts
  });
  const {
    data: payments = []
  } = useQuery({
    queryKey: ["payments"],
    queryFn: getPayments
  });
  const {
    data: units = []
  } = useQuery({
    queryKey: ["units"],
    queryFn: getUnits
  });
  const {
    data: tenants = []
  } = useQuery({
    queryKey: ["tenants"],
    queryFn: getTenants
  });
  const updateMutation = useMutation({
    mutationFn: updateContract,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["contracts"]
      });
      toast.success("تم تحديث العقد بنجاح");
    },
    onError: (e) => toast.error(e.message)
  });
  const deleteMutation = useMutation({
    mutationFn: deleteContract,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["contracts"]
      });
      toast.success("تم حذف العقد بنجاح");
      router.navigate({
        to: "/contracts"
      });
    },
    onError: (e) => toast.error(e.message)
  });
  const contract = contracts.find((c) => c.id === id);
  const {
    data: depositInfo
  } = useQuery({
    queryKey: ["contract-deposit", id],
    queryFn: () => getDepositByContractId(id),
    enabled: !!contract && (contract.deposit || 0) > 0
  });
  const settleDepositMutation = useMutation({
    mutationFn: updateDeposit,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["contract-deposit", id]
      });
      queryClient.invalidateQueries({
        queryKey: ["deposits"]
      });
      toast.success("تم تسوية التأمين بنجاح");
    },
    onError: (e) => toast.error(e.message)
  });
  const contractPayments = reactExports.useMemo(() => payments.filter((p) => p.contract_id === id), [payments, id]);
  const paymentsByDate = reactExports.useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    contractPayments.forEach((p) => map.set(p.payment_date, p));
    return map;
  }, [contractPayments]);
  const schedule = reactExports.useMemo(() => {
    if (!contract?.start_date || !contract?.end_date) return [];
    const start = parseISO(contract.start_date);
    const end = parseISO(contract.end_date);
    const freq = contract.payment_frequency;
    const monthsPerPeriod2 = freq === "quarterly" || freq === "كل 3 شهور" || freq === "ربع سنوي" ? 3 : freq === "semiannual" || freq === "كل 6 شهور" ? 6 : freq === "yearly" || freq === "سنوي" ? 12 : 1;
    const amount = contract.rent_amount * monthsPerPeriod2;
    const today = startOfDay(/* @__PURE__ */ new Date());
    const rows = [];
    let current = start;
    let installment = 1;
    while (!isAfter(current, end)) {
      const dateStr = format(current, "yyyy-MM-dd");
      const existing = paymentsByDate.get(dateStr);
      const nextStart = addMonths(current, monthsPerPeriod2);
      const rawEnd = subDays(nextStart);
      const periodEndActual = isAfter(rawEnd, end) ? end : rawEnd;
      let status;
      if (existing?.status === "مدفوع") {
        status = "مدفوع";
      } else if (isBefore(current, today)) {
        status = "متأخر";
      } else {
        status = "مستحق";
      }
      rows.push({
        id: dateStr,
        installment,
        payment_date: dateStr,
        period_start: dateStr,
        period_end: format(periodEndActual, "yyyy-MM-dd"),
        months: monthsPerPeriod2,
        amount,
        status,
        receipt_number: existing?.receipt_number ?? null,
        payment_method: existing?.payment_method ?? null
      });
      installment++;
      current = addMonths(current, monthsPerPeriod2);
    }
    return rows;
  }, [contract?.start_date, contract?.end_date, contract?.payment_frequency, contract?.rent_amount, paymentsByDate]);
  if (isLoading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(AppLayout, { title: "جاري التحميل...", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-8 w-8 animate-spin rounded-full border-b-2 border-primary" }) }) });
  }
  if (!contract) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(AppLayout, { title: "العقد غير موجود", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(EmptyState, { children: [
      "لم يتم العثور على هذا العقد.",
      " ",
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "link", onClick: () => router.navigate({
        to: "/contracts"
      }), children: "العودة للعقود" })
    ] }) });
  }
  const dueRows = schedule.filter((r) => r.status === "مستحق" || r.status === "متأخر");
  const paidRows = schedule.filter((r) => r.status === "مدفوع");
  const totalScheduled = schedule.reduce((s, r) => s + r.amount, 0);
  const totalPaid = paidRows.reduce((s, r) => s + r.amount, 0);
  const totalDue = dueRows.reduce((s, r) => s + r.amount, 0);
  const monthsPerPeriod = schedule[0]?.months ?? 1;
  const perPaymentAmount = contract.rent_amount * monthsPerPeriod;
  const firstPeriod = schedule[0];
  const handleExportPdf = async () => {
    const node = scheduleRef.current;
    if (!node) return;
    toast.info("جاري تجهيز ملف PDF...");
    try {
      const canvas = await html2canvas(node, {
        scale: 2,
        backgroundColor: "#ffffff",
        useCORS: true
      });
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF({
        orientation: "portrait",
        unit: "pt",
        format: "a4"
      });
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const margin = 20;
      const imgWidth = pageWidth - margin * 2;
      const imgHeight = canvas.height * imgWidth / canvas.width;
      let heightLeft = imgHeight;
      let position = margin;
      pdf.addImage(imgData, "PNG", margin, position, imgWidth, imgHeight);
      heightLeft -= pageHeight - margin * 2;
      while (heightLeft > 0) {
        pdf.addPage();
        position = margin - (imgHeight - heightLeft);
        pdf.addImage(imgData, "PNG", margin, position, imgWidth, imgHeight);
        heightLeft -= pageHeight - margin * 2;
      }
      pdf.save(`schedule-${contract.number || contract.id}.pdf`);
      toast.success("تم تصدير الجدول بصيغة PDF");
    } catch (e) {
      toast.error("فشل التصدير: " + (e?.message || "خطأ غير معروف"));
    }
  };
  const freqLabel = monthsPerPeriod === 1 ? "شهري" : monthsPerPeriod === 3 ? "كل 3 شهور" : monthsPerPeriod === 6 ? "كل 6 شهور" : "سنوي";
  const fields = [{
    name: "number",
    label: "رقم العقد"
  }, {
    name: "tenant_id",
    label: "المستأجر",
    type: "select",
    options: tenants.map((t) => ({
      value: t.id,
      label: t.full_name
    }))
  }, {
    name: "unit_id",
    label: "الوحدة",
    type: "select",
    options: units.map((u) => ({
      value: u.id,
      label: `${u.title} - ${u.number || ""}`
    })),
    onChange: (val, setValues) => {
      const unit = units.find((u) => u.id === val);
      setValues((prev) => ({
        ...prev,
        unit_id: val,
        ...unit?.rent_price ? {
          rent_amount: unit.rent_price
        } : {}
      }));
    }
  }, {
    name: "start_date",
    label: "تاريخ البداية",
    type: "date"
  }, {
    name: "end_date",
    label: "تاريخ النهاية",
    type: "date"
  }, {
    name: "rent_amount",
    label: "الإيجار (شهري)",
    type: "number"
  }, {
    name: "deposit",
    label: "التأمين",
    type: "number"
  }, {
    name: "payment_frequency",
    label: "دورية الدفع",
    type: "select",
    options: [{
      value: "monthly",
      label: "شهري"
    }, {
      value: "quarterly",
      label: "كل 3 شهور"
    }, {
      value: "semiannual",
      label: "كل 6 شهور"
    }, {
      value: "yearly",
      label: "سنوي"
    }]
  }, {
    name: "total_rent_sum",
    label: "",
    type: "custom",
    colSpan: 2,
    hidden: (v) => !v.payment_frequency || v.payment_frequency === "monthly" || !v.rent_amount,
    render: (v) => {
      const rent = Number(v.rent_amount) || 0;
      let multiplier = 1;
      if (v.payment_frequency === "quarterly") multiplier = 3;
      else if (v.payment_frequency === "semiannual") multiplier = 6;
      else if (v.payment_frequency === "yearly") multiplier = 12;
      return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-md bg-primary/10 p-3 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-sm font-semibold text-primary", children: [
          "إجمالي الإيجار (",
          v.payment_frequency === "quarterly" ? "كل 3 شهور" : v.payment_frequency === "semiannual" ? "كل 6 شهور" : "سنوي",
          ")"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-bold text-primary", children: [
          (rent * multiplier).toLocaleString(),
          " ج.م"
        ] })
      ] });
    }
  }, {
    name: "status",
    label: "الحالة",
    type: "select",
    options: contractStatuses
  }];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(AppLayout, { title: `عقد ${contract.number || "بدون رقم"}`, subtitle: `${contract.units?.title} - ${contract.units?.number || ""}`, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, variant: "outline", size: "sm", className: "gap-1", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/contracts", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "h-4 w-4" }),
        " العقود"
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CrudDialog, { title: "تعديل عقد", fields, initial: contract, onSubmit: (v) => updateMutation.mutate({
          ...v,
          id: contract.id
        }), trigger: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", size: "sm", className: "gap-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-4 w-4" }),
          " تعديل"
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ConfirmDelete, { description: `سيتم حذف العقد "${contract.number || "بدون رقم"}".`, onConfirm: () => deleteMutation.mutate(contract.id), trigger: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "destructive", size: "sm", className: "gap-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }),
          " حذف"
        ] }) }),
        depositInfo && depositInfo.status === "held" && /* @__PURE__ */ jsxRuntimeExports.jsx(CrudDialog, { title: "تسوية التأمين", fields: [{
          name: "status",
          label: "حالة التأمين",
          type: "select",
          options: [{
            value: "returned",
            label: "مسترد بالكامل"
          }, {
            value: "deducted",
            label: "مخصوم (جزئياً أو كلياً)"
          }, {
            value: "transferred",
            label: "مُرحّل لعقد آخر"
          }]
        }, {
          name: "notes",
          label: "ملاحظات الخصم / الترحيل",
          type: "textarea",
          colSpan: 2
        }], initial: {
          status: "returned",
          notes: ""
        }, onSubmit: (v) => settleDepositMutation.mutate({
          id: depositInfo.id,
          ...v
        }), submitLabel: "حفظ التسوية", trigger: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", size: "sm", className: "gap-1 text-orange-600 border-orange-200 bg-orange-50 hover:bg-orange-100 hover:text-orange-700", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "h-4 w-4" }),
          " تسوية التأمين"
        ] }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(DetailGrid, { items: [{
      label: "المستأجر",
      value: contract.tenant_id ? /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/tenants/$id", params: {
        id: contract.tenant_id
      }, className: "text-primary hover:underline", children: contract.tenants?.full_name }) : "—"
    }, {
      label: "الوحدة",
      value: contract.unit_id ? /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/units/$id", params: {
        id: contract.unit_id
      }, className: "text-primary hover:underline", children: [
        contract.units?.title,
        " - ",
        contract.units?.number || ""
      ] }) : "—"
    }, {
      label: "تاريخ البداية",
      value: contract.start_date
    }, {
      label: "تاريخ النهاية",
      value: contract.end_date
    }, {
      label: "دورية الدفع",
      value: contract.payment_frequency === "monthly" ? "شهري" : contract.payment_frequency === "quarterly" ? "كل 3 شهور" : contract.payment_frequency === "semiannual" ? "كل 6 شهور" : "سنوي"
    }, {
      label: "الإيجار",
      value: egp(contract.rent_amount)
    }, {
      label: "التأمين",
      value: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        egp(contract.deposit || 0),
        depositInfo && /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { status: depositInfo.status === "held" ? "محتجز" : depositInfo.status === "returned" ? "مسترد" : depositInfo.status === "deducted" ? "مخصوم" : "مُرحّل" })
      ] })
    }, {
      label: "الحالة",
      value: /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { status: getContractStatus(contract.status, contract.end_date) })
    }] }),
    firstPeriod && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 rounded-xl border border-primary/30 bg-primary/5 p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-2 text-sm font-semibold text-primary", children: "ملخص دورية الدفع" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3 text-sm sm:grid-cols-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground", children: "الدورية" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold", children: freqLabel })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground", children: "عدد الشهور لكل دفعة" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-semibold", children: [
            monthsPerPeriod,
            " شهر"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground", children: "فترة أول قسط" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-semibold tabular-nums", children: [
            firstPeriod.period_start,
            " → ",
            firstPeriod.period_end
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground", children: "مبلغ الدفعة (محسوب)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold text-primary", children: egp(perPaymentAmount) })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "my-6 grid grid-cols-3 gap-3 text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card p-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "إجمالي الجدول" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg font-bold", children: egp(totalScheduled) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-muted-foreground", children: [
          schedule.length,
          " قسط"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-emerald-700", children: "تم التحصيل" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg font-bold text-emerald-700", children: egp(totalPaid) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-emerald-700", children: [
          paidRows.length,
          " دفعة"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-amber-500/30 bg-amber-500/10 p-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-amber-700", children: "المتبقي" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg font-bold text-amber-700", children: egp(totalDue) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-amber-700", children: [
          dueRows.length,
          " دفعة"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(SectionTitle, { children: "جدول الدفعات الكامل" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", size: "sm", className: "gap-1", onClick: handleExportPdf, disabled: schedule.length === 0, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(FileDown, { className: "h-4 w-4" }),
        " تصدير PDF"
      ] })
    ] }),
    schedule.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { children: "لا يمكن حساب الجدول — تحقق من تواريخ العقد." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { ref: scheduleRef, className: "overflow-x-auto rounded-xl border border-border bg-card", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-sm", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-b border-border bg-muted/50 text-right", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold", children: "#" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold", children: "بداية الفترة" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold", children: "نهاية الفترة" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold", children: "عدد الشهور" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold", children: "المبلغ" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold", children: "الإيصال" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold", children: "الطريقة" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold", children: "الحالة" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { children: schedule.map((row) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: `border-b border-border transition-colors last:border-0 ${row.status === "مدفوع" ? "bg-emerald-500/5" : row.status === "متأخر" ? "bg-red-500/5" : ""}`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 font-bold text-muted-foreground", children: row.installment }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 tabular-nums", children: row.period_start }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 tabular-nums", children: row.period_end }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 tabular-nums", children: row.months }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 font-semibold", children: egp(row.amount) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 text-muted-foreground", children: row.receipt_number || "—" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 text-muted-foreground", children: row.payment_method || "—" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { status: row.status }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3", children: row.status !== "مدفوع" && /* @__PURE__ */ jsxRuntimeExports.jsx(PayNowDialog, { contractId: contract.id, amount: row.amount, dueDate: row.payment_date, installment: row.installment }) })
      ] }, row.id)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(SectionTitle, { children: "سجل الدفعات المحصلة" }),
    paidRows.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { children: "لا توجد دفعات محصلة مسجلة." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto rounded-xl border border-border", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-sm", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-b border-border bg-muted/50 text-right", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold", children: "#" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold", children: "التاريخ" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold", children: "المبلغ" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold", children: "الإيصال" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold", children: "الطريقة" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { children: paidRows.map((row) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-b border-border bg-emerald-500/5 last:border-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 font-bold text-muted-foreground", children: row.installment }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 tabular-nums", children: row.payment_date }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 font-semibold", children: egp(row.amount) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3", children: row.receipt_number || "—" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3", children: row.payment_method || "—" })
      ] }, row.id)) })
    ] }) })
  ] });
}
export {
  ContractDetail as component
};
