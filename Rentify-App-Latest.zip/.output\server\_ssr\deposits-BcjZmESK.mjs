import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { a as useQueryClient, u as useQuery, b as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { A as AppLayout } from "./AppLayout-D343eYEX.mjs";
import { B as Button } from "./button-DL752WFK.mjs";
import { D as DataTable } from "./DataTable-lfA95yU8.mjs";
import { S as StatusBadge } from "./StatusBadge-yA9h_bRJ.mjs";
import { C as CrudDialog, e as ConfirmDelete } from "./ConfirmDelete-DuL2SYKU.mjs";
import { u as updateDeposit, d as deleteDeposit, g as getDeposits } from "./deposits-scwjt4AQ.mjs";
import { e as egp } from "./router-D3vpDMsI.mjs";
import { r as Pencil, s as Trash2 } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/cmdk.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-effect-event+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-dropdown-menu.mjs";
import "../_libs/radix-ui__react-menu.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-roving-focus.mjs";
import "../_libs/date-fns.mjs";
import "../_libs/class-variance-authority.mjs";
import "./card-RGlIzTYo.mjs";
import "./input-C0QjszdI.mjs";
import "./label-JU3yqRBo.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-select.mjs";
import "../_libs/radix-ui__number.mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "../_libs/radix-ui__react-alert-dialog.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/supabase__functions-js.mjs";
const depositStatuses = [{
  value: "held",
  label: "محتجز"
}, {
  value: "returned",
  label: "مسترد"
}, {
  value: "deducted",
  label: "مخصوم"
}, {
  value: "transferred",
  label: "مُرحّل"
}];
function getStatusLabel(status) {
  return depositStatuses.find((s) => s.value === status)?.label || status;
}
function Deposits() {
  const queryClient = useQueryClient();
  const [page, setPage] = reactExports.useState(1);
  const PAGE_SIZE = 10;
  const {
    data: deposits = [],
    isLoading,
    isError,
    error
  } = useQuery({
    queryKey: ["deposits"],
    queryFn: getDeposits,
    throwOnError: false
  });
  const updateMutation = useMutation({
    mutationFn: updateDeposit,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["deposits"]
      });
      toast.success("تم تحديث التأمين بنجاح");
    },
    onError: (error2) => toast.error(error2.message)
  });
  const deleteMutation = useMutation({
    mutationFn: deleteDeposit,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["deposits"]
      });
      toast.success("تم حذف التأمين بنجاح");
    },
    onError: (error2) => toast.error(error2.message)
  });
  const fields = [{
    name: "amount",
    label: "المبلغ",
    type: "number"
  }, {
    name: "status",
    label: "الحالة",
    type: "select",
    options: depositStatuses
  }, {
    name: "notes",
    label: "ملاحظات",
    type: "textarea",
    colSpan: 2
  }];
  const columns = [{
    key: "tenant_id",
    header: "المستأجر",
    render: (r) => r.tenants?.full_name || "-"
  }, {
    key: "contract_id",
    header: "رقم العقد",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/contracts/$id", params: {
      id: r.contract_id
    }, className: "text-primary hover:underline", children: r.contracts?.number || "عرض العقد" })
  }, {
    key: "amount",
    header: "المبلغ",
    render: (r) => egp(r.amount)
  }, {
    key: "status",
    header: "الحالة",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { status: getStatusLabel(r.status) })
  }, {
    key: "notes",
    header: "ملاحظات",
    render: (r) => r.notes || "-"
  }, {
    key: "actions",
    header: "إجراءات",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-1", onClick: (e) => e.stopPropagation(), children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CrudDialog, { title: "تعديل حالة التأمين", fields, initial: r, onSubmit: (v) => updateMutation.mutate({
        id: r.id,
        ...v
      }), trigger: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "icon", variant: "ghost", className: "h-8 w-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-4 w-4" }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(ConfirmDelete, { description: `سيتم حذف تأمين العقد نهائياً.`, onConfirm: () => deleteMutation.mutate(r.id), trigger: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "icon", variant: "ghost", className: "h-8 w-8 text-destructive", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) }) })
    ] })
  }];
  if (isError) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(AppLayout, { title: "التأمينات", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-red-200 bg-red-50 p-6 text-red-700", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-bold mb-2", children: "خطأ في تحميل البيانات" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: error?.message }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-sm font-semibold", children: "Did you run the SQL migration `create_deposits_table.sql` in Supabase?" })
    ] }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(AppLayout, { title: "التأمينات", subtitle: "إدارة تأمينات العقود السارية والمنتهية", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-xl border border-border bg-card shadow-sm", children: isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-8 w-8 animate-spin rounded-full border-b-2 border-primary" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx(DataTable, { columns, rows: deposits, page, defaultPageSize: PAGE_SIZE, onPageChange: setPage }) }) });
}
export {
  Deposits as component
};
