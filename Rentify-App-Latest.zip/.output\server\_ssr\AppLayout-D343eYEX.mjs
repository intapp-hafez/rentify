import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link, d as useRouterState, e as useNavigate } from "../_libs/tanstack__react-router.mjs";
import { c as cn } from "./utils-H80jjgLf.mjs";
import { u as useAuth, s as supabase } from "./router-D3vpDMsI.mjs";
import { u as useQuery } from "../_libs/tanstack__react-query.mjs";
import { _ as _e } from "../_libs/cmdk.mjs";
import { D as Dialog$1, d as DialogTrigger$1, a as DialogPortal$1, c as DialogContent$1, h as DialogClose, f as DialogTitle$1, g as DialogDescription$1, b as DialogOverlay$1 } from "../_libs/radix-ui__react-dialog.mjs";
import { B as Button } from "./button-DL752WFK.mjs";
import { R as Root2, T as Trigger, P as Portal2, C as Content2, L as Label2, S as Separator2, I as Item2, a as SubTrigger2, b as SubContent2, c as CheckboxItem2, d as ItemIndicator2, e as RadioItem2 } from "../_libs/radix-ui__react-dropdown-menu.mjs";
import { X, M as Menu, P as Plus, B as Bell, L as LayoutDashboard, K as KeyRound, U as Users, F as FileText, W as Wallet, S as Shield, a as Wrench, C as ChartColumn, b as Settings, c as ChevronLeft, d as LogOut, e as Search, H as House, f as Crown, g as Banknote, h as Calendar, i as ChevronRight, j as Check, k as Circle } from "../_libs/lucide-react.mjs";
import { d as differenceInDays, p as parseISO, f as format, a as addDays, s as subMonths, b as startOfMonth, e as endOfMonth } from "../_libs/date-fns.mjs";
const sections = [
  { items: [{ label: "لوحة التحكم", to: "/dashboard", icon: LayoutDashboard }] },
  {
    title: "العقارات والعملاء",
    items: [
      { label: "الوحدات", to: "/units", icon: KeyRound },
      { label: "العملاء", to: "/tenants", icon: Users }
    ]
  },
  {
    title: "العمليات",
    items: [
      { label: "العقود", to: "/contracts", icon: FileText },
      { label: "التحصيلات", to: "/payments", icon: Wallet },
      { label: "التأمينات", to: "/deposits", icon: Shield },
      { label: "الصيانة", to: "/maintenance", icon: Wrench },
      { label: "الإشعارات", to: "/notifications", icon: Bell }
    ]
  },
  {
    title: "النظام",
    items: [
      { label: "التقارير", to: "/reports", icon: ChartColumn },
      { label: "الإعدادات", to: "/settings", icon: Settings }
    ]
  }
];
function AppSidebar({ onNavigate }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { user } = useAuth();
  const handleSignOut = async () => {
    await supabase.auth.signOut();
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("aside", { className: "flex h-full w-64 flex-col bg-sidebar text-sidebar-foreground", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 border-b border-sidebar-border px-5 py-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: "/logo.png", alt: "Rentify", className: "h-10 w-10 rounded-xl", width: 40, height: 40 }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-base font-extrabold leading-tight", children: "Rentify" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-sidebar-foreground/60", children: "إدارة العقارات" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("nav", { className: "flex-1 overflow-y-auto px-3 py-4", children: sections.map((section, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-5", children: [
      section.title && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-2 px-3 text-[11px] font-bold uppercase tracking-wider text-sidebar-foreground/40", children: section.title }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-1", children: section.items.map((item) => {
        const active = pathname === item.to;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Link,
          {
            to: item.to,
            onClick: onNavigate,
            className: cn(
              "group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
              active ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm" : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            ),
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(item.icon, { className: "h-[18px] w-[18px]" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex-1", children: item.label }),
              active && /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "h-4 w-4" })
            ]
          },
          item.to
        );
      }) })
    ] }, i)) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border-t border-sidebar-border p-4 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: "/logo.png", alt: "Avatar", className: "h-9 w-9 rounded-full bg-white p-1" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold max-w-[120px] truncate", children: user?.user_metadata?.full_name || "مدير النظام" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sidebar-foreground/60 max-w-[120px] truncate", title: user?.email, children: user?.email || "غير مسجل" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: handleSignOut, className: "text-sidebar-foreground/60 hover:text-destructive transition-colors p-2", title: "تسجيل الخروج", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "h-4 w-4" }) })
    ] })
  ] });
}
const globalSearch = async (query) => {
  if (!query || query.trim() === "") {
    return { units: [], tenants: [], contracts: [] };
  }
  const searchTerm = `%${query.trim()}%`;
  const [unitsRes, tenantsRes, contractsRes] = await Promise.all([
    supabase.from("units").select("id, title, number, type").or(`title.ilike.${searchTerm},number.ilike.${searchTerm},city.ilike.${searchTerm}`).limit(5),
    supabase.from("tenants").select("id, full_name, phone").or(`full_name.ilike.${searchTerm},phone.ilike.${searchTerm},civil_id.ilike.${searchTerm}`).limit(5),
    supabase.from("contracts").select("id, number, units(title)").or(`number.ilike.${searchTerm}`).limit(5)
  ]);
  if (unitsRes.error) console.error("Error searching units:", unitsRes.error);
  if (tenantsRes.error) console.error("Error searching tenants:", tenantsRes.error);
  if (contractsRes.error) console.error("Error searching contracts:", contractsRes.error);
  return {
    units: unitsRes.data || [],
    tenants: tenantsRes.data || [],
    // @ts-ignore
    contracts: contractsRes.data || []
  };
};
const Dialog = Dialog$1;
const DialogTrigger = DialogTrigger$1;
const DialogPortal = DialogPortal$1;
const DialogOverlay = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  DialogOverlay$1,
  {
    ref,
    className: cn(
      "fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className
    ),
    ...props
  }
));
DialogOverlay.displayName = DialogOverlay$1.displayName;
const DialogContent = reactExports.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogPortal, { children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx(DialogOverlay, {}),
  /* @__PURE__ */ jsxRuntimeExports.jsxs(
    DialogContent$1,
    {
      ref,
      className: cn(
        "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg",
        className
      ),
      ...props,
      children: [
        children,
        /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogClose, { className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "sr-only", children: "Close" })
        ] })
      ]
    }
  )
] }));
DialogContent.displayName = DialogContent$1.displayName;
const DialogHeader = ({ className, ...props }) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className), ...props });
DialogHeader.displayName = "DialogHeader";
const DialogFooter = ({ className, ...props }) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  "div",
  {
    className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
    ...props
  }
);
DialogFooter.displayName = "DialogFooter";
const DialogTitle = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  DialogTitle$1,
  {
    ref,
    className: cn("text-lg font-semibold leading-none tracking-tight", className),
    ...props
  }
));
DialogTitle.displayName = DialogTitle$1.displayName;
const DialogDescription = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  DialogDescription$1,
  {
    ref,
    className: cn("text-sm text-muted-foreground", className),
    ...props
  }
));
DialogDescription.displayName = DialogDescription$1.displayName;
const Command = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  _e,
  {
    ref,
    className: cn(
      "flex h-full w-full flex-col overflow-hidden rounded-md bg-popover text-popover-foreground",
      className
    ),
    ...props
  }
));
Command.displayName = _e.displayName;
const CommandDialog = ({ children, shouldFilter, ...props }) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { ...props, children: /* @__PURE__ */ jsxRuntimeExports.jsx(DialogContent, { className: "overflow-hidden p-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Command, { shouldFilter, className: "[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground [&_[cmdk-group]:not([hidden])_~[cmdk-group]]:pt-0 [&_[cmdk-group]]:px-2 [&_[cmdk-input-wrapper]_svg]:h-5 [&_[cmdk-input-wrapper]_svg]:w-5 [&_[cmdk-input]]:h-12 [&_[cmdk-item]]:px-2 [&_[cmdk-item]]:py-3 [&_[cmdk-item]_svg]:h-5 [&_[cmdk-item]_svg]:w-5", children }) }) });
};
const CommandInput = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center border-b px-3", "cmdk-input-wrapper": "", children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "mr-2 h-4 w-4 shrink-0 opacity-50" }),
  /* @__PURE__ */ jsxRuntimeExports.jsx(
    _e.Input,
    {
      ref,
      className: cn(
        "flex h-10 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50",
        className
      ),
      ...props
    }
  )
] }));
CommandInput.displayName = _e.Input.displayName;
const CommandList = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  _e.List,
  {
    ref,
    className: cn("max-h-[300px] overflow-y-auto overflow-x-hidden", className),
    ...props
  }
));
CommandList.displayName = _e.List.displayName;
const CommandEmpty = reactExports.forwardRef((props, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(_e.Empty, { ref, className: "py-6 text-center text-sm", ...props }));
CommandEmpty.displayName = _e.Empty.displayName;
const CommandGroup = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  _e.Group,
  {
    ref,
    className: cn(
      "overflow-hidden p-1 text-foreground [&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground",
      className
    ),
    ...props
  }
));
CommandGroup.displayName = _e.Group.displayName;
const CommandSeparator = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  _e.Separator,
  {
    ref,
    className: cn("-mx-1 h-px bg-border", className),
    ...props
  }
));
CommandSeparator.displayName = _e.Separator.displayName;
const CommandItem = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  _e.Item,
  {
    ref,
    className: cn(
      "relative flex cursor-default gap-2 select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none data-[disabled=true]:pointer-events-none data-[selected=true]:bg-accent data-[selected=true]:text-accent-foreground data-[disabled=true]:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
      className
    ),
    ...props
  }
));
CommandItem.displayName = _e.Item.displayName;
function GlobalSearch() {
  const [open, setOpen] = reactExports.useState(false);
  const [query, setQuery] = reactExports.useState("");
  const [debouncedQuery, setDebouncedQuery] = reactExports.useState("");
  const navigate = useNavigate();
  reactExports.useEffect(() => {
    const timer = setTimeout(() => setDebouncedQuery(query), 300);
    return () => clearTimeout(timer);
  }, [query]);
  reactExports.useEffect(() => {
    const down = (e) => {
      if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((open2) => !open2);
      }
    };
    document.addEventListener("keydown", down);
    return () => document.removeEventListener("keydown", down);
  }, []);
  const { data, isLoading } = useQuery({
    queryKey: ["globalSearch", debouncedQuery],
    queryFn: () => globalSearch(debouncedQuery),
    enabled: debouncedQuery.length > 0
  });
  const onSelect = (path) => {
    setOpen(false);
    navigate({ to: path });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: "relative hidden max-w-md flex-1 md:block cursor-text",
        onClick: () => setOpen(true),
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex h-10 w-full items-center justify-between rounded-lg border border-input bg-background pr-10 pl-3 text-sm text-muted-foreground hover:bg-accent/50 transition-colors", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "بحث شامل: عقار، وحدة، عقد، مستأجر..." }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("kbd", { className: "pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground opacity-100", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs", children: "⌘" }),
              "K"
            ] })
          ] })
        ]
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(CommandDialog, { open, onOpenChange: setOpen, shouldFilter: false, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        CommandInput,
        {
          placeholder: "ابحث هنا...",
          value: query,
          onValueChange: setQuery
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(CommandList, { children: [
        isLoading && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-4 text-center text-sm text-muted-foreground", children: "جاري البحث..." }),
        !isLoading && query.length > 0 && !data?.units.length && !data?.tenants.length && !data?.contracts.length && /* @__PURE__ */ jsxRuntimeExports.jsx(CommandEmpty, { children: "لا توجد نتائج مطابقة." }),
        data?.units && data.units.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(CommandGroup, { heading: "العقارات والوحدات", children: data.units.map((unit) => /* @__PURE__ */ jsxRuntimeExports.jsxs(CommandItem, { onSelect: () => onSelect(`/units/${unit.id}`), children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(House, { className: "ml-2 h-4 w-4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: unit.title }),
          unit.number && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "mr-2 text-muted-foreground", children: [
            "(",
            unit.number,
            ")"
          ] })
        ] }, unit.id)) }),
        data?.tenants && data.tenants.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(CommandGroup, { heading: "المستأجرين", children: data.tenants.map((tenant) => /* @__PURE__ */ jsxRuntimeExports.jsxs(CommandItem, { onSelect: () => onSelect(`/tenants/${tenant.id}`), children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "ml-2 h-4 w-4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: tenant.full_name }),
          tenant.phone && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mr-2 text-muted-foreground", children: tenant.phone })
        ] }, tenant.id)) }),
        data?.contracts && data.contracts.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(CommandGroup, { heading: "العقود", children: data.contracts.map((contract) => /* @__PURE__ */ jsxRuntimeExports.jsxs(CommandItem, { onSelect: () => onSelect(`/contracts/${contract.id}`), children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(FileText, { className: "ml-2 h-4 w-4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            "عقد #",
            contract.number || "بدون رقم"
          ] }),
          contract.units?.title && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "mr-2 text-muted-foreground", children: [
            "(",
            contract.units.title,
            ")"
          ] })
        ] }, contract.id)) })
      ] })
    ] })
  ] });
}
const getSubscription = async () => {
  const { data, error } = await supabase.from("subscriptions").select("*").order("created_at", { ascending: false }).limit(1).maybeSingle();
  if (error) throw new Error(error.message);
  return data;
};
function SubscriptionBadge() {
  const { data: sub, isLoading } = useQuery({
    queryKey: ["subscription"],
    queryFn: getSubscription,
    staleTime: 1e3 * 60 * 5
  });
  if (isLoading || !sub) return null;
  const remaining = differenceInDays(parseISO(sub.end_date), /* @__PURE__ */ new Date());
  const isExpired = remaining < 0;
  const isUrgent = remaining <= 7 && !isExpired;
  const urgencyClasses = isExpired ? "bg-red-500/15 border-red-500/30 text-red-600" : isUrgent ? "bg-amber-500/15 border-amber-500/30 text-amber-700" : "bg-emerald-500/10 border-emerald-500/25 text-emerald-700";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      className: `hidden items-center gap-3 rounded-lg border px-3 py-1.5 text-xs font-medium lg:flex ${urgencyClasses}`,
      title: `من ${sub.start_date} إلى ${sub.end_date}`,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Crown, { className: "h-3.5 w-3.5" }),
          sub.type
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "h-3 w-px bg-current opacity-30" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Banknote, { className: "h-3.5 w-3.5" }),
          Number(sub.value).toLocaleString("en-US", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
          }),
          " ",
          "EGP"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "h-3 w-px bg-current opacity-30" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "h-3.5 w-3.5" }),
          isExpired ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: "منتهي" }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold tabular-nums", children: remaining }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "opacity-80", children: "يوم متبقي" })
          ] })
        ] })
      ]
    }
  );
}
const DropdownMenu = Root2;
const DropdownMenuTrigger = Trigger;
const DropdownMenuSubTrigger = reactExports.forwardRef(({ className, inset, children, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
  SubTrigger2,
  {
    ref,
    className: cn(
      "flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent data-[state=open]:bg-accent [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
      inset && "pl-8",
      className
    ),
    ...props,
    children: [
      children,
      /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "ml-auto" })
    ]
  }
));
DropdownMenuSubTrigger.displayName = SubTrigger2.displayName;
const DropdownMenuSubContent = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  SubContent2,
  {
    ref,
    className: cn(
      "z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)",
      className
    ),
    ...props
  }
));
DropdownMenuSubContent.displayName = SubContent2.displayName;
const DropdownMenuContent = reactExports.forwardRef(({ className, sideOffset = 4, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(Portal2, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
  Content2,
  {
    ref,
    sideOffset,
    className: cn(
      "z-50 max-h-[var(--radix-dropdown-menu-content-available-height)] min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md",
      "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)",
      className
    ),
    ...props
  }
) }));
DropdownMenuContent.displayName = Content2.displayName;
const DropdownMenuItem = reactExports.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Item2,
  {
    ref,
    className: cn(
      "relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&>svg]:size-4 [&>svg]:shrink-0",
      inset && "pl-8",
      className
    ),
    ...props
  }
));
DropdownMenuItem.displayName = Item2.displayName;
const DropdownMenuCheckboxItem = reactExports.forwardRef(({ className, children, checked, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
  CheckboxItem2,
  {
    ref,
    className: cn(
      "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className
    ),
    checked,
    ...props,
    children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ItemIndicator2, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "h-4 w-4" }) }) }),
      children
    ]
  }
));
DropdownMenuCheckboxItem.displayName = CheckboxItem2.displayName;
const DropdownMenuRadioItem = reactExports.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
  RadioItem2,
  {
    ref,
    className: cn(
      "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className
    ),
    ...props,
    children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ItemIndicator2, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Circle, { className: "h-2 w-2 fill-current" }) }) }),
      children
    ]
  }
));
DropdownMenuRadioItem.displayName = RadioItem2.displayName;
const DropdownMenuLabel = reactExports.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Label2,
  {
    ref,
    className: cn("px-2 py-1.5 text-sm font-semibold", inset && "pl-8", className),
    ...props
  }
));
DropdownMenuLabel.displayName = Label2.displayName;
const DropdownMenuSeparator = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Separator2,
  {
    ref,
    className: cn("-mx-1 my-1 h-px bg-muted", className),
    ...props
  }
));
DropdownMenuSeparator.displayName = Separator2.displayName;
const getNotifications = async () => {
  const notifications = [];
  const today = /* @__PURE__ */ new Date();
  const { data: contracts } = await supabase.from("contracts").select("id, number, end_date, status, tenants(full_name)").eq("status", "نشط").gte("end_date", format(today, "yyyy-MM-dd")).lte("end_date", format(addDays(today, 60), "yyyy-MM-dd"));
  if (contracts) {
    for (const c of contracts) {
      const daysLeft = differenceInDays(new Date(c.end_date), today);
      const tenantName = c.tenants?.full_name || "مستأجر";
      notifications.push({
        id: `contract-${c.id}`,
        type: "contract",
        title: `عقد ينتهي خلال ${daysLeft} يوم`,
        body: `عقد المستأجر ${tenantName} رقم ${c.number || "-"} ينتهي في ${c.end_date}`,
        date: format(today, "yyyy-MM-dd"),
        read: false,
        link: { to: "/contracts/$id", params: { id: c.id } }
      });
    }
  }
  const { data: overdue } = await supabase.from("payments").select("id, amount, payment_date, contracts(number, tenants(full_name))").eq("status", "متأخر").order("payment_date", { ascending: true }).limit(10);
  if (overdue) {
    for (const p of overdue) {
      const contract = p.contracts;
      const tenantName = contract?.tenants?.full_name || "مستأجر";
      notifications.push({
        id: `payment-${p.id}`,
        type: "payment",
        title: "دفعة متأخرة",
        body: `المستأجر ${tenantName} متأخر في سداد دفعة بمبلغ ${p.amount} ج.م منذ ${p.payment_date}`,
        date: p.payment_date,
        read: false,
        link: { to: "/payments" }
      });
    }
  }
  const { data: maint } = await supabase.from("maintenance").select("id, number, description, type, priority, units(title, number)").in("status", ["جديد", "مفتوح", "pending"]).order("created_at", { ascending: false }).limit(10);
  if (maint) {
    for (const m of maint) {
      const unit = m.units;
      notifications.push({
        id: `maint-${m.id}`,
        type: "maintenance",
        title: `طلب صيانة جديد — ${m.type || "غير محدد"}`,
        body: `${m.description || "طلب صيانة"} في ${unit?.title || "وحدة"} ${unit?.number || ""}`,
        date: format(today, "yyyy-MM-dd"),
        read: false,
        link: { to: "/maintenance" }
      });
    }
  }
  const { data: vacant } = await supabase.from("units").select("id, title, number, created_at").eq("status", "available").lte("created_at", format(addDays(today, -7), "yyyy-MM-dd'T'HH:mm:ss")).limit(5);
  if (vacant) {
    for (const u of vacant) {
      notifications.push({
        id: `vacant-${u.id}`,
        type: "vacant",
        title: "وحدة شاغرة",
        body: `الوحدة ${u.title} رقم ${u.number || "-"} لا تزال شاغرة`,
        date: format(today, "yyyy-MM-dd"),
        read: false,
        link: { to: "/units/$id", params: { id: u.id } }
      });
    }
  }
  return notifications.sort((a, b) => b.date.localeCompare(a.date));
};
const getReportStats = async () => {
  const today = /* @__PURE__ */ new Date();
  const sixtyDaysLater = format(addDays(today, 60), "yyyy-MM-dd");
  const todayStr = format(today, "yyyy-MM-dd");
  const [
    { count: totalUnits },
    { count: rentedUnits },
    { count: availableUnits },
    { count: maintenanceUnits },
    { count: activeContracts },
    { count: expiringSoon },
    { count: expiredContracts },
    { data: payments },
    { count: totalTenants },
    { count: lateTenants },
    { count: totalMaint },
    { count: pendingMaint },
    { count: doneMaint }
  ] = await Promise.all([
    supabase.from("units").select("*", { count: "exact", head: true }),
    supabase.from("units").select("*", { count: "exact", head: true }).eq("status", "rented"),
    supabase.from("units").select("*", { count: "exact", head: true }).eq("status", "available"),
    supabase.from("units").select("*", { count: "exact", head: true }).eq("status", "maintenance"),
    supabase.from("contracts").select("*", { count: "exact", head: true }).eq("status", "نشط"),
    supabase.from("contracts").select("*", { count: "exact", head: true }).eq("status", "نشط").gte("end_date", todayStr).lte("end_date", sixtyDaysLater),
    supabase.from("contracts").select("*", { count: "exact", head: true }).eq("status", "عقد منتهي"),
    supabase.from("payments").select("amount, status, payment_date"),
    supabase.from("tenants").select("*", { count: "exact", head: true }),
    supabase.from("tenants").select("*", { count: "exact", head: true }).eq("status", "متأخر بالسداد"),
    supabase.from("maintenance").select("*", { count: "exact", head: true }),
    supabase.from("maintenance").select("*", { count: "exact", head: true }).in("status", ["جديد", "مفتوح", "pending"]),
    supabase.from("maintenance").select("*", { count: "exact", head: true }).in("status", ["مكتمل", "مغلق", "completed"])
  ]);
  const monthlyRevenue = [];
  for (let i = 5; i >= 0; i--) {
    const monthDate = subMonths(today, i);
    const start = format(startOfMonth(monthDate), "yyyy-MM-dd");
    const end = format(endOfMonth(monthDate), "yyyy-MM-dd");
    const monthName = format(monthDate, "MMM");
    const collected = (payments || []).filter((p) => p.status === "مدفوع" && p.payment_date >= start && p.payment_date <= end).reduce((sum, p) => sum + (p.amount || 0), 0);
    monthlyRevenue.push({ month: monthName, value: collected });
  }
  const allPayments = payments || [];
  return {
    units: { total: totalUnits || 0, rented: rentedUnits || 0, available: availableUnits || 0, maintenance: maintenanceUnits || 0 },
    contracts: { active: activeContracts || 0, expiringSoon: expiringSoon || 0, expired: expiredContracts || 0 },
    payments: {
      collected: allPayments.filter((p) => p.status === "مدفوع").reduce((s, p) => s + p.amount, 0),
      overdue: allPayments.filter((p) => p.status === "متأخر").reduce((s, p) => s + p.amount, 0),
      due: allPayments.filter((p) => p.status === "مستحق").reduce((s, p) => s + p.amount, 0),
      monthly: monthlyRevenue
    },
    tenants: { total: totalTenants || 0, late: lateTenants || 0 },
    maintenance: { total: totalMaint || 0, pending: pendingMaint || 0, done: doneMaint || 0 }
  };
};
const EVENT_KEY = "rentify-notifications-read";
const STORAGE_KEY = "rentify_read_notifications";
function useAppNotifications() {
  const { data: notifications = [], isLoading, isFetching, refetch } = useQuery({
    queryKey: ["notifications"],
    queryFn: getNotifications,
    staleTime: 5 * 60 * 1e3
  });
  const [readIds, setReadIds] = reactExports.useState(() => {
    try {
      if (typeof window !== "undefined") {
        const saved = localStorage.getItem(STORAGE_KEY);
        return saved ? new Set(JSON.parse(saved)) : /* @__PURE__ */ new Set();
      }
      return /* @__PURE__ */ new Set();
    } catch {
      return /* @__PURE__ */ new Set();
    }
  });
  reactExports.useEffect(() => {
    const handleStorage = () => {
      try {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) {
          setReadIds(new Set(JSON.parse(saved)));
        }
      } catch {
      }
    };
    window.addEventListener(EVENT_KEY, handleStorage);
    window.addEventListener("storage", handleStorage);
    return () => {
      window.removeEventListener(EVENT_KEY, handleStorage);
      window.removeEventListener("storage", handleStorage);
    };
  }, []);
  const saveReadIds = reactExports.useCallback((newIds) => {
    setReadIds(newIds);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(Array.from(newIds)));
    window.dispatchEvent(new CustomEvent(EVENT_KEY));
  }, []);
  const markRead = reactExports.useCallback((id) => {
    saveReadIds(/* @__PURE__ */ new Set([...readIds, id]));
  }, [readIds, saveReadIds]);
  const markAllRead = reactExports.useCallback(() => {
    saveReadIds(new Set(notifications.map((n) => n.id)));
  }, [notifications, saveReadIds]);
  const enriched = notifications.map((n) => ({ ...n, read: readIds.has(n.id) }));
  const unreadCount = enriched.filter((n) => !n.read).length;
  return {
    notifications: enriched,
    unreadCount,
    isLoading,
    isFetching,
    refetch,
    markRead,
    markAllRead
  };
}
const quickActions = [
  { label: "إضافة وحدة", to: "/units" },
  { label: "إنشاء عقد", to: "/contracts" },
  { label: "تسجيل دفعة", to: "/payments" },
  { label: "طلب صيانة", to: "/maintenance" }
];
function AppLayout({ title, subtitle, children }) {
  const [mobileOpen, setMobileOpen] = reactExports.useState(false);
  const { notifications, unreadCount: unread, markRead } = useAppNotifications();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex min-h-screen w-full bg-background", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "hidden border-l border-border lg:block", children: /* @__PURE__ */ jsxRuntimeExports.jsx(AppSidebar, {}) }),
    mobileOpen && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed inset-0 z-50 lg:hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-black/50", onClick: () => setMobileOpen(false) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute right-0 top-0 h-full", children: /* @__PURE__ */ jsxRuntimeExports.jsx(AppSidebar, { onNavigate: () => setMobileOpen(false) }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex min-w-0 flex-1 flex-col", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "sticky top-0 z-40 flex items-center gap-3 border-b border-border bg-card/80 px-4 py-3 backdrop-blur md:px-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "icon", className: "lg:hidden", onClick: () => setMobileOpen((v) => !v), children: mobileOpen ? /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-5 w-5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Menu, { className: "h-5 w-5" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(GlobalSearch, {}),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mr-auto flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SubscriptionBadge, {}),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(DropdownMenu, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "gold", size: "sm", className: "gap-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4" }),
              " إجراء سريع"
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(DropdownMenuContent, { align: "end", className: "w-48", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(DropdownMenuLabel, { children: "إجراءات سريعة" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(DropdownMenuSeparator, {}),
              quickActions.map((a) => /* @__PURE__ */ jsxRuntimeExports.jsx(DropdownMenuItem, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: a.to, children: a.label }) }, a.to))
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(DropdownMenu, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "ghost", size: "icon", className: "relative", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Bell, { className: "h-5 w-5" }),
              unread > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute right-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-bold text-destructive-foreground", children: unread })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(DropdownMenuContent, { align: "end", className: "w-80", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(DropdownMenuLabel, { children: "الإشعارات" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(DropdownMenuSeparator, {}),
              notifications.slice(0, 5).map((n) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
                DropdownMenuItem,
                {
                  onClick: () => markRead(n.id),
                  className: "flex-col items-start gap-0.5 whitespace-normal text-sm leading-relaxed",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2 font-semibold", children: [
                      !n.read && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "h-2 w-2 rounded-full bg-destructive" }),
                      n.title
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-muted-foreground", children: n.body })
                  ]
                },
                n.id
              )),
              /* @__PURE__ */ jsxRuntimeExports.jsx(DropdownMenuSeparator, {}),
              /* @__PURE__ */ jsxRuntimeExports.jsx(DropdownMenuItem, { asChild: true, className: "justify-center font-semibold text-primary", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/notifications", children: "عرض كل الإشعارات" }) })
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { className: "flex-1 px-4 py-6 md:px-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-extrabold text-foreground", children: title }),
          subtitle && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: subtitle })
        ] }),
        children
      ] })
    ] })
  ] });
}
export {
  AppLayout as A,
  Dialog as D,
  DialogTrigger as a,
  DialogContent as b,
  DialogHeader as c,
  DialogTitle as d,
  DialogDescription as e,
  DialogFooter as f,
  getReportStats as g,
  useAppNotifications as u
};
