import { u as utils, w as writeFileSync, r as readSync } from "../_libs/xlsx.mjs";
import { t as toast } from "../_libs/sonner.mjs";
const exportToExcel = (data, filename) => {
  try {
    const ws = utils.json_to_sheet(data);
    const wb = utils.book_new();
    utils.book_append_sheet(wb, ws, "Sheet1");
    writeFileSync(wb, `${filename}.xlsx`);
    toast.success("تم تصدير البيانات بنجاح");
  } catch (error) {
    console.error(error);
    toast.error("حدث خطأ أثناء تصدير البيانات");
  }
};
const importFromExcel = (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result);
        const workbook = readSync(data, { type: "array" });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const json = utils.sheet_to_json(worksheet);
        resolve(json);
      } catch (error) {
        reject(error);
      }
    };
    reader.onerror = (error) => reject(error);
    reader.readAsArrayBuffer(file);
  });
};
const downloadTemplate = (headers, filename) => {
  try {
    const ws = utils.aoa_to_sheet([headers]);
    const wb = utils.book_new();
    utils.book_append_sheet(wb, ws, "Template");
    writeFileSync(wb, `${filename}_template.xlsx`);
  } catch (error) {
    console.error(error);
    toast.error("حدث خطأ أثناء تحميل القالب");
  }
};
export {
  downloadTemplate as d,
  exportToExcel as e,
  importFromExcel as i
};
