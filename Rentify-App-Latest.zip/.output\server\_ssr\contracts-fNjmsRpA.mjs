import { s as supabase } from "./router-D3vpDMsI.mjs";
const getContracts = async () => {
  const { data, error } = await supabase.from("contracts").select("*, units(title, number), tenants(full_name)").order("created_at", { ascending: false });
  if (error) {
    throw new Error(error.message);
  }
  return data;
};
const addContract = async (contract) => {
  const { data, error } = await supabase.from("contracts").insert([contract]).select().single();
  if (error) {
    throw new Error(error.message);
  }
  if (data.deposit && data.deposit > 0) {
    await supabase.from("deposits").insert([{
      contract_id: data.id,
      tenant_id: data.tenant_id,
      amount: data.deposit,
      status: "held",
      notes: "تأمين العقد"
    }]);
  }
  return data;
};
const updateContract = async ({ id, ...updateData }) => {
  const { data, error } = await supabase.from("contracts").update(updateData).eq("id", id).select().single();
  if (error) {
    throw new Error(error.message);
  }
  return data;
};
const deleteContract = async (id) => {
  const { error } = await supabase.from("contracts").delete().eq("id", id);
  if (error) {
    throw new Error(error.message);
  }
};
export {
  addContract as a,
  deleteContract as d,
  getContracts as g,
  updateContract as u
};
