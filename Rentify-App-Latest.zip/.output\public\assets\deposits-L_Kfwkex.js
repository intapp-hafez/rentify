import{s as r}from"./index-BDl6EVWd.js";const n=async()=>{const{data:t,error:e}=await r.from("deposits").select(`
      *,
      contracts ( number, start_date, end_date ),
      tenants ( full_name )
    `).order("created_at",{ascending:!1});if(e)throw new Error(e.message);return t},c=async t=>{const{data:e,error:s}=await r.from("deposits").select("*").eq("contract_id",t).single();if(s&&s.code!=="PGRST116")throw new Error(s.message);return e},d=async({id:t,...e})=>{const{data:s,error:a}=await r.from("deposits").update(e).eq("id",t).select().single();if(a)throw new Error(a.message);return s},i=async t=>{const{error:e}=await r.from("deposits").delete().eq("id",t);if(e)throw new Error(e.message)};export{c as a,i as d,n as g,d as u};
