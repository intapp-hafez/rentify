import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { e as useNavigate, L as Link } from "../_libs/tanstack__react-router.mjs";
import { a as useQueryClient, u as useQuery, b as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { A as AppLayout } from "./AppLayout-BsiDHgiV.mjs";
import { B as Button } from "./button-DL752WFK.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { S as Select, a as SelectTrigger, b as SelectValue, c as SelectContent, d as SelectItem, C as CrudDialog, e as ConfirmDelete } from "./ConfirmDelete-Dl1P26PU.mjs";
import { D as DataTable } from "./DataTable-ZJdNVHD0.mjs";
import { S as StatusBadge } from "./StatusBadge-BmU038Ba.mjs";
import { f as findConflictingContract, n as normalizeDate, a as addContract, d as deleteContract, u as updateContract, g as getContracts } from "./contracts-CF5GNrDa.mjs";
import { g as getUnits } from "./units-jeYWXtjB.mjs";
import { g as getTenants } from "./tenants-DVwDHI80.mjs";
import { e as exportToExcel, d as downloadTemplate, i as importFromExcel } from "./excel-ncAzCXAJ.mjs";
import { e as egp } from "./router-ChN6Fncz.mjs";
import { g as Search, D as Download, r as FileSpreadsheet, s as Upload, P as Plus, F as FileText, t as Pencil, u as Trash2 } from "../_libs/lucide-react.mjs";
import { i as isBefore, c as startOfDay, f as format } from "../_libs/date-fns.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/cmdk.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-effect-event+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-dropdown-menu.mjs";
import "../_libs/radix-ui__react-menu.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-roving-focus.mjs";
import "../_libs/class-variance-authority.mjs";
import "./label-JU3yqRBo.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-select.mjs";
import "../_libs/radix-ui__number.mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "../_libs/radix-ui__react-alert-dialog.mjs";
import "./card-RGlIzTYo.mjs";
import "../_libs/xlsx.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/supabase__functions-js.mjs";
const getContractStatus = (status, endDate) => {
  if (status === "نشط" && endDate) {
    if (isBefore(new Date(endDate), startOfDay(/* @__PURE__ */ new Date()))) {
      return "عقد منتهي";
    }
  }
  return status || "نشط";
};
const contractStatuses = ["نشط", "عقد منتهي", "محجوز", "ملغي"];
function Contracts() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const fileInputRef = reactExports.useRef(null);
  const [page, setPage] = reactExports.useState(1);
  const [search, setSearch] = reactExports.useState("");
  const [statusFilter, setStatusFilter] = reactExports.useState("all");
  const {
    data: contracts = [],
    isLoading: loadingContracts
  } = useQuery({
    queryKey: ["contracts"],
    queryFn: getContracts
  });
  const {
    data: units = []
  } = useQuery({
    queryKey: ["units"],
    queryFn: getUnits
  });
  const {
    data: tenants = []
  } = useQuery({
    queryKey: ["tenants"],
    queryFn: getTenants
  });
  const filtered = reactExports.useMemo(() => {
    return contracts.filter((c) => {
      const q = search.trim().toLowerCase();
      const matchSearch = !q || c.number && c.number.toLowerCase().includes(q) || c.tenants?.full_name && c.tenants.full_name.toLowerCase().includes(q) || c.units?.title && c.units.title.toLowerCase().includes(q) || c.units?.number && c.units.number.toLowerCase().includes(q);
      const actualStatus = getContractStatus(c.status, c.end_date);
      const matchStatus = statusFilter === "all" || actualStatus === statusFilter || c.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [contracts, search, statusFilter]);
  const addMutation = useMutation({
    mutationFn: addContract,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["contracts"]
      });
      toast.success("تم إنشاء العقد بنجاح");
    },
    onError: (error) => toast.error(error.message)
  });
  const updateMutation = useMutation({
    mutationFn: updateContract,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["contracts"]
      });
      toast.success("تم تحديث العقد بنجاح");
    },
    onError: (error) => toast.error(error.message)
  });
  const deleteMutation = useMutation({
    mutationFn: deleteContract,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["contracts"]
      });
      toast.success("تم حذف العقد بنجاح");
    },
    onError: (error) => toast.error(error.message)
  });
  const fields = [{
    name: "number",
    label: "رقم العقد"
  }, {
    name: "tenant_id",
    label: "المستأجر",
    type: "select",
    options: tenants.map((t) => ({
      value: t.id,
      label: t.full_name
    }))
  }, {
    name: "unit_id",
    label: "الوحدة",
    type: "select",
    options: units.map((u) => ({
      value: u.id,
      label: `${u.title} - ${u.number || ""}`
    })),
    onChange: (val, setValues) => {
      const unit = units.find((u) => u.id === val);
      setValues((prev) => ({
        ...prev,
        unit_id: val,
        ...unit?.rent_price ? {
          rent_amount: unit.rent_price
        } : {}
      }));
    }
  }, {
    name: "start_date",
    label: "تاريخ البداية",
    type: "date"
  }, {
    name: "end_date",
    label: "تاريخ النهاية",
    type: "date"
  }, {
    name: "rent_amount",
    label: "الإيجار (شهري)",
    type: "number"
  }, {
    name: "deposit",
    label: "التأمين",
    type: "number"
  }, {
    name: "payment_frequency",
    label: "دورية الدفع",
    type: "select",
    options: [{
      value: "monthly",
      label: "شهري"
    }, {
      value: "quarterly",
      label: "كل 3 شهور"
    }, {
      value: "semiannual",
      label: "كل 6 شهور"
    }, {
      value: "yearly",
      label: "سنوي"
    }]
  }, {
    name: "total_rent_sum",
    label: "",
    type: "custom",
    colSpan: 2,
    hidden: (v) => !v.payment_frequency || v.payment_frequency === "monthly" || !v.rent_amount,
    render: (v) => {
      const rent = Number(v.rent_amount) || 0;
      let multiplier = 1;
      if (v.payment_frequency === "quarterly") multiplier = 3;
      else if (v.payment_frequency === "semiannual") multiplier = 6;
      else if (v.payment_frequency === "yearly") multiplier = 12;
      return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-md bg-primary/10 p-3 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-sm font-semibold text-primary", children: [
          "إجمالي الإيجار (",
          v.payment_frequency === "quarterly" ? "كل 3 شهور" : v.payment_frequency === "semiannual" ? "كل 6 شهور" : "سنوي",
          ")"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-bold text-primary", children: [
          (rent * multiplier).toLocaleString(),
          " ج.م"
        ] })
      ] });
    }
  }, {
    name: "status",
    label: "الحالة",
    type: "select",
    options: contractStatuses
  }, {
    name: "attachment_url",
    label: "مستند العقد المرفق (PDF / صورة)",
    type: "file",
    colSpan: 2
  }];
  const handleExport = () => {
    const exportData = filtered.map((c) => ({
      "رقم العقد": c.number,
      "اسم المستأجر": c.tenants?.full_name || "غير محدد",
      "الوحدة": `${c.units?.title} - ${c.units?.number || ""}`,
      "تاريخ البداية": c.start_date,
      "تاريخ النهاية": c.end_date,
      "الإيجار": c.rent_amount,
      "التأمين": c.deposit,
      "الحالة": getContractStatus(c.status, c.end_date)
    }));
    exportToExcel(exportData, "المنشآت_العقود");
  };
  const handleDownloadTemplate = () => {
    downloadTemplate(["number", "tenant_id", "unit_id", "start_date", "end_date", "rent_amount", "deposit", "status"], "Contracts_Template");
  };
  const validateAndCreateContract = (v) => {
    if (!v.unit_id) {
      toast.error("يرجى اختيار الوحدة");
      return false;
    }
    if (!v.start_date || !v.end_date) {
      toast.error("يرجى تحديد تاريخ البداية وتاريخ النهاية");
      return false;
    }
    if (normalizeDate(v.start_date) > normalizeDate(v.end_date)) {
      toast.error("تاريخ بداية العقد لا يمكن أن يكون بعد تاريخ النهاية");
      return false;
    }
    const conflict = findConflictingContract(contracts, {
      unitId: v.unit_id,
      startDate: v.start_date,
      endDate: v.end_date
    });
    if (conflict) {
      const unit = units.find((u) => u.id === v.unit_id);
      const unitName = unit ? `${unit.title}${unit.number ? ` - ${unit.number}` : ""}` : "الوحدة";
      const contractNum = conflict.number ? `(عقد رقم: ${conflict.number})` : "";
      toast.error(`لا يمكن إنشاء العقد: ${unitName} لديها عقد نشط بالفعل خلال الفترة من ${conflict.start_date} إلى ${conflict.end_date} ${contractNum}`, {
        duration: 6e3
      });
      return false;
    }
    addMutation.mutate({
      ...v,
      payment_frequency: v.payment_frequency || "monthly",
      status: v.status || "نشط"
    });
    return true;
  };
  const validateAndUpdateContract = (r, v) => {
    const targetUnitId = v.unit_id || r.unit_id;
    const targetStart = v.start_date || r.start_date;
    const targetEnd = v.end_date || r.end_date;
    if (targetStart && targetEnd && normalizeDate(targetStart) > normalizeDate(targetEnd)) {
      toast.error("تاريخ بداية العقد لا يمكن أن يكون بعد تاريخ النهاية");
      return false;
    }
    const conflict = findConflictingContract(contracts, {
      unitId: targetUnitId,
      startDate: targetStart,
      endDate: targetEnd,
      excludeContractId: r.id
    });
    if (conflict) {
      const unit = units.find((u) => u.id === targetUnitId);
      const unitName = unit ? `${unit.title}${unit.number ? ` - ${unit.number}` : ""}` : "الوحدة";
      const contractNum = conflict.number ? `(عقد رقم: ${conflict.number})` : "";
      toast.error(`لا يمكن تحديث العقد: ${unitName} لديها عقد نشط آخر خلال الفترة من ${conflict.start_date} إلى ${conflict.end_date} ${contractNum}`, {
        duration: 6e3
      });
      return false;
    }
    updateMutation.mutate({
      id: r.id,
      ...v
    });
    return true;
  };
  const handleImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const toastId = toast.loading("جاري تحليل الملف واستيراد البيانات...");
    try {
      const data = await importFromExcel(file);
      if (!data || data.length === 0) {
        toast.error("الملف فارغ أو لا يحتوي على بيانات صحيحة", {
          id: toastId
        });
        return;
      }
      let successCount = 0;
      let skippedCount = 0;
      const batchAdded = [];
      for (const row of data) {
        if (!row.tenant_id || !row.unit_id) continue;
        const startDate = row.start_date || format(/* @__PURE__ */ new Date(), "yyyy-MM-dd");
        const endDate = row.end_date || format(/* @__PURE__ */ new Date(), "yyyy-MM-dd");
        const conflict = findConflictingContract([...contracts, ...batchAdded], {
          unitId: row.unit_id,
          startDate,
          endDate
        });
        if (conflict) {
          skippedCount++;
          const unit = units.find((u) => u.id === row.unit_id);
          const unitName = unit ? `${unit.title}${unit.number ? ` - ${unit.number}` : ""}` : row.unit_id;
          toast.warning(`تم تخطي عقد للوحدة (${unitName}): يوجد عقد نشط خلال نفس الفترة (${startDate} إلى ${endDate})`);
          continue;
        }
        const newContract = await addMutation.mutateAsync({
          number: row.number?.toString() || null,
          tenant_id: row.tenant_id,
          unit_id: row.unit_id,
          start_date: startDate,
          end_date: endDate,
          rent_amount: Number(row.rent_amount) || 0,
          deposit: Number(row.deposit) || null,
          payment_frequency: row.payment_frequency || "monthly",
          status: row.status || "نشط"
        });
        batchAdded.push(newContract);
        successCount++;
      }
      queryClient.invalidateQueries({
        queryKey: ["contracts"]
      });
      if (skippedCount > 0) {
        toast.info(`تم استيراد ${successCount} عقد بنجاح وتخطي ${skippedCount} بسبب تعارض الفترات الزمنية`, {
          id: toastId
        });
      } else {
        toast.success(`تم استيراد ${successCount} عقد بنجاح`, {
          id: toastId
        });
      }
    } catch (error) {
      toast.error(`فشل الاستيراد: ${error?.message || "تأكد من استخدام القالب الصحيح"}`, {
        id: toastId
      });
      console.error("Import Error:", error);
    } finally {
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };
  const columns = [{
    key: "number",
    header: "رقم العقد",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/contracts/$id", params: {
      id: r.id
    }, className: "font-bold text-primary hover:underline", children: r.number || "بدون رقم" })
  }, {
    key: "tenant_id",
    header: "المستأجر",
    render: (r) => r.tenants?.full_name || "-"
  }, {
    key: "unit_id",
    header: "الوحدة",
    render: (r) => `${r.units?.title} - ${r.units?.number || ""}`
  }, {
    key: "start_date",
    header: "البداية",
    render: (r) => r.start_date
  }, {
    key: "end_date",
    header: "النهاية",
    render: (r) => r.end_date
  }, {
    key: "rent_amount",
    header: "الإيجار",
    render: (r) => egp(r.rent_amount)
  }, {
    key: "deposit",
    header: "التأمين",
    render: (r) => egp(r.deposit || 0)
  }, {
    key: "status",
    header: "الحالة",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { status: getContractStatus(r.status, r.end_date) })
  }, {
    key: "actions",
    header: "إجراءات",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-1", onClick: (e) => e.stopPropagation(), children: [
      r.attachment_url && /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "icon", variant: "ghost", className: "h-8 w-8 text-primary hover:bg-primary/10", title: "عرض/تنزيل العقد المرفق", onClick: () => {
        const win = window.open();
        if (win) {
          if (r.attachment_url?.startsWith("data:application/pdf")) {
            win.document.write(`<iframe src="${r.attachment_url}" frameborder="0" style="border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;" allowfullscreen></iframe>`);
          } else {
            win.document.write(`<img src="${r.attachment_url}" style="max-width:100%; height:auto; display:block; margin:20px auto; border-radius:8px;" />`);
          }
        }
      }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(FileText, { className: "h-4 w-4" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CrudDialog, { title: "تعديل عقد", fields, initial: r, onSubmit: (v) => validateAndUpdateContract(r, v), trigger: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "icon", variant: "ghost", className: "h-8 w-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-4 w-4" }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(ConfirmDelete, { description: `سيتم حذف العقد "${r.number || "بدون رقم"}".`, onConfirm: () => deleteMutation.mutate(r.id), trigger: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "icon", variant: "ghost", className: "h-8 w-8 text-destructive", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) }) })
    ] })
  }];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(AppLayout, { title: "العقود", subtitle: "إدارة العقود النشطة والمنتهية والتجديدات", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "my-4 rounded-xl border border-border bg-card p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 gap-3 md:grid-cols-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: search, onChange: (e) => {
          setSearch(e.target.value);
          setPage(1);
        }, placeholder: "بحث برقم العقد، اسم المستأجر، أو الوحدة...", className: "pr-9" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: statusFilter, onValueChange: (v) => {
        setStatusFilter(v);
        setPage(1);
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "الحالة" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectContent, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "all", children: "كل الحالات" }),
          contractStatuses.map((s) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: s, children: s }, s))
        ] })
      ] }),
      (search || statusFilter !== "all") && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "sm", onClick: () => {
        setSearch("");
        setStatusFilter("all");
        setPage(1);
      }, children: "مسح التصفية" }) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex flex-wrap items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", className: "gap-1 text-muted-foreground", onClick: handleExport, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "h-4 w-4" }),
          " تصدير Excel"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", className: "gap-1 text-muted-foreground", onClick: handleDownloadTemplate, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(FileSpreadsheet, { className: "h-4 w-4" }),
          " تحميل القالب"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", className: "gap-1 text-muted-foreground", onClick: () => fileInputRef.current?.click(), children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "h-4 w-4" }),
          " استيراد Excel"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "file", ref: fileInputRef, onChange: handleImport, accept: ".xlsx, .xls, .csv", className: "hidden" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CrudDialog, { title: "إنشاء عقد", fields, onSubmit: validateAndCreateContract, trigger: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { className: "gap-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4" }),
        " إنشاء عقد"
      ] }) })
    ] }),
    loadingContracts ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-8 w-8 animate-spin rounded-full border-b-2 border-primary" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx(DataTable, { columns, rows: filtered, onRowClick: (r) => navigate({
      to: "/contracts/$id",
      params: {
        id: r.id
      }
    }), page, defaultPageSize: 10, onPageChange: setPage })
  ] });
}
export {
  Contracts as component
};
