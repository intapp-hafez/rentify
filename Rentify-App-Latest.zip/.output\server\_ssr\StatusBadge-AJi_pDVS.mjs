import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { c as statusColors } from "./router-C7nVfvJ9.mjs";
import { c as cn } from "./utils-H80jjgLf.mjs";
function StatusBadge({ status }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "span",
    {
      className: cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold",
        statusColors[status] ?? "bg-muted text-muted-foreground border-border"
      ),
      children: status
    }
  );
}
export {
  StatusBadge as S
};
