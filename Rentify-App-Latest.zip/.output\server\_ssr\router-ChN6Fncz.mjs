import { b as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { Q as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { c as createRouter, a as createRootRouteWithContext, u as useRouter, L as Link, H as HeadContent, S as Scripts, b as createFileRoute, l as lazyRouteComponent, O as Outlet } from "../_libs/tanstack__react-router.mjs";
import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { c as createClient } from "../_libs/supabase__supabase-js.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
const appCss = "/assets/styles-Dao-kunJ.css";
function reportLovableError(error, context = {}) {
  if (typeof window === "undefined") return;
  window.__lovableEvents?.captureException?.(
    error,
    {
      source: "react_error_boundary",
      route: window.location.pathname,
      ...context
    },
    {
      mechanism: "react_error_boundary",
      handled: false,
      severity: "error"
    }
  );
}
const statusColors = {
  متاح: "bg-success/15 text-success border-success/30",
  مؤجر: "bg-info/15 text-info border-info/30",
  محجوز: "bg-gold/15 text-gold border-gold/40",
  "تحت الصيانة": "bg-[oklch(0.6_0.12_300)]/15 text-[oklch(0.5_0.14_300)] border-[oklch(0.6_0.12_300)]/30",
  "متأخر بالسداد": "bg-warning/15 text-warning border-warning/30",
  "عقد منتهي": "bg-destructive/15 text-destructive border-destructive/30",
  نشط: "bg-success/15 text-success border-success/30",
  مدفوع: "bg-success/15 text-success border-success/30",
  متأخر: "bg-warning/15 text-warning border-warning/30",
  مستحق: "bg-info/15 text-info border-info/30",
  "غير مدفوع": "bg-destructive/15 text-destructive border-destructive/30",
  عاجل: "bg-destructive/15 text-destructive border-destructive/30",
  مرتفع: "bg-warning/15 text-warning border-warning/30",
  متوسط: "bg-info/15 text-info border-info/30",
  منخفض: "bg-muted text-muted-foreground border-border",
  جديد: "bg-info/15 text-info border-info/30",
  "قيد التنفيذ": "bg-gold/15 text-gold border-gold/40",
  مكتمل: "bg-success/15 text-success border-success/30"
};
const paymentMethods = ["نقدي", "تحويل بنكي", "إنستاباي", "فودافون كاش", "بطاقة ائتمان"];
const properties = [
  { id: "p1", code: "PR-001", name: "برج النيل", governorate: "القاهرة", district: "التجمع الخامس", type: "شقة", units: 24, occupancy: 92 },
  { id: "p2", code: "PR-002", name: "أبراج المعادي", governorate: "القاهرة", district: "المعادي", type: "شقة", units: 36, occupancy: 78 },
  { id: "p3", code: "PR-003", name: "عمارة الهرم", governorate: "الجيزة", district: "الهرم", type: "شقة", units: 12, occupancy: 100 },
  { id: "p4", code: "PR-004", name: "كمبوند الياسمين", governorate: "القاهرة", district: "الرحاب", type: "فيلا", units: 18, occupancy: 67 },
  { id: "p5", code: "PR-005", name: "عمارات التجمع", governorate: "القاهرة", district: "التجمع الخامس", type: "شقة", units: 40, occupancy: 85 },
  { id: "p6", code: "PR-006", name: "أبراج سموحة", governorate: "الإسكندرية", district: "سموحة", type: "شقة", units: 28, occupancy: 71 },
  { id: "p7", code: "PR-007", name: "مول الشيخ زايد", governorate: "الجيزة", district: "الشيخ زايد", type: "محل تجاري", units: 32, occupancy: 88 },
  { id: "p8", code: "PR-008", name: "أبراج النصر", governorate: "القاهرة", district: "مدينة نصر", type: "مكتب إداري", units: 20, occupancy: 95 }
];
const units = [
  { id: "u1", number: "101", property: "برج النيل", floor: "الأول", area: 145, rooms: 3, baths: 2, status: "مؤجر", rent: 12e3 },
  { id: "u2", number: "102", property: "برج النيل", floor: "الأول", area: 120, rooms: 2, baths: 1, status: "متاح", rent: 9e3 },
  { id: "u3", number: "205", property: "أبراج المعادي", floor: "الثاني", area: 180, rooms: 4, baths: 3, status: "مؤجر", rent: 18e3 },
  { id: "u4", number: "301", property: "كمبوند الياسمين", floor: "الأرضي", area: 320, rooms: 5, baths: 4, status: "محجوز", rent: 35e3 },
  { id: "u5", number: "112", property: "عمارة الهرم", floor: "الأول", area: 110, rooms: 2, baths: 1, status: "تحت الصيانة", rent: 7500 },
  { id: "u6", number: "404", property: "عمارات التجمع", floor: "الرابع", area: 160, rooms: 3, baths: 2, status: "مؤجر", rent: 14e3 },
  { id: "u7", number: "G-12", property: "مول الشيخ زايد", floor: "الأرضي", area: 65, rooms: 1, baths: 1, status: "مؤجر", rent: 22e3 },
  { id: "u8", number: "501", property: "أبراج سموحة", floor: "الخامس", area: 150, rooms: 3, baths: 2, status: "متاح", rent: 11e3 }
];
const tenants = [
  { id: "t1", name: "أحمد محمود السيد", nationalId: "28905120101234", phone: "01001234567", email: "ahmed@gmail.com", job: "مهندس", unit: "برج النيل - 101", status: "نشط" },
  { id: "t2", name: "منى عبد الرحمن", nationalId: "29103150201567", phone: "01112345678", email: "mona@gmail.com", job: "طبيبة", unit: "أبراج المعادي - 205", status: "نشط" },
  { id: "t3", name: "خالد إبراهيم فؤاد", nationalId: "28712030301890", phone: "01223456789", email: "khaled@gmail.com", job: "محاسب", unit: "عمارات التجمع - 404", status: "متأخر بالسداد" },
  { id: "t4", name: "سارة وليد حسن", nationalId: "29405180401123", phone: "01509876543", email: "sara@gmail.com", job: "مدرّسة", unit: "مول الشيخ زايد - G-12", status: "نشط" },
  { id: "t5", name: "محمد علي شعبان", nationalId: "28609110501456", phone: "01098765432", email: "mohamed@gmail.com", job: "رجل أعمال", unit: "أبراج النصر - 801", status: "نشط" }
];
const contracts = [
  { id: "c1", number: "CT-1001", tenant: "أحمد محمود السيد", unit: "برج النيل - 101", start: "2025-01-01", end: "2025-12-31", rent: 12e3, deposit: 24e3, status: "نشط" },
  { id: "c2", number: "CT-1002", tenant: "منى عبد الرحمن", unit: "أبراج المعادي - 205", start: "2024-06-01", end: "2025-05-31", rent: 18e3, deposit: 36e3, status: "نشط" },
  { id: "c3", number: "CT-1003", tenant: "خالد إبراهيم فؤاد", unit: "عمارات التجمع - 404", start: "2024-03-01", end: "2025-02-28", rent: 14e3, deposit: 28e3, status: "عقد منتهي" },
  { id: "c4", number: "CT-1004", tenant: "سارة وليد حسن", unit: "مول الشيخ زايد - G-12", start: "2025-02-01", end: "2026-01-31", rent: 22e3, deposit: 66e3, status: "نشط" },
  { id: "c5", number: "CT-1005", tenant: "محمد علي شعبان", unit: "أبراج النصر - 801", start: "2024-09-01", end: "2025-08-31", rent: 16e3, deposit: 32e3, status: "نشط" }
];
const payments = [
  { id: "pay1", receipt: "RC-5001", tenant: "أحمد محمود السيد", unit: "برج النيل - 101", amount: 12e3, method: "إنستاباي", date: "2025-06-01", status: "مدفوع" },
  { id: "pay2", receipt: "RC-5002", tenant: "منى عبد الرحمن", unit: "أبراج المعادي - 205", amount: 18e3, method: "تحويل بنكي", date: "2025-06-02", status: "مدفوع" },
  { id: "pay3", receipt: "RC-5003", tenant: "خالد إبراهيم فؤاد", unit: "عمارات التجمع - 404", amount: 14e3, method: "نقدي", date: "2025-05-15", status: "متأخر" },
  { id: "pay4", receipt: "RC-5004", tenant: "سارة وليد حسن", unit: "مول الشيخ زايد - G-12", amount: 22e3, method: "فودافون كاش", date: "2025-06-03", status: "مدفوع" },
  { id: "pay5", receipt: "RC-5005", tenant: "محمد علي شعبان", unit: "أبراج النصر - 801", amount: 16e3, method: "بطاقة ائتمان", date: "2025-06-05", status: "مستحق" }
];
const maintenanceRequests = [
  { id: "m1", number: "MN-301", unit: "برج النيل - 101", type: "تكييف", priority: "عاجل", status: "قيد التنفيذ", date: "2025-06-04" },
  { id: "m2", number: "MN-302", unit: "عمارة الهرم - 112", type: "سباكة", priority: "مرتفع", status: "جديد", date: "2025-06-05" },
  { id: "m3", number: "MN-303", unit: "أبراج المعادي - 205", type: "كهرباء", priority: "متوسط", status: "مكتمل", date: "2025-05-28" },
  { id: "m4", number: "MN-304", unit: "عمارات التجمع - 404", type: "مصاعد", priority: "عاجل", status: "قيد التنفيذ", date: "2025-06-06" },
  { id: "m5", number: "MN-305", unit: "كمبوند الياسمين - 301", type: "دهانات", priority: "منخفض", status: "جديد", date: "2025-06-06" }
];
const egp = (n) => `${n.toLocaleString("en-EG")} ج.م`;
let counter = 1e3;
const uid = (prefix) => `${prefix}-${++counter}`;
const seedNotifications = [
  {
    id: uid("n"),
    type: "contract",
    title: "قرب انتهاء عقد",
    body: "عقد برج النيل - 101 ينتهي خلال 14 يوم",
    date: "2025-06-06",
    read: false,
    link: { to: "/contracts/$id", params: { id: "c1" } }
  },
  {
    id: uid("n"),
    type: "payment",
    title: "تأخر سداد الإيجار",
    body: "تأخر سداد إيجار عمارات التجمع - 404",
    date: "2025-06-05",
    read: false,
    link: { to: "/contracts/$id", params: { id: "c3" } }
  },
  {
    id: uid("n"),
    type: "maintenance",
    title: "طلب صيانة جديد",
    body: "طلب صيانة: مصاعد - عمارات التجمع - 404",
    date: "2025-06-06",
    read: false,
    link: { to: "/maintenance" }
  },
  {
    id: uid("n"),
    type: "payment-received",
    title: "تم استلام دفعة",
    body: "تم استلام دفعة من سارة وليد حسن بقيمة 22,000 ج.م",
    date: "2025-06-03",
    read: true,
    link: { to: "/payments" }
  },
  {
    id: uid("n"),
    type: "vacant",
    title: "وحدة شاغرة",
    body: "أصبحت الوحدة أبراج سموحة - 501 شاغرة",
    date: "2025-06-02",
    read: true,
    link: { to: "/units/$id", params: { id: "u8" } }
  }
];
const StoreContext = reactExports.createContext(null);
function StoreProvider({ children }) {
  const [properties$1, setProperties] = reactExports.useState(properties);
  const [units$1, setUnits] = reactExports.useState(units);
  const [tenants$1, setTenants] = reactExports.useState(tenants);
  const [contracts$1, setContracts] = reactExports.useState(contracts);
  const [payments$1, setPayments] = reactExports.useState(payments);
  const [maintenance, setMaintenance] = reactExports.useState(maintenanceRequests);
  const [notifications, setNotifications] = reactExports.useState(seedNotifications);
  const value = reactExports.useMemo(() => {
    function crud(setter, prefix) {
      return {
        add: (item) => setter((prev) => [{ ...item, id: uid(prefix) }, ...prev]),
        update: (id, patch) => setter((prev) => prev.map((x) => x.id === id ? { ...x, ...patch } : x)),
        remove: (id) => setter((prev) => prev.filter((x) => x.id !== id))
      };
    }
    const p = crud(setProperties, "p");
    const u = crud(setUnits, "u");
    const t = crud(setTenants, "t");
    const c = crud(setContracts, "c");
    const pay = crud(setPayments, "pay");
    const m = crud(setMaintenance, "m");
    return {
      properties: properties$1,
      units: units$1,
      tenants: tenants$1,
      contracts: contracts$1,
      payments: payments$1,
      maintenance,
      notifications,
      addProperty: p.add,
      updateProperty: p.update,
      deleteProperty: p.remove,
      addUnit: u.add,
      updateUnit: u.update,
      deleteUnit: u.remove,
      addTenant: t.add,
      updateTenant: t.update,
      deleteTenant: t.remove,
      addContract: c.add,
      updateContract: c.update,
      deleteContract: c.remove,
      addPayment: pay.add,
      updatePayment: pay.update,
      deletePayment: pay.remove,
      addMaintenance: m.add,
      updateMaintenance: m.update,
      deleteMaintenance: m.remove,
      markRead: (id) => setNotifications((prev) => prev.map((n) => n.id === id ? { ...n, read: true } : n)),
      markAllRead: () => setNotifications((prev) => prev.map((n) => ({ ...n, read: true }))),
      deleteNotification: (id) => setNotifications((prev) => prev.filter((n) => n.id !== id))
    };
  }, [properties$1, units$1, tenants$1, contracts$1, payments$1, maintenance, notifications]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(StoreContext.Provider, { value, children });
}
const supabaseUrl = "https://moegmastkniqzfnlhcvf.supabase.co";
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1vZWdtYXN0a25pcXpmbmxoY3ZmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODMyNDQ2MTgsImV4cCI6MjA5ODgyMDYxOH0.836AWom90XC9WHqikIBQLS-K0lRY-V1U62HMr5OOGSk";
const isSupabaseConfigured = Boolean(supabaseAnonKey);
function createGuardClient() {
  const notConfigured = () => {
    if (typeof console !== "undefined") {
      console.warn("[Supabase] Skipped call — backend not configured.");
    }
    return { data: null, error: { message: "Supabase غير مهيأ" } };
  };
  const queryBuilder = new Proxy(function() {
  }, {
    get: (_t, prop) => {
      if (prop === "then") return (resolve) => resolve(notConfigured());
      return () => queryBuilder;
    },
    apply: () => queryBuilder
  });
  return new Proxy(
    {},
    {
      get: (_t, prop) => {
        if (prop === "from" || prop === "rpc") return () => queryBuilder;
        if (prop === "auth") {
          return {
            getSession: async () => ({ data: { session: null }, error: null }),
            getUser: async () => ({ data: { user: null }, error: null }),
            signInWithPassword: async () => ({ data: null, error: { message: "Supabase غير مهيأ" } }),
            signOut: async () => ({ error: null }),
            onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {
            } } } })
          };
        }
        if (prop === "storage" || prop === "functions" || prop === "channel") return () => queryBuilder;
        return () => queryBuilder;
      }
    }
  );
}
const supabase = isSupabaseConfigured ? createClient(supabaseUrl, supabaseAnonKey) : createGuardClient();
const AuthContext = reactExports.createContext({
  session: null,
  user: null,
  isLoading: true
});
function AuthProvider({ children }) {
  const [session, setSession] = reactExports.useState(null);
  const [user, setUser] = reactExports.useState(null);
  const [isLoading, setIsLoading] = reactExports.useState(true);
  reactExports.useEffect(() => {
    let mounted = true;
    async function getInitialSession() {
      const { data, error } = await supabase.auth.getSession();
      if (mounted) {
        if (error) {
          console.error("Error getting initial session:", error.message);
        } else {
          setSession(data.session);
          setUser(data.session?.user ?? null);
        }
        setIsLoading(false);
      }
    }
    getInitialSession();
    const {
      data: { subscription }
    } = supabase.auth.onAuthStateChange((_event, session2) => {
      setSession(session2);
      setUser(session2?.user ?? null);
      setIsLoading(false);
    });
    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(AuthContext.Provider, { value: { session, user, isLoading }, children });
}
function useAuth() {
  return reactExports.useContext(AuthContext);
}
function NotFoundComponent() {
  const router2 = useRouter();
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full max-w-md rounded-2xl border border-border bg-card p-8 text-center shadow-sm", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 text-primary", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-3xl font-extrabold", children: "!" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "mt-5 text-6xl font-extrabold text-foreground", children: "404" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 text-xl font-bold text-foreground", children: "الصفحة غير موجودة" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "عذراً، الصفحة التي تبحث عنها غير موجودة أو تم نقلها. جرّب إعادة المحاولة أو تحديث التطبيق." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex flex-wrap justify-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => router2.invalidate(),
          className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
          children: "إعادة المحاولة"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => window.location.reload(),
          className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
          children: "تحديث التطبيق"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Link,
        {
          to: "/dashboard",
          className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
          children: "لوحة التحكم"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Link,
        {
          to: "/contracts",
          className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
          children: "قائمة العقود"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Link,
        {
          to: "/tenants",
          className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
          children: "قائمة المستأجرين"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-xs text-muted-foreground", children: "إذا استمرت المشكلة، حدّث الصفحة من المتصفح (Ctrl/Cmd + R)." })
  ] }) });
}
function ErrorComponent({ error, reset }) {
  console.error(error);
  const router2 = useRouter();
  reactExports.useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl font-semibold tracking-tight text-foreground", children: "This page didn't load" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "Something went wrong on our end. You can try refreshing or head back home." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex flex-wrap justify-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => {
            router2.invalidate();
            reset();
          },
          className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
          children: "Try again"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "a",
        {
          href: "/",
          className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
          children: "Go home"
        }
      )
    ] })
  ] }) });
}
const Route$l = createRootRouteWithContext()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Rentify — نظام إدارة العقارات" },
      { name: "description", content: "نظام Rentify لإدارة العقارات والإيجارات والعقود والتحصيلات بسهولة واحترافية." },
      { name: "author", content: "Mr. Hafez Rahim +201007419344" },
      { property: "og:title", content: "Rentify — نظام إدارة العقارات" },
      { property: "og:description", content: "إدارة العقارات والإيجارات بسهولة واحترافية." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:site", content: "@Rentify" }
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss
      },
      { rel: "icon", type: "image/png", href: "/favicon.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800&display=swap"
      }
    ]
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent
});
function RootShell({ children }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("html", { lang: "ar", dir: "rtl", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("head", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(HeadContent, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("body", { children: [
      children,
      /* @__PURE__ */ jsxRuntimeExports.jsx(Scripts, {})
    ] })
  ] });
}
function InnerRoot() {
  const { session, isLoading } = useAuth();
  const router2 = useRouter();
  reactExports.useEffect(() => {
    if (!isLoading) {
      if (!session && router2.state.location.pathname !== "/login") {
        router2.navigate({ to: "/login", replace: true });
      } else if (session && router2.state.location.pathname === "/login") {
        router2.navigate({ to: "/dashboard", replace: true });
      }
    }
  }, [session, isLoading, router2.state.location.pathname]);
  if (isLoading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-screen items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-8 w-8 animate-spin rounded-full border-b-2 border-primary" }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(StoreProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Outlet, {}) });
}
function RootComponent() {
  const { queryClient } = Route$l.useRouteContext();
  return /* @__PURE__ */ jsxRuntimeExports.jsx(QueryClientProvider, { client: queryClient, children: /* @__PURE__ */ jsxRuntimeExports.jsx(AuthProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(InnerRoot, {}) }) });
}
const $$splitComponentImporter$j = () => import("./units-BFsOu0JM.mjs");
const Route$k = createFileRoute("/units")({
  component: lazyRouteComponent($$splitComponentImporter$j, "component")
});
const $$splitComponentImporter$i = () => import("./tenants-BFsOu0JM.mjs");
const Route$j = createFileRoute("/tenants")({
  component: lazyRouteComponent($$splitComponentImporter$i, "component")
});
const BASE_URL = "";
const Route$i = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const entries = [
          { path: "/", changefreq: "weekly", priority: "1.0" },
          { path: "/dashboard", changefreq: "weekly", priority: "0.8" },
          { path: "/units", changefreq: "weekly", priority: "0.7" },
          { path: "/tenants", changefreq: "weekly", priority: "0.7" },
          { path: "/contracts", changefreq: "weekly", priority: "0.7" },
          { path: "/payments", changefreq: "weekly", priority: "0.7" },
          { path: "/maintenance", changefreq: "weekly", priority: "0.6" },
          { path: "/reports", changefreq: "monthly", priority: "0.6" },
          { path: "/settings", changefreq: "monthly", priority: "0.5" }
        ];
        const urls = entries.map(
          (e) => [
            `  <url>`,
            `    <loc>${BASE_URL}${e.path}</loc>`,
            e.changefreq ? `    <changefreq>${e.changefreq}</changefreq>` : null,
            e.priority ? `    <priority>${e.priority}</priority>` : null,
            `  </url>`
          ].filter(Boolean).join("\n")
        );
        const xml = [
          `<?xml version="1.0" encoding="UTF-8"?>`,
          `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
          ...urls,
          `</urlset>`
        ].join("\n");
        return new Response(xml, {
          headers: { "Content-Type": "application/xml", "Cache-Control": "public, max-age=3600" }
        });
      }
    }
  }
});
const $$splitComponentImporter$h = () => import("./settings-C-3YfY0F.mjs");
const Route$h = createFileRoute("/settings")({
  component: lazyRouteComponent($$splitComponentImporter$h, "component")
});
const $$splitComponentImporter$g = () => import("./reports-Bmr1WM6k.mjs");
const Route$g = createFileRoute("/reports")({
  head: () => ({
    meta: [{
      title: "التقارير — Rentify"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$g, "component")
});
const $$splitComponentImporter$f = () => import("./payments-BFR85EhU.mjs");
const Route$f = createFileRoute("/payments")({
  head: () => ({
    meta: [{
      title: "التحصيلات — Rentify"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$f, "component")
});
const $$splitComponentImporter$e = () => import("./notifications-CLpR6pd6.mjs");
const Route$e = createFileRoute("/notifications")({
  head: () => ({
    meta: [{
      title: "مركز الإشعارات — Rentify"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$e, "component")
});
const $$splitComponentImporter$d = () => import("./maintenance-B2pLxhXV.mjs");
const Route$d = createFileRoute("/maintenance")({
  head: () => ({
    meta: [{
      title: "الصيانة — Rentify"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$d, "component")
});
const $$splitComponentImporter$c = () => import("./login-qaJi6r3X.mjs");
const Route$c = createFileRoute("/login")({
  head: () => ({
    meta: [{
      title: "تسجيل الدخول | Rentify"
    }, {
      name: "description",
      content: "تسجيل الدخول إلى نظام Rentify لإدارة العقارات والإيجارات."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$c, "component")
});
const $$splitComponentImporter$b = () => import("./deposits-BCDj4JCO.mjs");
const Route$b = createFileRoute("/deposits")({
  head: () => ({
    meta: [{
      title: "التأمينات — Rentify"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$b, "component")
});
const $$splitComponentImporter$a = () => import("./dashboard-C2b9mP2a.mjs");
const Route$a = createFileRoute("/dashboard")({
  head: () => ({
    meta: [{
      title: "لوحة التحكم — Rentify"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$a, "component")
});
const $$splitComponentImporter$9 = () => import("./contracts-BFsOu0JM.mjs");
const Route$9 = createFileRoute("/contracts")({
  component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
const $$splitComponentImporter$8 = () => import("./index-BJsKlBFI.mjs");
const Route$8 = createFileRoute("/")({
  head: () => ({
    meta: [{
      title: "نظام Rentify لإدارة العقارات"
    }, {
      name: "description",
      content: "إدارة العقارات والإيجارات والعقود والتحصيلات بسهولة واحترافية للسوق المصري."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
const $$splitComponentImporter$7 = () => import("./units.index-DMp8UCXr.mjs");
const Route$7 = createFileRoute("/units/")({
  head: () => ({
    meta: [{
      title: "الوحدات — Rentify"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
const $$splitComponentImporter$6 = () => import("./tenants.index-CIHdw9k-.mjs");
const Route$6 = createFileRoute("/tenants/")({
  head: () => ({
    meta: [{
      title: "العملاء — Rentify"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
const $$splitComponentImporter$5 = () => import("./settings.index-US0kYCy3.mjs");
const Route$5 = createFileRoute("/settings/")({
  head: () => ({
    meta: [{
      title: "الإعدادات — Rentify"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
const $$splitComponentImporter$4 = () => import("./contracts.index-BwNcCBuf.mjs");
const Route$4 = createFileRoute("/contracts/")({
  head: () => ({
    meta: [{
      title: "العقود — Rentify"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
const $$splitComponentImporter$3 = () => import("./units._id-B3HML4kv.mjs");
const Route$3 = createFileRoute("/units/$id")({
  head: () => ({
    meta: [{
      title: "تفاصيل الوحدة — Rentify"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
const $$splitComponentImporter$2 = () => import("./tenants._id-CR5m8Zx5.mjs");
const Route$2 = createFileRoute("/tenants/$id")({
  head: () => ({
    meta: [{
      title: "تفاصيل العميل — Rentify"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
const $$splitComponentImporter$1 = () => import("./settings.about-Du2Cb4Tm.mjs");
const Route$1 = createFileRoute("/settings/about")({
  head: () => ({
    meta: [{
      title: "حول Rentify"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
const $$splitComponentImporter = () => import("./contracts._id-DLaNr6IB.mjs");
const Route = createFileRoute("/contracts/$id")({
  head: () => ({
    meta: [{
      title: "تفاصيل العقد — Rentify"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter, "component")
});
const UnitsRoute = Route$k.update({
  id: "/units",
  path: "/units",
  getParentRoute: () => Route$l
});
const TenantsRoute = Route$j.update({
  id: "/tenants",
  path: "/tenants",
  getParentRoute: () => Route$l
});
const SitemapDotxmlRoute = Route$i.update({
  id: "/sitemap.xml",
  path: "/sitemap.xml",
  getParentRoute: () => Route$l
});
const SettingsRoute = Route$h.update({
  id: "/settings",
  path: "/settings",
  getParentRoute: () => Route$l
});
const ReportsRoute = Route$g.update({
  id: "/reports",
  path: "/reports",
  getParentRoute: () => Route$l
});
const PaymentsRoute = Route$f.update({
  id: "/payments",
  path: "/payments",
  getParentRoute: () => Route$l
});
const NotificationsRoute = Route$e.update({
  id: "/notifications",
  path: "/notifications",
  getParentRoute: () => Route$l
});
const MaintenanceRoute = Route$d.update({
  id: "/maintenance",
  path: "/maintenance",
  getParentRoute: () => Route$l
});
const LoginRoute = Route$c.update({
  id: "/login",
  path: "/login",
  getParentRoute: () => Route$l
});
const DepositsRoute = Route$b.update({
  id: "/deposits",
  path: "/deposits",
  getParentRoute: () => Route$l
});
const DashboardRoute = Route$a.update({
  id: "/dashboard",
  path: "/dashboard",
  getParentRoute: () => Route$l
});
const ContractsRoute = Route$9.update({
  id: "/contracts",
  path: "/contracts",
  getParentRoute: () => Route$l
});
const IndexRoute = Route$8.update({
  id: "/",
  path: "/",
  getParentRoute: () => Route$l
});
const UnitsIndexRoute = Route$7.update({
  id: "/",
  path: "/",
  getParentRoute: () => UnitsRoute
});
const TenantsIndexRoute = Route$6.update({
  id: "/",
  path: "/",
  getParentRoute: () => TenantsRoute
});
const SettingsIndexRoute = Route$5.update({
  id: "/",
  path: "/",
  getParentRoute: () => SettingsRoute
});
const ContractsIndexRoute = Route$4.update({
  id: "/",
  path: "/",
  getParentRoute: () => ContractsRoute
});
const UnitsIdRoute = Route$3.update({
  id: "/$id",
  path: "/$id",
  getParentRoute: () => UnitsRoute
});
const TenantsIdRoute = Route$2.update({
  id: "/$id",
  path: "/$id",
  getParentRoute: () => TenantsRoute
});
const SettingsAboutRoute = Route$1.update({
  id: "/about",
  path: "/about",
  getParentRoute: () => SettingsRoute
});
const ContractsIdRoute = Route.update({
  id: "/$id",
  path: "/$id",
  getParentRoute: () => ContractsRoute
});
const ContractsRouteChildren = {
  ContractsIdRoute,
  ContractsIndexRoute
};
const ContractsRouteWithChildren = ContractsRoute._addFileChildren(
  ContractsRouteChildren
);
const SettingsRouteChildren = {
  SettingsAboutRoute,
  SettingsIndexRoute
};
const SettingsRouteWithChildren = SettingsRoute._addFileChildren(
  SettingsRouteChildren
);
const TenantsRouteChildren = {
  TenantsIdRoute,
  TenantsIndexRoute
};
const TenantsRouteWithChildren = TenantsRoute._addFileChildren(TenantsRouteChildren);
const UnitsRouteChildren = {
  UnitsIdRoute,
  UnitsIndexRoute
};
const UnitsRouteWithChildren = UnitsRoute._addFileChildren(UnitsRouteChildren);
const rootRouteChildren = {
  IndexRoute,
  ContractsRoute: ContractsRouteWithChildren,
  DashboardRoute,
  DepositsRoute,
  LoginRoute,
  MaintenanceRoute,
  NotificationsRoute,
  PaymentsRoute,
  ReportsRoute,
  SettingsRoute: SettingsRouteWithChildren,
  SitemapDotxmlRoute,
  TenantsRoute: TenantsRouteWithChildren,
  UnitsRoute: UnitsRouteWithChildren
};
const routeTree = Route$l._addFileChildren(rootRouteChildren)._addFileTypes();
const getRouter = () => {
  const queryClient = new QueryClient();
  const router2 = createRouter({
    routeTree,
    context: { queryClient },
    scrollRestoration: true,
    defaultPreloadStaleTime: 0
  });
  return router2;
};
const router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getRouter
}, Symbol.toStringTag, { value: "Module" }));
export {
  Route$3 as R,
  Route$2 as a,
  Route as b,
  statusColors as c,
  egp as e,
  paymentMethods as p,
  router as r,
  supabase as s,
  useAuth as u
};
