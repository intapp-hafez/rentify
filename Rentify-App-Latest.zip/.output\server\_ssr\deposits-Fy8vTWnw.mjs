import { s as supabase } from "./router-ChN6Fncz.mjs";
const getDeposits = async () => {
  const { data, error } = await supabase.from("deposits").select(`
      *,
      contracts ( number, start_date, end_date ),
      tenants ( full_name )
    `).order("created_at", { ascending: false });
  if (error) {
    throw new Error(error.message);
  }
  return data;
};
const getDepositByContractId = async (contractId) => {
  const { data, error } = await supabase.from("deposits").select("*").eq("contract_id", contractId).single();
  if (error && error.code !== "PGRST116") {
    throw new Error(error.message);
  }
  return data;
};
const updateDeposit = async ({ id, ...updateData }) => {
  const { data, error } = await supabase.from("deposits").update(updateData).eq("id", id).select().single();
  if (error) {
    throw new Error(error.message);
  }
  return data;
};
const deleteDeposit = async (id) => {
  const { error } = await supabase.from("deposits").delete().eq("id", id);
  if (error) {
    throw new Error(error.message);
  }
};
export {
  getDepositByContractId as a,
  deleteDeposit as d,
  getDeposits as g,
  updateDeposit as u
};
