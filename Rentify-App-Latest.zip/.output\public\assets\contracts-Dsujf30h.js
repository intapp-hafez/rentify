import{j as t,O as o}from"./index-BiCJzA_6.js";const n=()=>t.jsx(o,{});export{n as component};
