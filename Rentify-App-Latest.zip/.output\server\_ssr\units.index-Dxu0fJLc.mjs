import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { e as useNavigate, L as Link } from "../_libs/tanstack__react-router.mjs";
import { a as useQueryClient, u as useQuery, b as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { A as AppLayout } from "./AppLayout-D343eYEX.mjs";
import { B as Button } from "./button-DL752WFK.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { S as Select, a as SelectTrigger, b as SelectValue, c as SelectContent, d as SelectItem, C as CrudDialog, e as ConfirmDelete } from "./ConfirmDelete-DuL2SYKU.mjs";
import { D as DataTable } from "./DataTable-lfA95yU8.mjs";
import { S as StatusBadge } from "./StatusBadge-yA9h_bRJ.mjs";
import { a as addUnit, u as updateUnit, d as deleteUnit, g as getUnits } from "./units-DFEKe7B8.mjs";
import { g as getAllSettings } from "./settings-YGc86L75.mjs";
import { e as exportToExcel, d as downloadTemplate, i as importFromExcel } from "./excel-ncAzCXAJ.mjs";
import { e as egp } from "./router-D3vpDMsI.mjs";
import { e as Search, A as ArrowDownUp, D as Download, p as FileSpreadsheet, q as Upload, P as Plus, r as Pencil, s as Trash2 } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/cmdk.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-effect-event+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-dropdown-menu.mjs";
import "../_libs/radix-ui__react-menu.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-roving-focus.mjs";
import "../_libs/date-fns.mjs";
import "../_libs/class-variance-authority.mjs";
import "./label-JU3yqRBo.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-select.mjs";
import "../_libs/radix-ui__number.mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "../_libs/radix-ui__react-alert-dialog.mjs";
import "./card-RGlIzTYo.mjs";
import "../_libs/xlsx.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/supabase__functions-js.mjs";
const unitStatuses = ["available", "rented", "maintenance"];
const statusTranslations = {
  "available": "متاح",
  "rented": "مؤجر",
  "maintenance": "تحت الصيانة"
};
const ALL = "__all__";
const PAGE_SIZE = 5;
function Units() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [search, setSearch] = reactExports.useState("");
  const [statusFilter, setStatusFilter] = reactExports.useState(ALL);
  const [sortDir, setSortDir] = reactExports.useState("asc");
  const [page, setPage] = reactExports.useState(1);
  const fileInputRef = reactExports.useRef(null);
  const {
    data: settings
  } = useQuery({
    queryKey: ["settings"],
    queryFn: getAllSettings
  });
  const {
    data: units = [],
    isLoading
  } = useQuery({
    queryKey: ["units"],
    queryFn: getUnits
  });
  const addMutation = useMutation({
    mutationFn: addUnit,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["units"]
      });
      toast.success("تم إضافة الوحدة بنجاح");
    },
    onError: (error) => toast.error(error.message)
  });
  const updateMutation = useMutation({
    mutationFn: updateUnit,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["units"]
      });
      toast.success("تم تحديث الوحدة بنجاح");
    },
    onError: (error) => toast.error(error.message)
  });
  const deleteMutation = useMutation({
    mutationFn: deleteUnit,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["units"]
      });
      toast.success("تم حذف الوحدة بنجاح");
    },
    onError: (error) => toast.error(error.message)
  });
  const fields = [{
    name: "number",
    label: "رقم الوحدة"
  }, {
    name: "title",
    label: "اسم العقار / العنوان",
    colSpan: 2
  }, {
    name: "type",
    label: "النوع",
    type: "select",
    options: settings?.property_types?.length ? settings.property_types : ["شقق سكنية", "فيلات", "مكاتب", "محلات تجارية", "مستودعات", "أراضي"]
  }, {
    name: "city",
    label: "المدينة / المحافظة",
    type: "select",
    options: settings?.governorates?.length ? settings.governorates : ["القاهرة", "الجيزة", "الإسكندرية"]
  }, {
    name: "address",
    label: "العنوان التفصيلي"
  }, {
    name: "floor",
    label: "الطابق",
    hidden: (v) => ["مستودعات", "أراضي"].includes(v.type)
  }, {
    name: "area",
    label: "المساحة (م²)",
    type: "number"
  }, {
    name: "rooms",
    label: "الغرف",
    type: "number",
    hidden: (v) => ["مستودعات", "أراضي", "محلات تجارية"].includes(v.type)
  }, {
    name: "baths",
    label: "الحمامات",
    type: "number",
    hidden: (v) => ["مستودعات", "أراضي"].includes(v.type)
  }, {
    name: "status",
    label: "الحالة",
    type: "select",
    options: ["available", "rented", "maintenance"]
  }, {
    name: "rent_price",
    label: "الإيجار",
    type: "number"
  }];
  const filtered = reactExports.useMemo(() => {
    const q = search.trim().toLowerCase();
    return units.filter((u) => {
      if (statusFilter !== ALL && u.status !== statusFilter) return false;
      if (q && ![u.number, u.title, u.floor].some((v) => v?.toLowerCase().includes(q))) return false;
      return true;
    }).sort((a, b) => sortDir === "asc" ? a.rent_price - b.rent_price : b.rent_price - a.rent_price);
  }, [units, statusFilter, search, sortDir]);
  const resetFilters = () => {
    setSearch("");
    setStatusFilter(ALL);
    setSortDir("asc");
    setPage(1);
  };
  const handleExport = () => {
    const exportData = units.map((u) => ({
      "رقم الوحدة": u.number,
      "اسم العقار / العنوان": u.title,
      "النوع": u.type,
      "المدينة / المحافظة": u.city,
      "العنوان التفصيلي": u.address,
      "الطابق": u.floor,
      "المساحة": u.area,
      "الغرف": u.rooms,
      "الحمامات": u.baths,
      "الحالة": u.status,
      "الإيجار": u.rent_price
    }));
    exportToExcel(exportData, "المنشآت_الوحدات");
  };
  const handleDownloadTemplate = () => {
    downloadTemplate(["number", "title", "type", "city", "address", "floor", "area", "rooms", "baths", "status", "rent_price"], "Units_Template");
  };
  const handleImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const toastId = toast.loading("جاري تحليل الملف واستيراد البيانات...");
    try {
      const data = await importFromExcel(file);
      if (!data || data.length === 0) {
        toast.error("الملف فارغ أو لا يحتوي على بيانات صحيحة", {
          id: toastId
        });
        return;
      }
      let successCount = 0;
      for (const row of data) {
        await addMutation.mutateAsync({
          number: row.number?.toString() || null,
          title: row.title || "بدون اسم",
          type: row.type || "apartment",
          city: row.city || null,
          address: row.address || null,
          floor: row.floor?.toString() || null,
          area: Number(row.area) || null,
          rooms: Number(row.rooms) || null,
          baths: Number(row.baths) || null,
          status: row.status || "available",
          rent_price: Number(row.rent_price) || 0
        });
        successCount++;
      }
      queryClient.invalidateQueries({
        queryKey: ["units"]
      });
      toast.success(`تم استيراد ${successCount} وحدة بنجاح`, {
        id: toastId
      });
    } catch (error) {
      toast.error(`فشل الاستيراد: ${error?.message || "تأكد من استخدام القالب الصحيح"}`, {
        id: toastId
      });
      console.error("Import Error:", error);
    } finally {
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };
  const columns = [{
    key: "number",
    header: "رقم الوحدة",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/units/$id", params: {
      id: r.id
    }, className: "font-bold text-primary hover:underline", children: r.number || "-" })
  }, {
    key: "title",
    header: "العقار",
    render: (r) => r.title
  }, {
    key: "city",
    header: "المدينة",
    render: (r) => r.city || "-"
  }, {
    key: "type",
    header: "النوع",
    render: (r) => r.type
  }, {
    key: "floor",
    header: "الطابق",
    render: (r) => r.floor || "-"
  }, {
    key: "area",
    header: "المساحة",
    render: (r) => r.area ? `${r.area} م²` : "-"
  }, {
    key: "rooms",
    header: "الغرف",
    render: (r) => r.rooms || "-"
  }, {
    key: "baths",
    header: "الحمامات",
    render: (r) => r.baths || "-"
  }, {
    key: "rent_price",
    header: "الإيجار",
    render: (r) => egp(r.rent_price)
  }, {
    key: "status",
    header: "الحالة",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { status: statusTranslations[r.status] || r.status })
  }, {
    key: "actions",
    header: "إجراءات",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-1", onClick: (e) => e.stopPropagation(), children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CrudDialog, { maxWidth: "max-w-2xl", title: "تعديل وحدة", fields, initial: r, onSubmit: (v) => updateMutation.mutate({
        id: r.id,
        ...v
      }), trigger: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "icon", variant: "ghost", className: "h-8 w-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-4 w-4" }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(ConfirmDelete, { description: `سيتم حذف الوحدة "${r.number || r.title}".`, onConfirm: () => deleteMutation.mutate(r.id), trigger: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "icon", variant: "ghost", className: "h-8 w-8 text-destructive", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) }) })
    ] })
  }];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(AppLayout, { title: "الوحدات", subtitle: "إدارة وحدات العقارات وحالتها", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "my-4 rounded-xl border border-border bg-card p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: search, onChange: (e) => {
          setSearch(e.target.value);
          setPage(1);
        }, placeholder: "بحث برقم الوحدة أو العقار", className: "pr-9" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: statusFilter, onValueChange: (v) => {
        setStatusFilter(v);
        setPage(1);
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "الحالة" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectContent, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: ALL, children: "كل الحالات" }),
          unitStatuses.map((s) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: s, children: statusTranslations[s] }, s))
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", className: "flex-1 gap-1", onClick: () => setSortDir((d) => d === "asc" ? "desc" : "asc"), children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowDownUp, { className: "h-4 w-4" }),
          " ",
          sortDir === "asc" ? "الإيجار ↑" : "الإيجار ↓"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", onClick: resetFilters, children: "مسح" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex flex-wrap items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", className: "gap-1 text-muted-foreground", onClick: handleExport, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "h-4 w-4" }),
          " تصدير Excel"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", className: "gap-1 text-muted-foreground", onClick: handleDownloadTemplate, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(FileSpreadsheet, { className: "h-4 w-4" }),
          " تحميل القالب"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", className: "gap-1 text-muted-foreground", onClick: () => fileInputRef.current?.click(), children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "h-4 w-4" }),
          " استيراد Excel"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "file", ref: fileInputRef, onChange: handleImport, accept: ".xlsx, .xls, .csv", className: "hidden" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CrudDialog, { maxWidth: "max-w-2xl", title: "إضافة وحدة", fields, onSubmit: (v) => addMutation.mutate({
        ...v,
        title: v.title || "بدون اسم",
        rent_price: v.rent_price || 0,
        type: v.type || "شقق سكنية"
      }), trigger: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { className: "gap-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4" }),
        " إضافة وحدة"
      ] }) })
    ] }),
    isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-8 w-8 animate-spin rounded-full border-b-2 border-primary" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx(DataTable, { columns, rows: filtered, onRowClick: (r) => navigate({
      to: "/units/$id",
      params: {
        id: r.id
      }
    }), page, defaultPageSize: PAGE_SIZE, onPageChange: setPage })
  ] });
}
export {
  Units as component
};
