import { r as reactExports, j as jsxRuntimeExports, R as React } from "../_libs/react.mjs";
import { C as Card } from "./card-RGlIzTYo.mjs";
import { B as Button } from "./button-DL752WFK.mjs";
function wrapFourWords(node, maxWords = 4) {
  if (node === null || node === void 0 || typeof node === "boolean") {
    return node;
  }
  if (typeof node === "string") {
    const trimmed = node.trim();
    if (!trimmed) return node;
    const words = trimmed.split(/\s+/);
    if (words.length <= maxWords) {
      return node;
    }
    const lines = [];
    for (let i = 0; i < words.length; i += maxWords) {
      lines.push(words.slice(i, i + maxWords).join(" "));
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "inline-flex flex-col gap-0.5 leading-snug", children: lines.map((line, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: line }, idx)) });
  }
  if (typeof node === "number") {
    return node;
  }
  if (React.isValidElement(node)) {
    const children = node.props?.children;
    if (typeof children === "string") {
      return React.cloneElement(node, {
        children: wrapFourWords(children, maxWords)
      });
    }
    if (Array.isArray(children) && children.every((c) => typeof c === "string" || typeof c === "number")) {
      const combined = children.join("");
      return React.cloneElement(node, {
        children: wrapFourWords(combined, maxWords)
      });
    }
  }
  return node;
}
function DataTable({
  columns,
  rows,
  onRowClick,
  page,
  defaultPageSize,
  onPageChange
}) {
  const [pageSize, setPageSize] = reactExports.useState(defaultPageSize || 10);
  const isPaginated = page !== void 0 && onPageChange !== void 0;
  const paginatedRows = reactExports.useMemo(() => {
    if (!isPaginated) return rows;
    const start = (page - 1) * pageSize;
    return rows.slice(start, start + pageSize);
  }, [rows, page, pageSize, isPaginated]);
  const totalPages = isPaginated ? Math.max(1, Math.ceil(rows.length / pageSize)) : 1;
  const safePage = isPaginated ? Math.min(page, totalPages) : 1;
  const startItem = isPaginated ? (safePage - 1) * pageSize + 1 : 1;
  const endItem = isPaginated ? Math.min(safePage * pageSize, rows.length) : rows.length;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "overflow-hidden p-0", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-right text-sm", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "bg-secondary/60", children: /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: columns.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "whitespace-nowrap px-4 py-3 font-bold text-foreground/80", children: c.header }, c.key)) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("tbody", { children: [
        paginatedRows.map((row) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          "tr",
          {
            onClick: onRowClick ? () => onRowClick(row) : void 0,
            className: `border-t border-border transition-colors hover:bg-secondary/40 ${onRowClick ? "cursor-pointer" : ""}`,
            children: columns.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 text-foreground/90 align-middle", children: wrapFourWords(c.render(row)) }, c.key))
          },
          row.id
        )),
        paginatedRows.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: columns.length, className: "px-4 py-8 text-center text-muted-foreground", children: "لا توجد نتائج" }) })
      ] })
    ] }) }),
    isPaginated && rows.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-between gap-3 border-t border-border px-4 py-3 sm:flex-row", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 text-sm text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
          "عرض ",
          startItem,
          "–",
          endItem,
          " من ",
          rows.length
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "العدد:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "select",
            {
              value: pageSize,
              onChange: (e) => {
                setPageSize(Number(e.target.value));
                onPageChange(1);
              },
              className: "h-7 cursor-pointer rounded border border-border bg-background px-1 py-0 text-xs outline-none focus:border-ring",
              children: [5, 10, 15, 25, 50, 100].map((size) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: size, children: size }, size))
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Button,
          {
            variant: "outline",
            size: "sm",
            onClick: () => onPageChange(safePage - 1),
            disabled: safePage <= 1,
            children: "السابق"
          }
        ),
        (() => {
          if (totalPages <= 7) {
            return Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              Button,
              {
                variant: p === safePage ? "default" : "outline",
                size: "sm",
                onClick: () => onPageChange(p),
                className: "min-w-[2rem]",
                children: p
              },
              p
            ));
          }
          const items = [];
          if (safePage <= 4) {
            items.push(1, 2, 3, 4, 5, "...", totalPages);
          } else if (safePage >= totalPages - 3) {
            items.push(1, "...", totalPages - 4, totalPages - 3, totalPages - 2, totalPages - 1, totalPages);
          } else {
            items.push(1, "...", safePage - 1, safePage, safePage + 1, "...", totalPages);
          }
          return items.map(
            (item, idx) => typeof item === "string" ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-1 text-xs text-muted-foreground", children: "..." }, `ellipsis-${idx}`) : /* @__PURE__ */ jsxRuntimeExports.jsx(
              Button,
              {
                variant: item === safePage ? "default" : "outline",
                size: "sm",
                onClick: () => onPageChange(item),
                className: "min-w-[2rem]",
                children: item
              },
              item
            )
          );
        })(),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Button,
          {
            variant: "outline",
            size: "sm",
            onClick: () => onPageChange(safePage + 1),
            disabled: safePage >= totalPages,
            children: "التالي"
          }
        )
      ] })
    ] })
  ] });
}
export {
  DataTable as D,
  wrapFourWords as w
};
