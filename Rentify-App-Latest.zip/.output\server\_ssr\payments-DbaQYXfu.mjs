import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { a as useQueryClient, u as useQuery, b as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { A as AppLayout } from "./AppLayout-D343eYEX.mjs";
import { B as Button } from "./button-DL752WFK.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { S as Select, a as SelectTrigger, b as SelectValue, c as SelectContent, d as SelectItem, C as CrudDialog, e as ConfirmDelete } from "./ConfirmDelete-DuL2SYKU.mjs";
import { K as KpiCard } from "./KpiCard-B0PnoKzu.mjs";
import { D as DataTable } from "./DataTable-lfA95yU8.mjs";
import { S as StatusBadge } from "./StatusBadge-yA9h_bRJ.mjs";
import { a as addPayment, u as updatePayment, d as deletePayment, g as getPayments } from "./payments-CqySaxzc.mjs";
import { g as getContracts } from "./contracts-fNjmsRpA.mjs";
import { g as getUnits } from "./units-DFEKe7B8.mjs";
import { g as getTenants } from "./tenants-CkyNSj6k.mjs";
import { e as exportToExcel, d as downloadTemplate, i as importFromExcel } from "./excel-ncAzCXAJ.mjs";
import { p as paymentMethods, e as egp } from "./router-D3vpDMsI.mjs";
import { n as CalendarCheck, o as TriangleAlert, W as Wallet, T as TrendingUp, e as Search, A as ArrowDownUp, D as Download, p as FileSpreadsheet, q as Upload, P as Plus, r as Pencil, s as Trash2 } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/isbot.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/cmdk.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-effect-event+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-dropdown-menu.mjs";
import "../_libs/radix-ui__react-menu.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-roving-focus.mjs";
import "../_libs/date-fns.mjs";
import "../_libs/class-variance-authority.mjs";
import "./label-JU3yqRBo.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-select.mjs";
import "../_libs/radix-ui__number.mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "../_libs/radix-ui__react-alert-dialog.mjs";
import "./card-RGlIzTYo.mjs";
import "../_libs/xlsx.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/supabase__functions-js.mjs";
const paymentStatuses = ["مدفوع", "متأخر", "مستحق"];
const ALL = "__all__";
function Payments() {
  const queryClient = useQueryClient();
  const fileInputRef = reactExports.useRef(null);
  const [search, setSearch] = reactExports.useState("");
  const [contractFilter, setContractFilter] = reactExports.useState(ALL);
  const [tenantFilter, setTenantFilter] = reactExports.useState(ALL);
  const [sortDir, setSortDir] = reactExports.useState("desc");
  const {
    data: payments = [],
    isLoading
  } = useQuery({
    queryKey: ["payments"],
    queryFn: getPayments
  });
  const {
    data: contracts = []
  } = useQuery({
    queryKey: ["contracts"],
    queryFn: getContracts
  });
  const {
    data: units = []
  } = useQuery({
    queryKey: ["units"],
    queryFn: getUnits
  });
  const {
    data: tenants = []
  } = useQuery({
    queryKey: ["tenants"],
    queryFn: getTenants
  });
  const addMutation = useMutation({
    mutationFn: addPayment,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["payments"]
      });
      toast.success("تم تسجيل الدفعة بنجاح");
    },
    onError: (error) => toast.error(error.message)
  });
  const updateMutation = useMutation({
    mutationFn: updatePayment,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["payments"]
      });
      toast.success("تم تحديث الدفعة بنجاح");
    },
    onError: (error) => toast.error(error.message)
  });
  const deleteMutation = useMutation({
    mutationFn: deletePayment,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["payments"]
      });
      toast.success("تم حذف الدفعة بنجاح");
    },
    onError: (error) => toast.error(error.message)
  });
  const fields = [{
    name: "receipt_number",
    label: "رقم الإيصال"
  }, {
    name: "contract_id",
    label: "العقد المربوط",
    type: "select",
    options: contracts.map((c) => ({
      value: c.id,
      label: `${c.number || "بدون رقم"} - ${c.tenants?.full_name}`
    }))
  }, {
    name: "amount",
    label: "المبلغ",
    type: "number"
  }, {
    name: "payment_method",
    label: "طريقة الدفع",
    type: "select",
    options: paymentMethods
  }, {
    name: "bank_name",
    label: "اسم البنك",
    hidden: (v) => v.payment_method !== "تحويل بنكي"
  }, {
    name: "account_number",
    label: "رقم الحساب",
    hidden: (v) => v.payment_method !== "تحويل بنكي"
  }, {
    name: "other_number",
    label: "الرقم",
    hidden: (v) => !v.payment_method || v.payment_method === "نقدي" || v.payment_method === "تحويل بنكي"
  }, {
    name: "payment_date",
    label: "التاريخ",
    type: "date"
  }, {
    name: "status",
    label: "الحالة",
    type: "select",
    options: paymentStatuses
  }, {
    name: "notes",
    label: "ملاحظات",
    type: "textarea",
    colSpan: 2
  }];
  const prepareSubmitData = (v) => {
    const payment_details = {
      notes: v.notes
    };
    if (v.payment_method === "تحويل بنكي") {
      payment_details.bank_name = v.bank_name;
      payment_details.account_number = v.account_number;
    } else if (v.payment_method && v.payment_method !== "نقدي") {
      payment_details.number = v.other_number;
    }
    const {
      notes,
      bank_name,
      account_number,
      other_number,
      ...rest
    } = v;
    return {
      ...rest,
      payment_details
    };
  };
  const filtered = reactExports.useMemo(() => {
    const q = search.trim().toLowerCase();
    return payments.filter((p) => p.status === "مدفوع").filter((p) => {
      const c_num = p.contracts?.number || "";
      const t_name = p.contracts?.tenants?.full_name || "";
      const u_name = p.contracts?.units?.title || "";
      if (contractFilter !== ALL && c_num !== contractFilter) return false;
      if (tenantFilter !== ALL && t_name !== tenantFilter) return false;
      if (q && ![p.receipt_number || "", t_name, u_name].some((v) => v.toLowerCase().includes(q))) return false;
      return true;
    }).sort((a, b) => sortDir === "desc" ? b.payment_date.localeCompare(a.payment_date) : a.payment_date.localeCompare(b.payment_date));
  }, [payments, contractFilter, tenantFilter, search, sortDir]);
  const collected = filtered.filter((p) => p.status === "مدفوع").reduce((s, p) => s + p.amount, 0);
  const overdue = filtered.filter((p) => p.status === "متأخر").reduce((s, p) => s + p.amount, 0);
  const due = filtered.filter((p) => p.status === "مستحق").reduce((s, p) => s + p.amount, 0);
  const resetFilters = () => {
    setSearch("");
    setContractFilter(ALL);
    setTenantFilter(ALL);
  };
  const handleExport = () => {
    const exportData = payments.map((p) => ({
      "رقم الإيصال": p.receipt_number,
      "اسم المستأجر": p.contracts?.tenants?.full_name || "غير محدد",
      "الوحدة": `${p.contracts?.units?.title} - ${p.contracts?.units?.number || ""}`,
      "المبلغ": p.amount,
      "طريقة الدفع": p.payment_method,
      "التاريخ": p.payment_date,
      "الحالة": p.status
    }));
    exportToExcel(exportData, "المنشآت_التحصيلات");
  };
  const handleDownloadTemplate = () => {
    downloadTemplate(["receipt_number", "contract_id", "amount", "payment_method", "payment_date", "status"], "Payments_Template");
  };
  const handleImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const toastId = toast.loading("جاري تحليل الملف واستيراد البيانات...");
    try {
      const data = await importFromExcel(file);
      if (!data || data.length === 0) {
        toast.error("الملف فارغ أو لا يحتوي على بيانات صحيحة", {
          id: toastId
        });
        return;
      }
      let successCount = 0;
      for (const row of data) {
        if (!row.contract_id) continue;
        await addMutation.mutateAsync({
          receipt_number: row.receipt_number?.toString() || null,
          contract_id: row.contract_id,
          amount: Number(row.amount) || 0,
          payment_method: row.payment_method || "نقدي",
          payment_date: row.payment_date || (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
          status: row.status || "مدفوع",
          receipt_url: null
        });
        successCount++;
      }
      queryClient.invalidateQueries({
        queryKey: ["payments"]
      });
      toast.success(`تم استيراد ${successCount} دفعة بنجاح`, {
        id: toastId
      });
    } catch (error) {
      toast.error(`فشل الاستيراد: ${error?.message || "تأكد من استخدام القالب الصحيح"}`, {
        id: toastId
      });
      console.error("Import Error:", error);
    } finally {
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };
  const columns = [{
    key: "receipt_number",
    header: "رقم الإيصال",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: r.receipt_number || "-" })
  }, {
    key: "tenant",
    header: "المستأجر",
    render: (r) => r.contracts?.tenants?.full_name || "-"
  }, {
    key: "unit",
    header: "الوحدة",
    render: (r) => `${r.contracts?.units?.title} - ${r.contracts?.units?.number || ""}`
  }, {
    key: "amount",
    header: "المبلغ",
    render: (r) => egp(r.amount)
  }, {
    key: "payment_method",
    header: "طريقة الدفع",
    render: (r) => r.payment_method || "-"
  }, {
    key: "payment_date",
    header: "التاريخ",
    render: (r) => r.payment_date
  }, {
    key: "status",
    header: "الحالة",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { status: r.status || "مدفوع" })
  }, {
    key: "actions",
    header: "إجراءات",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CrudDialog, { title: "تعديل دفعة", fields, initial: {
        ...r,
        notes: r.payment_details?.notes || "",
        bank_name: r.payment_details?.bank_name || "",
        account_number: r.payment_details?.account_number || "",
        other_number: r.payment_details?.number || ""
      }, onSubmit: (v) => updateMutation.mutate({
        id: r.id,
        ...prepareSubmitData(v)
      }), trigger: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "icon", variant: "ghost", className: "h-8 w-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-4 w-4" }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(ConfirmDelete, { description: `سيتم حذف الإيصال "${r.receipt_number || "-"}".`, onConfirm: () => deleteMutation.mutate(r.id), trigger: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "icon", variant: "ghost", className: "h-8 w-8 text-destructive", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) }) })
    ] })
  }];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(AppLayout, { title: "التحصيلات المدفوعة", subtitle: "سجل إيصالات الدفع المحصلة", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "مستحقة", value: egp(due), icon: CalendarCheck, tone: "accent" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "متأخرات", value: egp(overdue), icon: TriangleAlert, tone: "warning" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "تحصيلات", value: egp(collected), icon: Wallet, tone: "success" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(KpiCard, { label: "عدد الإيصالات", value: String(filtered.length), icon: TrendingUp, tone: "gold" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "my-4 rounded-xl border border-border bg-card p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative xl:col-span-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: search, onChange: (e) => setSearch(e.target.value), placeholder: "بحث بالإيصال أو المستأجر أو الوحدة", className: "pr-9" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: contractFilter, onValueChange: setContractFilter, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "العقد" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectContent, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: ALL, children: "كل العقود" }),
          contracts.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectItem, { value: c.number || "", children: [
            c.number,
            " — ",
            c.tenants?.full_name
          ] }, c.id))
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: tenantFilter, onValueChange: setTenantFilter, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "المستأجر" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectContent, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: ALL, children: "كل المستأجرين" }),
          tenants.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: t.full_name, children: t.full_name }, t.id))
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", className: "flex-1 gap-1", onClick: () => setSortDir((d) => d === "desc" ? "asc" : "desc"), children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowDownUp, { className: "h-4 w-4" }),
          " ",
          sortDir === "desc" ? "الأحدث أولاً" : "الأقدم أولاً"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", onClick: resetFilters, children: "مسح" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex flex-wrap items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", className: "gap-1 text-muted-foreground", onClick: handleExport, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "h-4 w-4" }),
          " تصدير Excel"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", className: "gap-1 text-muted-foreground", onClick: handleDownloadTemplate, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(FileSpreadsheet, { className: "h-4 w-4" }),
          " تحميل القالب"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", className: "gap-1 text-muted-foreground", onClick: () => fileInputRef.current?.click(), children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "h-4 w-4" }),
          " استيراد Excel"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "file", ref: fileInputRef, onChange: handleImport, accept: ".xlsx, .xls, .csv", className: "hidden" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CrudDialog, { title: "تسجيل دفعة", fields, onSubmit: (v) => {
        const data = prepareSubmitData(v);
        addMutation.mutate({
          ...data,
          status: data.status || "مدفوع",
          payment_method: data.payment_method || "نقدي"
        });
      }, trigger: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { className: "gap-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4" }),
        " تسجيل دفعة"
      ] }) })
    ] }),
    isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-8 w-8 animate-spin rounded-full border-b-2 border-primary" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx(DataTable, { columns, rows: filtered })
  ] });
}
export {
  Payments as component
};
