import { s as supabase } from "./router-C7nVfvJ9.mjs";
const getAllSettings = async () => {
  const { data, error } = await supabase.from("settings").select("key, value").in("key", ["governorates", "property_types", "unit_statuses"]);
  if (error || !data) {
    return { governorates: [], property_types: [], unit_statuses: [] };
  }
  const result = {};
  for (const row of data) {
    result[row.key] = row.value;
  }
  return {
    governorates: result["governorates"] || [],
    property_types: result["property_types"] || [],
    unit_statuses: result["unit_statuses"] || []
  };
};
const updateSetting = async (key, value) => {
  const { error } = await supabase.from("settings").upsert({ key, value, updated_at: (/* @__PURE__ */ new Date()).toISOString() }, { onConflict: "key" });
  if (error) throw new Error(error.message);
};
export {
  getAllSettings as g,
  updateSetting as u
};
