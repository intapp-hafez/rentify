import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { e as useNavigate } from "../_libs/tanstack__react-router.mjs";
import { s as supabase } from "./router-ChN6Fncz.mjs";
import { B as Button } from "./button-DL752WFK.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { c as cn } from "./utils-H80jjgLf.mjs";
import { J as Sparkles, N as Mail, O as Lock, Q as EyeOff, E as Eye, e as ChevronLeft, V as ShieldCheck, k as ChevronRight } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
const SLIDES = [{
  id: 1,
  image: "/rentify-slider.png",
  title: "Rentify - إدارة متكاملة"
}, {
  id: 2,
  image: "/rentify-slider1.png",
  title: "Rentify - تحصيلات ذكية"
}, {
  id: 3,
  image: "/rentify-slider2.png",
  title: "Rentify - تنظيم فائق"
}];
function LoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = reactExports.useState("");
  const [password, setPassword] = reactExports.useState("");
  const [showPassword, setShowPassword] = reactExports.useState(false);
  const [isLoading, setIsLoading] = reactExports.useState(false);
  const [currentSlide, setCurrentSlide] = reactExports.useState(0);
  const [isPaused, setIsPaused] = reactExports.useState(false);
  const nextSlide = reactExports.useCallback(() => {
    setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
  }, []);
  const prevSlide = reactExports.useCallback(() => {
    setCurrentSlide((prev) => (prev - 1 + SLIDES.length) % SLIDES.length);
  }, []);
  reactExports.useEffect(() => {
    if (isPaused) return;
    const interval = setInterval(() => {
      nextSlide();
    }, 5e3);
    return () => clearInterval(interval);
  }, [isPaused, nextSlide]);
  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    const {
      error
    } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password
    });
    if (error) {
      toast.error(error.message || "فشل تسجيل الدخول. يرجى التحقق من البيانات");
      setIsLoading(false);
    } else {
      toast.success("تم تسجيل الدخول بنجاح! مرحباً بك.");
      navigate({
        to: "/dashboard"
      });
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "h-screen max-h-screen w-full overflow-hidden flex flex-col lg:grid lg:grid-cols-12 bg-background text-foreground", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex h-full flex-col justify-between p-5 sm:p-6 lg:p-8 lg:col-span-5 xl:col-span-5 2xl:col-span-4 bg-card/60 backdrop-blur-sm border-b lg:border-b-0 lg:border-l border-border/60 z-10 overflow-y-auto lg:overflow-y-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "shrink-0 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: "/logo.png", alt: "Rentify Logo", className: "h-9 w-9 rounded-xl shadow-sm ring-1 ring-primary/20 object-contain bg-white p-1" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xl font-black tracking-tight text-primary font-sans leading-none", children: "Rentify" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-[10px] font-medium text-muted-foreground leading-tight mt-0.5", children: "نظام إدارة العقارات المتطور" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-primary/10 text-primary border border-primary/20", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3 h-3 text-gold" }),
          "إصدار 2026"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "my-3 lg:hidden shrink-0 overflow-hidden rounded-xl border border-border/80 bg-slate-950 p-1.5 shadow-md", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative aspect-[16/9] w-full overflow-hidden rounded-lg", children: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: SLIDES[currentSlide].image, alt: SLIDES[currentSlide].title, className: "h-full w-full object-cover transition-all duration-500" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center gap-1.5 mt-1.5 py-0.5", children: SLIDES.map((_, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setCurrentSlide(idx), "aria-label": `شريحة ${idx + 1}`, className: cn("h-1.5 rounded-full transition-all duration-300", idx === currentSlide ? "w-5 bg-gold" : "w-1.5 bg-white/30") }, idx)) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "my-auto py-2 max-w-sm w-full mx-auto", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-5 text-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-extrabold tracking-tight text-foreground", children: "تسجيل الدخول" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-muted-foreground leading-relaxed max-w-xs mx-auto", children: "أهلاً بك مجدداً. أدخل بيانات حسابك للوصول إلى لوحة تحكم Rentify ومتابعة عقاراتك." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleLogin, className: "space-y-3.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5 text-right", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { htmlFor: "email", className: "text-xs font-bold text-muted-foreground flex items-center justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "البريد الإلكتروني" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { className: "h-3.5 w-3.5 text-muted-foreground/80" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: "email", type: "email", placeholder: "admin@rentify.app", value: email, onChange: (e) => setEmail(e.target.value), required: true, autoComplete: "email", className: "h-10 text-left rounded-xl bg-background/80 border-border/80 focus:border-primary focus:ring-primary/20 text-sm font-medium transition-all", dir: "ltr" }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5 text-right", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-between", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { htmlFor: "password", className: "text-xs font-bold text-muted-foreground flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "h-3.5 w-3.5 text-muted-foreground/80" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "كلمة المرور" })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: "password", type: showPassword ? "text" : "password", placeholder: "••••••••", value: password, onChange: (e) => setPassword(e.target.value), required: true, autoComplete: "current-password", className: "h-10 pl-10 pr-4 text-left rounded-xl bg-background/80 border-border/80 focus:border-primary focus:ring-primary/20 text-sm font-medium transition-all", dir: "ltr" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setShowPassword(!showPassword), "aria-label": showPassword ? "إخفاء كلمة المرور" : "إظهار كلمة المرور", className: "absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors p-1", children: showPassword ? /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOff, { className: "h-4 w-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "h-4 w-4" }) })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "submit", size: "default", disabled: isLoading, className: "w-full h-10 text-sm font-bold rounded-xl shadow-md shadow-primary/20 hover:shadow-primary/30 transition-all active:scale-[0.99] gap-2 mt-2", children: isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "جاري تسجيل الدخول..." })
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "دخول إلى النظام" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "h-4 w-4" })
          ] }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 rounded-xl bg-muted/50 p-2.5 border border-border/60 flex items-center gap-2.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "h-4 w-4 text-primary" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-right text-[11px]", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-foreground", children: "اتصال آمن ومشفّر" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground", children: "بياناتك العقارية والمالية محمية بأعلى معايير الأمان." })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "shrink-0 pt-2 text-center text-[11px] text-muted-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "© 2026 Rentify. جميع الحقوق محفوظة." }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative hidden h-full lg:flex lg:col-span-7 xl:col-span-7 2xl:col-span-8 flex-col justify-between overflow-hidden bg-gradient-to-br from-[#060D1A] via-[#0A1628] to-[#040911] p-6 xl:p-8 text-white select-none", onMouseEnter: () => setIsPaused(true), onMouseLeave: () => setIsPaused(false), children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pointer-events-none absolute -left-20 -top-20 h-80 w-80 rounded-full bg-primary/20 blur-3xl" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pointer-events-none absolute -bottom-24 -right-16 h-80 w-80 rounded-full bg-gold/15 blur-3xl" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pointer-events-none absolute top-1/2 right-1/4 h-64 w-64 rounded-full bg-blue-600/10 blur-3xl" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-20 shrink-0 flex items-center justify-between pb-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 rounded-full bg-white/10 px-3.5 py-1 backdrop-blur-md border border-white/15", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "h-2 w-2 rounded-full bg-emerald-400 animate-pulse" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-semibold text-white/90", children: "Rentify Property Cloud" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs font-mono font-bold text-white/80 bg-black/40 backdrop-blur-md px-3 py-1 rounded-full border border-white/10", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-gold", children: [
            "0",
            currentSlide + 1
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-white/40", children: "/" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            "0",
            SLIDES.length
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative z-10 my-auto flex-1 min-h-0 w-full flex items-center justify-center p-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative w-full h-full max-h-[66vh] max-w-4xl flex items-center justify-center", children: SLIDES.map((slide, idx) => {
        const isActive = idx === currentSlide;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: cn("absolute inset-0 flex items-center justify-center transition-all duration-700 ease-out", isActive ? "opacity-100 scale-100 z-10" : "opacity-0 scale-95 pointer-events-none z-0"), children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-4 rounded-3xl bg-gradient-to-tr from-primary/30 via-gold/15 to-transparent blur-3xl pointer-events-none" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: slide.image, alt: slide.title, className: "relative max-h-full max-w-full rounded-2xl object-contain drop-shadow-[0_20px_50px_rgba(0,0,0,0.85)] ring-1 ring-white/10 transition-transform duration-700 hover:scale-[1.01]" })
        ] }, slide.id);
      }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-20 shrink-0 flex items-center justify-between pt-3 border-t border-white/10", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2", children: SLIDES.map((slide, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setCurrentSlide(idx), "aria-label": `الانتقال إلى الشريحة ${idx + 1}`, className: cn("group relative h-2.5 rounded-full transition-all duration-300 focus:outline-none", idx === currentSlide ? "w-8 bg-gold shadow-md shadow-gold/40 ring-2 ring-gold/30" : "w-2.5 bg-white/30 hover:bg-white/60"), children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "sr-only", children: [
          "شريحة ",
          idx + 1
        ] }) }, slide.id)) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: prevSlide, "aria-label": "الشريحة السابقة", className: "flex h-9 w-9 items-center justify-center rounded-full bg-white/10 text-white backdrop-blur-md border border-white/15 transition-all hover:bg-white/20 hover:scale-105 active:scale-95 shadow-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-4 w-4" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: nextSlide, "aria-label": "الشريحة التالية", className: "flex h-9 w-9 items-center justify-center rounded-full bg-white/10 text-white backdrop-blur-md border border-white/15 transition-all hover:bg-white/20 hover:scale-105 active:scale-95 shadow-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "h-4 w-4" }) })
        ] })
      ] })
    ] })
  ] });
}
export {
  LoginPage as component
};
