import{t}from"./AppLayout-ChiaEUYe.js";function i(o,r){return+t(o)<+t(r)}export{i};
