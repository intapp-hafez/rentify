import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { a as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { u as useAppNotifications, A as AppLayout } from "./AppLayout-C7gE-JWZ.mjs";
import { B as Button } from "./button-DL752WFK.mjs";
import { C as Card } from "./card-RGlIzTYo.mjs";
import { c as cn } from "./utils-H80jjgLf.mjs";
import { R as RefreshCw, x as CheckCheck, y as BellOff, z as DoorOpen, W as Wallet, c as Wrench, T as TriangleAlert, I as FileClock } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "./router-C7nVfvJ9.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/cmdk.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-effect-event+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-dropdown-menu.mjs";
import "../_libs/radix-ui__react-menu.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-roving-focus.mjs";
import "../_libs/date-fns.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
const meta = {
  contract: {
    icon: FileClock,
    tone: "bg-info/15 text-info"
  },
  payment: {
    icon: TriangleAlert,
    tone: "bg-warning/15 text-warning"
  },
  maintenance: {
    icon: Wrench,
    tone: "bg-[oklch(0.6_0.12_300)]/15 text-[oklch(0.5_0.14_300)]"
  },
  "payment-received": {
    icon: Wallet,
    tone: "bg-success/15 text-success"
  },
  vacant: {
    icon: DoorOpen,
    tone: "bg-gold/15 text-gold"
  }
};
const filters = [{
  key: "all",
  label: "الكل"
}, {
  key: "contract",
  label: "العقود"
}, {
  key: "payment",
  label: "التأخيرات"
}, {
  key: "maintenance",
  label: "الصيانة"
}, {
  key: "vacant",
  label: "الشاغرة"
}];
function Row({
  n,
  onRead
}) {
  const m = meta[n.type];
  const Icon = m.icon;
  const body = /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-xl", m.tone), children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-5 w-5" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-bold text-foreground", children: n.title }),
        !n.read && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "h-2 w-2 rounded-full bg-destructive" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-0.5 text-sm text-muted-foreground", children: n.body }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-muted-foreground/70", children: n.date })
    ] })
  ] });
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: cn("p-4 transition-colors", !n.read && "border-r-4 border-r-primary bg-secondary/30"), children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-3", children: [
    n.link ? /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: n.link.to, params: n.link.params, onClick: onRead, className: "flex-1", children: body }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-1", onClick: onRead, children: body }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex shrink-0 gap-1", children: !n.read && /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "icon", variant: "ghost", className: "h-8 w-8", title: "تعليم كمقروء", onClick: onRead, children: /* @__PURE__ */ jsxRuntimeExports.jsx(CheckCheck, { className: "h-4 w-4" }) }) })
  ] }) });
}
function NotificationsPage() {
  const queryClient = useQueryClient();
  const [filter, setFilter] = reactExports.useState("all");
  const {
    notifications: enriched,
    unreadCount: unread,
    isLoading,
    isFetching,
    markRead,
    markAllRead
  } = useAppNotifications();
  const shown = enriched.filter((n) => filter === "all" ? true : n.type === filter);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(AppLayout, { title: "مركز الإشعارات", subtitle: `${unread} إشعار يحتاج انتباهك`, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex flex-wrap items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: filters.map((f) => /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: filter === f.key ? "default" : "outline", onClick: () => setFilter(f.key), children: f.label }, f.key)) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant: "outline", className: "gap-1", onClick: () => queryClient.invalidateQueries({
          queryKey: ["notifications"]
        }), disabled: isFetching, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: cn("h-4 w-4", isFetching && "animate-spin") }),
          " تحديث"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant: "gold", className: "gap-1", onClick: markAllRead, disabled: unread === 0, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CheckCheck, { className: "h-4 w-4" }),
          " تعليم الكل كمقروء"
        ] })
      ] })
    ] }),
    isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center p-12", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-8 w-8 animate-spin rounded-full border-b-2 border-primary" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: shown.length ? shown.map((n) => /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { n, onRead: () => markRead(n.id) }, n.id)) : /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "flex flex-col items-center gap-3 p-12 text-muted-foreground", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(BellOff, { className: "h-10 w-10 opacity-40" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold", children: "لا توجد إشعارات" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm opacity-70", children: "كل شيء على ما يرام! ستظهر هنا تنبيهات العقود والمدفوعات والصيانة تلقائياً." })
      ] })
    ] }) })
  ] });
}
export {
  NotificationsPage as component
};
