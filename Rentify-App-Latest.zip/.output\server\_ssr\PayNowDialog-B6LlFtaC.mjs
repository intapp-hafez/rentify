import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { C as Card } from "./card-RGlIzTYo.mjs";
import { D as Dialog, a as DialogTrigger, b as DialogContent, c as DialogHeader, d as DialogTitle, e as DialogDescription, f as DialogFooter } from "./AppLayout-D343eYEX.mjs";
import { B as Button } from "./button-DL752WFK.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { L as Label } from "./label-JU3yqRBo.mjs";
import { S as Select, a as SelectTrigger, b as SelectValue, c as SelectContent, d as SelectItem, T as Textarea } from "./ConfirmDelete-DuL2SYKU.mjs";
import { a as addPayment } from "./payments-CqySaxzc.mjs";
import { a as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { p as paymentMethods, e as egp } from "./router-D3vpDMsI.mjs";
import { t as toast } from "../_libs/sonner.mjs";
function DetailGrid({ items }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "grid grid-cols-2 gap-x-6 gap-y-4 p-6 sm:grid-cols-3", children: items.map((it, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: it.label }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 font-semibold text-foreground", children: it.value })
  ] }, i)) });
}
function SectionTitle({ children }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mb-3 mt-8 flex items-center gap-3 text-lg font-bold text-foreground", children });
}
function EmptyState({ children }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "p-6 text-center text-sm text-muted-foreground", children });
}
function PayNowDialog({ contractId, amount, dueDate, installment }) {
  const queryClient = useQueryClient();
  const [open, setOpen] = reactExports.useState(false);
  const [receipt, setReceipt] = reactExports.useState("");
  const [method, setMethod] = reactExports.useState(paymentMethods[0]);
  const [notes, setNotes] = reactExports.useState("");
  const [bankName, setBankName] = reactExports.useState("");
  const [accountNumber, setAccountNumber] = reactExports.useState("");
  const [otherNumber, setOtherNumber] = reactExports.useState("");
  const [loading, setLoading] = reactExports.useState(false);
  async function submit() {
    if (!receipt.trim()) {
      toast.error("يرجى إدخال رقم الإيصال");
      return;
    }
    setLoading(true);
    try {
      let payment_details = { notes };
      if (method === "تحويل بنكي") {
        payment_details.bank_name = bankName;
        payment_details.account_number = accountNumber;
      } else if (method !== "نقدي") {
        payment_details.number = otherNumber;
      }
      await addPayment({
        contract_id: contractId,
        amount,
        payment_date: dueDate,
        status: "مدفوع",
        receipt_number: receipt.trim(),
        payment_method: method,
        payment_details,
        receipt_url: null
      });
      queryClient.invalidateQueries({ queryKey: ["payments"] });
      toast.success(`تم تسجيل القسط #${installment} كمدفوع`);
      setOpen(false);
      setReceipt("");
    } catch (e) {
      toast.error(e.message || "حدث خطأ أثناء التسجيل");
    } finally {
      setLoading(false);
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Dialog, { open, onOpenChange: (v) => {
    setOpen(v);
    if (v) {
      setReceipt("");
      setNotes("");
      setBankName("");
      setAccountNumber("");
      setOtherNumber("");
    }
  }, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "outline", className: "h-7 gap-1 border-primary/40 text-primary hover:bg-primary/10 text-xs px-2", children: "ادفع الآن" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "max-w-md", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogHeader, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogTitle, { children: [
          "تسجيل دفعة — قسط #",
          installment
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(DialogDescription, { children: "أدخل رقم الإيصال وطريقة الدفع لتأكيد السداد." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 py-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-4 rounded-lg border border-border bg-muted/50 p-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "المبلغ المستحق" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-lg font-bold text-foreground", children: egp(amount) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "تاريخ الاستحقاق" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 font-semibold text-foreground", children: dueDate })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "mb-1.5 block text-sm", children: "رقم الإيصال" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Input,
            {
              value: receipt,
              onChange: (e) => setReceipt(e.target.value),
              placeholder: "مثال: RC-5001",
              onKeyDown: (e) => e.key === "Enter" && submit()
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "mb-1.5 block text-sm", children: "طريقة الدفع" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: method, onValueChange: setMethod, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {}) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: paymentMethods.map((m) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: m, children: m }, m)) })
          ] })
        ] }),
        method === "تحويل بنكي" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "mb-1.5 block text-sm", children: "اسم البنك" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: bankName, onChange: (e) => setBankName(e.target.value) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "mb-1.5 block text-sm", children: "رقم الحساب" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: accountNumber, onChange: (e) => setAccountNumber(e.target.value) })
          ] })
        ] }),
        method !== "نقدي" && method !== "تحويل بنكي" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "mb-1.5 block text-sm", children: "الرقم" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: otherNumber, onChange: (e) => setOtherNumber(e.target.value) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "mb-1.5 block text-sm", children: "ملاحظات" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { value: notes, onChange: (e) => setNotes(e.target.value), className: "resize-none" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogFooter, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", onClick: () => setOpen(false), children: "إلغاء" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: submit, disabled: loading, children: loading ? "جاري الحفظ..." : "تأكيد الدفع" })
      ] })
    ] })
  ] });
}
export {
  DetailGrid as D,
  EmptyState as E,
  PayNowDialog as P,
  SectionTitle as S
};
