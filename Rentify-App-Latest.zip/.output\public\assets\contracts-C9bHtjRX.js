import{j as t,O as o}from"./index-MFwZeyvL.js";const n=()=>t.jsx(o,{});export{n as component};
