import{o as n}from"./AppLayout-DWpWrGGj.js";function d(r,a,t){return n(r,a*3,t)}function s(r,a,t){return n(r,a*12,t)}export{d as a,s as b};
