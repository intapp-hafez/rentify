import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { e as useNavigate, L as Link } from "../_libs/tanstack__react-router.mjs";
import { a as useQueryClient, u as useQuery, b as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { A as AppLayout } from "./AppLayout-C7gE-JWZ.mjs";
import { B as Button } from "./button-DL752WFK.mjs";
import { I as Input } from "./input-C0QjszdI.mjs";
import { S as Select, a as SelectTrigger, b as SelectValue, c as SelectContent, d as SelectItem, C as CrudDialog, e as ConfirmDelete } from "./ConfirmDelete-C1KEQ8_E.mjs";
import { D as DataTable } from "./DataTable-lfA95yU8.mjs";
import { S as StatusBadge } from "./StatusBadge-AJi_pDVS.mjs";
import { a as addTenant, u as updateTenant, d as deleteTenant, g as getTenants } from "./tenants-C2ioY8Kw.mjs";
import { e as exportToExcel, d as downloadTemplate, i as importFromExcel } from "./excel-ncAzCXAJ.mjs";
import { g as Search, A as ArrowDownUp, D as Download, r as FileSpreadsheet, s as Upload, P as Plus, t as Pencil, u as Trash2 } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "./router-C7nVfvJ9.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/cmdk.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-effect-event+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-dropdown-menu.mjs";
import "../_libs/radix-ui__react-menu.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-roving-focus.mjs";
import "../_libs/date-fns.mjs";
import "../_libs/class-variance-authority.mjs";
import "./label-JU3yqRBo.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-select.mjs";
import "../_libs/radix-ui__number.mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "../_libs/radix-ui__react-alert-dialog.mjs";
import "./card-RGlIzTYo.mjs";
import "../_libs/xlsx.mjs";
const tenantStatuses = ["نشط", "متأخر بالسداد"];
const ALL = "__all__";
const PAGE_SIZE = 5;
function Tenants() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [search, setSearch] = reactExports.useState("");
  const [statusFilter, setStatusFilter] = reactExports.useState(ALL);
  const [sortDir, setSortDir] = reactExports.useState("asc");
  const [page, setPage] = reactExports.useState(1);
  const fileInputRef = reactExports.useRef(null);
  const {
    data: tenants = [],
    isLoading
  } = useQuery({
    queryKey: ["tenants"],
    queryFn: getTenants
  });
  const addMutation = useMutation({
    mutationFn: addTenant,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["tenants"]
      });
      toast.success("تم إضافة المستأجر بنجاح");
    },
    onError: (error) => toast.error(error.message)
  });
  const updateMutation = useMutation({
    mutationFn: updateTenant,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["tenants"]
      });
      toast.success("تم تحديث بيانات المستأجر بنجاح");
    },
    onError: (error) => toast.error(error.message)
  });
  const deleteMutation = useMutation({
    mutationFn: deleteTenant,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["tenants"]
      });
      toast.success("تم حذف المستأجر بنجاح");
    },
    onError: (error) => toast.error(error.message)
  });
  const fields = [{
    name: "full_name",
    label: "الاسم",
    colSpan: 2
  }, {
    name: "civil_id",
    label: "الرقم القومي / المدني"
  }, {
    name: "phone",
    label: "الهاتف"
  }, {
    name: "email",
    label: "البريد الإلكتروني"
  }, {
    name: "job",
    label: "جهة العمل"
  }, {
    name: "status",
    label: "الحالة",
    type: "select",
    options: ["نشط", "متأخر بالسداد"]
  }];
  const filtered = reactExports.useMemo(() => {
    const q = search.trim().toLowerCase();
    return tenants.filter((t) => {
      if (statusFilter !== ALL && t.status !== statusFilter) return false;
      if (q && ![t.full_name, t.civil_id, t.phone, t.job, t.email].some((v) => v?.toLowerCase().includes(q))) return false;
      return true;
    }).sort((a, b) => sortDir === "asc" ? a.full_name.localeCompare(b.full_name) : b.full_name.localeCompare(a.full_name));
  }, [tenants, statusFilter, search, sortDir]);
  const resetFilters = () => {
    setSearch("");
    setStatusFilter(ALL);
    setSortDir("asc");
    setPage(1);
  };
  const handleExport = () => {
    const exportData = tenants.map((t) => ({
      "الاسم": t.full_name,
      "الرقم القومي": t.civil_id,
      "الهاتف": t.phone,
      "البريد الإلكتروني": t.email,
      "جهة العمل": t.job,
      "الحالة": t.status
    }));
    exportToExcel(exportData, "المنشآت_العملاء");
  };
  const handleDownloadTemplate = () => {
    downloadTemplate(["full_name", "civil_id", "phone", "email", "job", "status"], "Tenants_Template");
  };
  const handleImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const toastId = toast.loading("جاري تحليل الملف واستيراد البيانات...");
    try {
      const data = await importFromExcel(file);
      if (!data || data.length === 0) {
        toast.error("الملف فارغ أو لا يحتوي على بيانات صحيحة", {
          id: toastId
        });
        return;
      }
      let successCount = 0;
      for (const row of data) {
        await addMutation.mutateAsync({
          full_name: row.full_name || "بدون اسم",
          civil_id: row.civil_id?.toString() || null,
          phone: row.phone?.toString() || null,
          email: row.email || null,
          job: row.job || null,
          status: row.status || "نشط"
        });
        successCount++;
      }
      queryClient.invalidateQueries({
        queryKey: ["tenants"]
      });
      toast.success(`تم استيراد ${successCount} عميل بنجاح`, {
        id: toastId
      });
    } catch (error) {
      toast.error(`فشل الاستيراد: ${error?.message || "تأكد من استخدام القالب الصحيح"}`, {
        id: toastId
      });
      console.error("Import Error:", error);
    } finally {
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };
  const columns = [{
    key: "full_name",
    header: "الاسم",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/tenants/$id", params: {
      id: r.id
    }, className: "font-bold text-primary hover:underline", children: r.full_name })
  }, {
    key: "civil_id",
    header: "الرقم القومي",
    render: (r) => r.civil_id || "-"
  }, {
    key: "phone",
    header: "الهاتف",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx("span", { dir: "ltr", className: "inline-block", children: r.phone || "-" })
  }, {
    key: "job",
    header: "جهة العمل",
    render: (r) => r.job || "-"
  }, {
    key: "status",
    header: "الحالة",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { status: r.status || "نشط" })
  }, {
    key: "actions",
    header: "إجراءات",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-1", onClick: (e) => e.stopPropagation(), children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CrudDialog, { title: "تعديل مستأجر", fields, initial: r, onSubmit: (v) => updateMutation.mutate({
        id: r.id,
        ...v
      }), trigger: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "icon", variant: "ghost", className: "h-8 w-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-4 w-4" }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(ConfirmDelete, { description: `سيتم حذف المستأجر "${r.full_name}".`, onConfirm: () => deleteMutation.mutate(r.id), trigger: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "icon", variant: "ghost", className: "h-8 w-8 text-destructive", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) }) })
    ] })
  }];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(AppLayout, { title: "العملاء والمستأجرون", subtitle: "بيانات المستأجرين والملاك والوسطاء", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "my-4 rounded-xl border border-border bg-card p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: search, onChange: (e) => {
          setSearch(e.target.value);
          setPage(1);
        }, placeholder: "بحث بالاسم أو الرقم القومي أو الهاتف", className: "pr-9" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: statusFilter, onValueChange: (v) => {
        setStatusFilter(v);
        setPage(1);
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "الحالة" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectContent, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: ALL, children: "كل الحالات" }),
          tenantStatuses.map((s) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: s, children: s }, s))
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2 md:col-span-2 xl:col-span-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", className: "flex-1 gap-1", onClick: () => setSortDir((d) => d === "asc" ? "desc" : "asc"), children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowDownUp, { className: "h-4 w-4" }),
          " ",
          sortDir === "asc" ? "أ-ي" : "ي-أ"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", onClick: resetFilters, children: "مسح" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex flex-wrap items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", className: "gap-1 text-muted-foreground", onClick: handleExport, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "h-4 w-4" }),
          " تصدير Excel"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", className: "gap-1 text-muted-foreground", onClick: handleDownloadTemplate, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(FileSpreadsheet, { className: "h-4 w-4" }),
          " تحميل القالب"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", className: "gap-1 text-muted-foreground", onClick: () => fileInputRef.current?.click(), children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "h-4 w-4" }),
          " استيراد Excel"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "file", ref: fileInputRef, onChange: handleImport, accept: ".xlsx, .xls, .csv", className: "hidden" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CrudDialog, { title: "إضافة مستأجر", fields, onSubmit: (v) => addMutation.mutate({
        ...v,
        full_name: v.full_name || "بدون اسم"
      }), trigger: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { className: "gap-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4" }),
        " إضافة مستأجر"
      ] }) })
    ] }),
    isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-8 w-8 animate-spin rounded-full border-b-2 border-primary" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx(DataTable, { columns, rows: filtered, onRowClick: (r) => navigate({
      to: "/tenants/$id",
      params: {
        id: r.id
      }
    }), page, defaultPageSize: PAGE_SIZE, onPageChange: setPage })
  ] });
}
export {
  Tenants as component
};
