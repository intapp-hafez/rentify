import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { a as useQueryClient, u as useQuery, b as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { A as AppLayout } from "./AppLayout-BsiDHgiV.mjs";
import { B as Button } from "./button-DL752WFK.mjs";
import { D as DataTable } from "./DataTable-ZJdNVHD0.mjs";
import { S as StatusBadge } from "./StatusBadge-BmU038Ba.mjs";
import { C as CrudDialog, e as ConfirmDelete } from "./ConfirmDelete-Dl1P26PU.mjs";
import { a as addMaintenance, u as updateMaintenance, d as deleteMaintenance, g as getMaintenanceRequests } from "./maintenance-BdeCqtns.mjs";
import { g as getUnits } from "./units-jeYWXtjB.mjs";
import { g as getTenants } from "./tenants-DVwDHI80.mjs";
import { e as exportToExcel, d as downloadTemplate, i as importFromExcel } from "./excel-ncAzCXAJ.mjs";
import { D as Download, r as FileSpreadsheet, s as Upload, P as Plus, t as Pencil, u as Trash2 } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/isbot.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "./router-ChN6Fncz.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/cmdk.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-effect-event+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-dropdown-menu.mjs";
import "../_libs/radix-ui__react-menu.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-roving-focus.mjs";
import "../_libs/date-fns.mjs";
import "../_libs/class-variance-authority.mjs";
import "./card-RGlIzTYo.mjs";
import "./input-C0QjszdI.mjs";
import "./label-JU3yqRBo.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-select.mjs";
import "../_libs/radix-ui__number.mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "../_libs/radix-ui__react-alert-dialog.mjs";
import "../_libs/xlsx.mjs";
const priorities = ["عاجل", "مرتفع", "متوسط", "منخفض", "عادي"];
const statuses = ["جديد", "قيد التنفيذ", "مكتمل", "مفتوح", "مغلق"];
const types = ["تكييف", "سباكة", "كهرباء", "مصاعد", "دهانات", "نجارة", "أخرى"];
function MaintenancePage() {
  const queryClient = useQueryClient();
  const fileInputRef = reactExports.useRef(null);
  const {
    data: maintenance = [],
    isLoading
  } = useQuery({
    queryKey: ["maintenance"],
    queryFn: getMaintenanceRequests
  });
  const {
    data: units = []
  } = useQuery({
    queryKey: ["units"],
    queryFn: getUnits
  });
  const {
    data: tenants = []
  } = useQuery({
    queryKey: ["tenants"],
    queryFn: getTenants
  });
  const addMutation = useMutation({
    mutationFn: addMaintenance,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["maintenance"]
      });
      toast.success("تم تسجيل طلب الصيانة بنجاح");
    },
    onError: (error) => toast.error(error.message)
  });
  const updateMutation = useMutation({
    mutationFn: updateMaintenance,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["maintenance"]
      });
      toast.success("تم تحديث طلب الصيانة بنجاح");
    },
    onError: (error) => toast.error(error.message)
  });
  const deleteMutation = useMutation({
    mutationFn: deleteMaintenance,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["maintenance"]
      });
      toast.success("تم حذف طلب الصيانة بنجاح");
    },
    onError: (error) => toast.error(error.message)
  });
  const fields = [{
    name: "number",
    label: "رقم الطلب"
  }, {
    name: "description",
    label: "الوصف",
    colSpan: 2
  }, {
    name: "unit_id",
    label: "الوحدة",
    type: "select",
    options: units.map((u) => ({
      value: u.id,
      label: `${u.title} - ${u.number || ""}`
    }))
  }, {
    name: "tenant_id",
    label: "المستأجر",
    type: "select",
    options: tenants.map((t) => ({
      value: t.id,
      label: t.full_name
    }))
  }, {
    name: "type",
    label: "النوع",
    type: "select",
    options: types
  }, {
    name: "priority",
    label: "الأولوية",
    type: "select",
    options: priorities
  }, {
    name: "status",
    label: "الحالة",
    type: "select",
    options: statuses
  }, {
    name: "maintenance_date",
    label: "التاريخ",
    type: "date"
  }, {
    name: "cost",
    label: "التكلفة",
    type: "number"
  }];
  const handleExport = () => {
    const exportData = maintenance.map((m) => ({
      "رقم الطلب": m.number,
      "الوحدة": `${m.units?.title} - ${m.units?.number || ""}`,
      "المستأجر": m.tenants?.full_name || "غير محدد",
      "الوصف": m.description,
      "النوع": m.type,
      "الأولوية": m.priority,
      "الحالة": m.status,
      "التكلفة": m.cost,
      "التاريخ": m.maintenance_date
    }));
    exportToExcel(exportData, "المنشآت_الصيانة");
  };
  const handleDownloadTemplate = () => {
    downloadTemplate(["number", "unit_id", "tenant_id", "description", "type", "priority", "status", "cost", "maintenance_date"], "Maintenance_Template");
  };
  const handleImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const toastId = toast.loading("جاري تحليل الملف واستيراد البيانات...");
    try {
      const data = await importFromExcel(file);
      if (!data || data.length === 0) {
        toast.error("الملف فارغ أو لا يحتوي على بيانات صحيحة", {
          id: toastId
        });
        return;
      }
      let successCount = 0;
      for (const row of data) {
        if (!row.unit_id || !row.tenant_id) continue;
        await addMutation.mutateAsync({
          number: row.number?.toString() || null,
          unit_id: row.unit_id,
          tenant_id: row.tenant_id,
          description: row.description || "بدون وصف",
          type: row.type || "أخرى",
          priority: row.priority || "عادي",
          status: row.status || "جديد",
          cost: Number(row.cost) || null,
          maintenance_date: row.maintenance_date || (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
        });
        successCount++;
      }
      queryClient.invalidateQueries({
        queryKey: ["maintenance"]
      });
      toast.success(`تم استيراد ${successCount} طلب صيانة بنجاح`, {
        id: toastId
      });
    } catch (error) {
      toast.error(`فشل الاستيراد: ${error?.message || "تأكد من استخدام القالب الصحيح"}`, {
        id: toastId
      });
      console.error("Import Error:", error);
    } finally {
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };
  const columns = [{
    key: "number",
    header: "رقم الطلب",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: r.number || "-" })
  }, {
    key: "unit",
    header: "الوحدة",
    render: (r) => `${r.units?.title} - ${r.units?.number || ""}`
  }, {
    key: "tenant",
    header: "المستأجر",
    render: (r) => r.tenants?.full_name || "-"
  }, {
    key: "type",
    header: "النوع",
    render: (r) => r.type || "أخرى"
  }, {
    key: "priority",
    header: "الأولوية",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { status: r.priority || "عادي" })
  }, {
    key: "status",
    header: "الحالة",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { status: r.status || "جديد" })
  }, {
    key: "maintenance_date",
    header: "التاريخ",
    render: (r) => r.maintenance_date || "-"
  }, {
    key: "actions",
    header: "إجراءات",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CrudDialog, { title: "تعديل طلب", fields, initial: r, onSubmit: (v) => updateMutation.mutate({
        id: r.id,
        ...v
      }), trigger: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "icon", variant: "ghost", className: "h-8 w-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-4 w-4" }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(ConfirmDelete, { description: `سيتم حذف الطلب "${r.number || "-"}".`, onConfirm: () => deleteMutation.mutate(r.id), trigger: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "icon", variant: "ghost", className: "h-8 w-8 text-destructive", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) }) })
    ] })
  }];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(AppLayout, { title: "الصيانة", subtitle: "إدارة طلبات الصيانة والفنيين والموردين", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex flex-wrap items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", className: "gap-1 text-muted-foreground", onClick: handleExport, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "h-4 w-4" }),
          " تصدير Excel"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", className: "gap-1 text-muted-foreground", onClick: handleDownloadTemplate, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(FileSpreadsheet, { className: "h-4 w-4" }),
          " تحميل القالب"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", className: "gap-1 text-muted-foreground", onClick: () => fileInputRef.current?.click(), children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "h-4 w-4" }),
          " استيراد Excel"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "file", ref: fileInputRef, onChange: handleImport, accept: ".xlsx, .xls, .csv", className: "hidden" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CrudDialog, { title: "طلب صيانة", fields, onSubmit: (v) => addMutation.mutate({
        ...v,
        status: v.status || "جديد",
        priority: v.priority || "عادي"
      }), trigger: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { className: "gap-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4" }),
        " طلب صيانة"
      ] }) })
    ] }),
    isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-8 w-8 animate-spin rounded-full border-b-2 border-primary" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx(DataTable, { columns, rows: maintenance })
  ] });
}
export {
  MaintenancePage as component
};
