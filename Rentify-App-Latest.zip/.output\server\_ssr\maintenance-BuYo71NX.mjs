import { s as supabase } from "./router-C7nVfvJ9.mjs";
const getMaintenanceRequests = async () => {
  const { data, error } = await supabase.from("maintenance").select("*, units(title, number), tenants(full_name)").order("created_at", { ascending: false });
  if (error) {
    throw new Error(error.message);
  }
  return data;
};
const addMaintenance = async (request) => {
  const { data, error } = await supabase.from("maintenance").insert([request]).select().single();
  if (error) {
    throw new Error(error.message);
  }
  return data;
};
const updateMaintenance = async ({ id, ...updateData }) => {
  const { data, error } = await supabase.from("maintenance").update(updateData).eq("id", id).select().single();
  if (error) {
    throw new Error(error.message);
  }
  return data;
};
const deleteMaintenance = async (id) => {
  const { error } = await supabase.from("maintenance").delete().eq("id", id);
  if (error) {
    throw new Error(error.message);
  }
};
export {
  addMaintenance as a,
  deleteMaintenance as d,
  getMaintenanceRequests as g,
  updateMaintenance as u
};
