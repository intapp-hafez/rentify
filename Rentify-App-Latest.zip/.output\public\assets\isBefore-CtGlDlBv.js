import{t}from"./AppLayout-DWpWrGGj.js";function i(o,r){return+t(o)<+t(r)}export{i};
