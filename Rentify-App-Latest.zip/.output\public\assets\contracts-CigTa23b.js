import{j as t,O as o}from"./index-BDl6EVWd.js";const n=()=>t.jsx(o,{});export{n as component};
