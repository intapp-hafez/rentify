import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { u as useRouter, L as Link } from "../_libs/tanstack__react-router.mjs";
import { A as AppLayout } from "./AppLayout-BsiDHgiV.mjs";
import { B as Button } from "./button-DL752WFK.mjs";
import { S as StatusBadge } from "./StatusBadge-BmU038Ba.mjs";
import { E as EmptyState, D as DetailGrid, S as SectionTitle, P as PayNowDialog } from "./PayNowDialog-C3LbVq29.mjs";
import { D as DataTable, w as wrapFourWords } from "./DataTable-ZJdNVHD0.mjs";
import { C as CrudDialog, e as ConfirmDelete } from "./ConfirmDelete-Dl1P26PU.mjs";
import { R as Route$3, e as egp } from "./router-ChN6Fncz.mjs";
import { a as useQueryClient, u as useQuery, b as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { u as updateUnit, d as deleteUnit, g as getUnits } from "./units-jeYWXtjB.mjs";
import { g as getContracts } from "./contracts-CF5GNrDa.mjs";
import { g as getPayments } from "./payments-DDfWMFC3.mjs";
import { g as getAllSettings } from "./settings-DeYgSfla.mjs";
import { _ as ArrowRight, t as Pencil, u as Trash2 } from "../_libs/lucide-react.mjs";
import { c as startOfDay, p as parseISO, h as isAfter, f as format, i as isBefore, g as addMonths, j as addQuarters, k as addYears } from "../_libs/date-fns.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "./utils-H80jjgLf.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/cmdk.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-effect-event+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-dropdown-menu.mjs";
import "../_libs/radix-ui__react-menu.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-roving-focus.mjs";
import "../_libs/class-variance-authority.mjs";
import "./card-RGlIzTYo.mjs";
import "./input-C0QjszdI.mjs";
import "./label-JU3yqRBo.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/radix-ui__react-select.mjs";
import "../_libs/radix-ui__number.mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "../_libs/radix-ui__react-alert-dialog.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/supabase__functions-js.mjs";
const getContractStatus = (status, endDate) => {
  if (status === "نشط" && endDate && isBefore(new Date(endDate), startOfDay(/* @__PURE__ */ new Date()))) {
    return "عقد منتهي";
  }
  return status || "نشط";
};
function buildSchedule(contracts, paymentsByDate) {
  const today = startOfDay(/* @__PURE__ */ new Date());
  const rows = [];
  for (const contract of contracts) {
    if (!contract.start_date || !contract.end_date) continue;
    const start = parseISO(contract.start_date);
    const end = parseISO(contract.end_date);
    const freq = contract.payment_frequency;
    const amount = contract.rent_amount;
    const contractDateMap = paymentsByDate.get(contract.id) ?? /* @__PURE__ */ new Map();
    let current = start;
    let installment = 1;
    while (!isAfter(current, end)) {
      const dateStr = format(current, "yyyy-MM-dd");
      const existing = contractDateMap.get(dateStr);
      let status;
      if (existing?.status === "مدفوع") {
        status = "مدفوع";
      } else if (isBefore(current, today)) {
        status = "متأخر";
      } else {
        status = "مستحق";
      }
      rows.push({
        id: `${contract.id}-${dateStr}`,
        contractId: contract.id,
        contractNumber: contract.number,
        tenantName: contract.tenants?.full_name ?? "—",
        installment,
        payment_date: dateStr,
        amount,
        status,
        receipt_number: existing?.receipt_number ?? null,
        payment_method: existing?.payment_method ?? null
      });
      installment++;
      if (freq === "monthly" || freq === "شهري") current = addMonths(current, 1);
      else if (freq === "quarterly" || freq === "ربع سنوي") current = addQuarters(current, 1);
      else current = addYears(current, 1);
    }
  }
  return rows.sort((a, b) => b.payment_date.localeCompare(a.payment_date));
}
function UnitDetail() {
  const {
    id
  } = Route$3.useParams();
  const router = useRouter();
  const queryClient = useQueryClient();
  const {
    data: units = [],
    isLoading: loadingUnits
  } = useQuery({
    queryKey: ["units"],
    queryFn: getUnits
  });
  const {
    data: contracts = []
  } = useQuery({
    queryKey: ["contracts"],
    queryFn: getContracts
  });
  const {
    data: payments = []
  } = useQuery({
    queryKey: ["payments"],
    queryFn: getPayments
  });
  const {
    data: settings
  } = useQuery({
    queryKey: ["settings"],
    queryFn: getAllSettings
  });
  const updateMutation = useMutation({
    mutationFn: updateUnit,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["units"]
      });
      toast.success("تم تحديث الوحدة بنجاح");
    },
    onError: (error) => toast.error(error.message)
  });
  const deleteMutation = useMutation({
    mutationFn: deleteUnit,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["units"]
      });
      toast.success("تم حذف الوحدة بنجاح");
      router.navigate({
        to: "/units"
      });
    },
    onError: (error) => toast.error(error.message)
  });
  const unit = units.find((u) => u.id === id);
  const unitContracts = reactExports.useMemo(() => contracts.filter((c) => c.unit_id === id), [contracts, id]);
  const currentContract = reactExports.useMemo(() => unitContracts.find((c) => c.status !== "terminated"), [unitContracts]);
  const paymentsByDate = reactExports.useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const p of payments) {
      if (!p.contract_id) continue;
      if (!map.has(p.contract_id)) map.set(p.contract_id, /* @__PURE__ */ new Map());
      map.get(p.contract_id).set(p.payment_date, {
        status: p.status,
        receipt_number: p.receipt_number,
        payment_method: p.payment_method
      });
    }
    return map;
  }, [payments]);
  const schedule = reactExports.useMemo(() => buildSchedule(unitContracts, paymentsByDate), [unitContracts, paymentsByDate]);
  const dueRows = reactExports.useMemo(() => schedule.filter((r) => r.status === "مستحق" || r.status === "متأخر"), [schedule]);
  const paidRows = reactExports.useMemo(() => schedule.filter((r) => r.status === "مدفوع"), [schedule]);
  if (loadingUnits) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(AppLayout, { title: "جاري التحميل...", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-8 w-8 animate-spin rounded-full border-b-2 border-primary" }) }) });
  }
  if (!unit) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(AppLayout, { title: "الوحدة غير موجودة", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(EmptyState, { children: [
      "لم يتم العثور على هذه الوحدة.",
      " ",
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "link", onClick: () => router.navigate({
        to: "/units"
      }), children: "العودة للوحدات" })
    ] }) });
  }
  const totalDue = dueRows.reduce((s, r) => s + r.amount, 0);
  const totalPaid = paidRows.reduce((s, r) => s + r.amount, 0);
  const totalScheduled = schedule.reduce((s, r) => s + r.amount, 0);
  const contractColumns = [{
    key: "number",
    header: "رقم العقد",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/contracts/$id", params: {
      id: r.id
    }, className: "font-bold text-primary hover:underline", children: r.number || "بدون رقم" })
  }, {
    key: "tenant",
    header: "المستأجر",
    render: (r) => r.tenant_id ? /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/tenants/$id", params: {
      id: r.tenant_id
    }, className: "text-primary hover:underline font-medium", children: r.tenants?.full_name || "—" }) : r.tenants?.full_name || "—"
  }, {
    key: "start_date",
    header: "البداية",
    render: (r) => r.start_date
  }, {
    key: "end_date",
    header: "النهاية",
    render: (r) => r.end_date
  }, {
    key: "rent_amount",
    header: "الإيجار",
    render: (r) => egp(r.rent_amount)
  }, {
    key: "deposit",
    header: "التأمين",
    render: (r) => egp(r.deposit || 0)
  }, {
    key: "status",
    header: "الحالة",
    render: (r) => /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { status: getContractStatus(r.status, r.end_date) })
  }];
  const fields = [{
    name: "number",
    label: "رقم الوحدة"
  }, {
    name: "title",
    label: "اسم العقار / العنوان",
    colSpan: 2
  }, {
    name: "type",
    label: "النوع",
    type: "select",
    options: settings?.property_types?.length ? settings.property_types : ["شقق سكنية", "فيلات", "مكاتب", "محلات تجارية", "مستودعات", "أراضي"]
  }, {
    name: "city",
    label: "المدينة / المحافظة",
    type: "select",
    options: settings?.governorates?.length ? settings.governorates : ["القاهرة", "الجيزة", "الإسكندرية"]
  }, {
    name: "address",
    label: "العنوان التفصيلي"
  }, {
    name: "floor",
    label: "الطابق",
    hidden: (v) => ["مستودعات", "أراضي"].includes(v.type)
  }, {
    name: "area",
    label: "المساحة (م²)",
    type: "number"
  }, {
    name: "rooms",
    label: "الغرف",
    type: "number",
    hidden: (v) => ["مستودعات", "أراضي", "محلات تجارية"].includes(v.type)
  }, {
    name: "baths",
    label: "الحمامات",
    type: "number",
    hidden: (v) => ["مستودعات", "أراضي"].includes(v.type)
  }, {
    name: "status",
    label: "الحالة",
    type: "select",
    options: ["available", "rented", "maintenance"]
  }, {
    name: "rent_price",
    label: "الإيجار",
    type: "number"
  }];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(AppLayout, { title: `وحدة ${unit.number || "بدون رقم"}`, subtitle: unit.title, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, variant: "outline", size: "sm", className: "gap-1", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/units", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "h-4 w-4" }),
        " الوحدات"
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CrudDialog, { title: "تعديل وحدة", fields, initial: unit, maxWidth: "max-w-2xl", onSubmit: (v) => updateMutation.mutate({
          ...v,
          id: unit.id
        }), trigger: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", size: "sm", className: "gap-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-4 w-4" }),
          " تعديل"
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ConfirmDelete, { description: `سيتم حذف الوحدة "${unit.number || unit.title}".`, onConfirm: () => deleteMutation.mutate(unit.id), trigger: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "destructive", size: "sm", className: "gap-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }),
          " حذف"
        ] }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(DetailGrid, { items: [{
      label: "العقار",
      value: unit.title
    }, {
      label: "النوع",
      value: unit.type
    }, {
      label: "المدينة",
      value: unit.city || "-"
    }, {
      label: "العنوان التفصيلي",
      value: unit.address || "-"
    }, {
      label: "الطابق",
      value: unit.floor || "-"
    }, {
      label: "المساحة",
      value: unit.area ? `${unit.area} م²` : "-"
    }, {
      label: "الغرف",
      value: unit.rooms || "-"
    }, {
      label: "الحمامات",
      value: unit.baths || "-"
    }, {
      label: "الإيجار",
      value: egp(unit.rent_price)
    }, {
      label: "الحالة",
      value: /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { status: unit.status || "متاح" })
    }, {
      label: "العقد الحالي",
      value: currentContract ? /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/contracts/$id", params: {
        id: currentContract.id
      }, className: "text-primary hover:underline", children: currentContract.number || "عرض العقد" }) : "—"
    }, {
      label: "المستأجر الحالي",
      value: currentContract?.tenants?.full_name ?? "—"
    }] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "my-6 grid grid-cols-3 gap-3 text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card p-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "إجمالي الجدول" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg font-bold", children: egp(totalScheduled) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-muted-foreground", children: [
          schedule.length,
          " قسط"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-emerald-700", children: "تم التحصيل" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg font-bold text-emerald-700", children: egp(totalPaid) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-emerald-700", children: [
          paidRows.length,
          " دفعة"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-amber-500/30 bg-amber-500/10 p-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-amber-700", children: "المتبقي" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg font-bold text-amber-700", children: egp(totalDue) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-amber-700", children: [
          dueRows.length,
          " دفعة"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionTitle, { children: [
      "العقود المرتبطة (",
      unitContracts.length,
      ")"
    ] }),
    unitContracts.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(DataTable, { columns: contractColumns, rows: unitContracts }) : /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { children: "لا توجد عقود مسجلة لهذه الوحدة حتى الآن." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(SectionTitle, { children: "جدول الدفعات المستحقة / المتأخرة" }),
    dueRows.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { children: "لا توجد دفعات مستحقة أو متأخرة." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto rounded-xl border border-border", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-sm", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-b border-border bg-muted/50 text-right", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold", children: "المستأجر" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold", children: "تاريخ الاستحقاق" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold", children: "المبلغ" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold", children: "الحالة" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { children: dueRows.map((row) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: `border-b border-border last:border-0 ${row.status === "متأخر" ? "bg-red-500/5" : ""}`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 text-xs", children: wrapFourWords(row.tenantName) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 tabular-nums", children: row.payment_date }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 font-semibold", children: egp(row.amount) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(StatusBadge, { status: row.status }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(PayNowDialog, { contractId: row.contractId, amount: row.amount, dueDate: row.payment_date, installment: row.installment }) })
      ] }, row.id)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(SectionTitle, { children: "سجل الدفعات المحصلة" }),
    paidRows.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { children: "لا توجد دفعات محصلة." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto rounded-xl border border-border", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-sm", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-b border-border bg-muted/50 text-right", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold", children: "المستأجر" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold", children: "التاريخ" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold", children: "المبلغ" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold", children: "الإيصال" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-semibold", children: "الطريقة" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { children: paidRows.map((row) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-b border-border bg-emerald-500/5 last:border-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 text-xs", children: wrapFourWords(row.tenantName) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 tabular-nums", children: row.payment_date }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 font-semibold", children: egp(row.amount) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3", children: row.receipt_number || "—" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3", children: row.payment_method || "—" })
      ] }, row.id)) })
    ] }) })
  ] });
}
export {
  UnitDetail as component
};
